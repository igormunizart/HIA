bl_info = {
    "name": "Auto-Update Addon",
    "author": "Seu Nome",
    "version": (1, 1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Auto Update",
    "description": "Addon com sistema de auto-atualização via GitHub",
    "warning": "",
    "doc_url": "",
    "category": "System",
}

import bpy
import requests
import json
import os
import zipfile
import shutil
from bpy.app.handlers import persistent
from datetime import datetime, timedelta

# Configurações do GitHub
GITHUB_USER = "igormunizart"
GITHUB_REPO = "HIA"
GITHUB_BRANCH = "main"

# Intervalo de verificação de atualizações (em horas)
CHECK_INTERVAL = 24

class AddonUpdater:
    @staticmethod
    def get_addon_path():
        """Retorna o caminho do addon atual"""
        return os.path.dirname(os.path.realpath(__file__))

    @staticmethod
    def get_current_version():
        """Retorna a versão atual do addon como string"""
        return ".".join(map(str, bl_info["version"]))

    @staticmethod
    def get_latest_release_info():
        """Obtém informações da última release do GitHub"""
        try:
            url = f"https://api.github.com/repos/{GITHUB_USER}/{GITHUB_REPO}/releases/latest"
            response = requests.get(url)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            print(f"Erro ao verificar versão: {str(e)}")
            return None

    @classmethod
    def download_and_install_update(cls, download_url):
        """Baixa e instala a nova versão do addon"""
        try:
            # Baixa o arquivo
            response = requests.get(download_url)
            response.raise_for_status()

            # Prepara os caminhos
            addon_path = cls.get_addon_path()
            temp_zip = os.path.join(addon_path, "update.zip")

            # Salva o arquivo zip
            with open(temp_zip, 'wb') as f:
                f.write(response.content)

            # Faz backup do arquivo de configuração atual
            config_file = os.path.join(addon_path, "config.json")
            config_backup = None
            if os.path.exists(config_file):
                with open(config_file, 'r') as f:
                    config_backup = f.read()

            # Remove arquivos antigos (exceto o zip baixado)
            for item in os.listdir(addon_path):
                if item != "update.zip":
                    item_path = os.path.join(addon_path, item)
                    if os.path.isfile(item_path):
                        os.unlink(item_path)
                    elif os.path.isdir(item_path):
                        shutil.rmtree(item_path)

            # Extrai arquivos novos
            with zipfile.ZipFile(temp_zip, 'r') as zip_ref:
                zip_ref.extractall(addon_path)

            # Restaura configurações
            if config_backup:
                with open(config_file, 'w') as f:
                    f.write(config_backup)

            # Remove o zip temporário
            os.unlink(temp_zip)

            return True
        except Exception as e:
            print(f"Erro na atualização: {str(e)}")
            return False

    @classmethod
    def check_for_update(cls):
        """Verifica se há uma atualização disponível"""
        release_info = cls.get_latest_release_info()
        if not release_info:
            return False, None

        current_version = cls.get_current_version()
        latest_version = release_info['tag_name'].lstrip('v')

        if latest_version > current_version:
            return True, release_info['zipball_url']

        return False, None

class AUTO_UPDATE_OT_check_update(bpy.types.Operator):
    """Verifica e instala atualizações do addon"""
    bl_idname = "auto_update.check_update"
    bl_label = "Verificar Atualizações"

    def execute(self, context):
        updater = AddonUpdater()
        has_update, download_url = updater.check_for_update()

        if has_update:
            # Pergunta ao usuário se deseja atualizar
            bpy.context.window_manager.popup_menu(
                lambda self, context: self.layout.operator(
                    "auto_update.do_update",
                    text="Nova versão disponível. Atualizar agora?"
                ),
                title="Atualização Disponível",
                icon='INFO'
            )
        else:
            self.report({'INFO'}, "Addon está atualizado!")

        return {'FINISHED'}

class AUTO_UPDATE_OT_do_update(bpy.types.Operator):
    """Executa a atualização do addon"""
    bl_idname = "auto_update.do_update"
    bl_label = "Atualizar Addon"

    def execute(self, context):
        updater = AddonUpdater()
        _, download_url = updater.check_for_update()

        if updater.download_and_install_update(download_url):
            self.report({'INFO'}, "Atualização concluída! Reinicie o Blender.")
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, "Erro ao atualizar o addon")
            return {'CANCELLED'}

class AUTO_UPDATE_PT_panel(bpy.types.Panel):
    """Painel de interface do usuário"""
    bl_label = "Auto Update 2"
    bl_idname = "AUTO_UPDATE_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Auto Update'

    def draw(self, context):
        layout = self.layout
        layout.operator("auto_update.check_update")

@persistent
def check_for_updates(dummy):
    """Verifica atualizações ao iniciar o Blender"""
    # Verifica se já passou o intervalo desde a última verificação
    last_check = bpy.context.preferences.addons[__package__].preferences.last_check
    if last_check:
        last_check = datetime.fromisoformat(last_check)
        if datetime.now() - last_check < timedelta(hours=CHECK_INTERVAL):
            return

    updater = AddonUpdater()
    has_update, _ = updater.check_for_update()

    if has_update:
        bpy.ops.auto_update.check_update('INVOKE_DEFAULT')

    # Atualiza o timestamp da última verificação
    bpy.context.preferences.addons[__package__].preferences.last_check = datetime.now().isoformat()

class AutoUpdateAddonPreferences(bpy.types.AddonPreferences):
    """Preferências do addon"""
    bl_idname = __package__

    last_check: bpy.props.StringProperty(
        name="Última verificação",
        default=""
    )

def register():
    bpy.utils.register_class(AutoUpdateAddonPreferences)
    bpy.utils.register_class(AUTO_UPDATE_OT_check_update)
    bpy.utils.register_class(AUTO_UPDATE_OT_do_update)
    bpy.utils.register_class(AUTO_UPDATE_PT_panel)
    bpy.app.handlers.load_post.append(check_for_updates)

def unregister():
    bpy.utils.unregister_class(AutoUpdateAddonPreferences)
    bpy.utils.unregister_class(AUTO_UPDATE_OT_check_update)
    bpy.utils.unregister_class(AUTO_UPDATE_OT_do_update)
    bpy.utils.unregister_class(AUTO_UPDATE_PT_panel)
    if check_for_updates in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(check_for_updates)

if __name__ == "__main__":
    register()
