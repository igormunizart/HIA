# ------------------------------------------------------------------------ #
# Start of boneCollections.py
# Operators to manage the bone collections

import bpy
import json
from collections import defaultdict
from .userInterfaceMoveButtons import draw_move_config_button_bc
from .customIcons import get_icon_id, get_icon

from . import utils

ADDON_NAME = __package__.split(".")[0]
PRO_VERSION = utils.check_pro_version()


from .utils import (
    refresh_ui,
    get_group_index,
    generate_unique_id,
    save_bc_props_to_json,
    restore_bc_props_from_json,
)


from .userInterface_groups import (
    draw_bc_ui_groups_list,
)


from .utils import RIG_UI_OT_ToggleCollectionGroups

# else:

#     def draw_bc_ui_groups_list(context, layout):
#         pass


def on_collection_name_update(self, context):
    bpy.ops.rig_ui.refresh_bc_list()


def draw_bc_main_ui(layout, context):
    """Draws the bone collection buttons in the Rig UI panel."""
    armature = context.view_layer.objects.active
    props = armature.data.rig_ui_props
    active_pose_bone = context.active_pose_bone
    selected_bones = context.selected_pose_bones
    move_bone_active = props.rig_ui_move_bone_collections_active

    # Create a mapping from group unique IDs to their index
    group_index_map = {group.unique_id: idx for idx, group in enumerate(armature.data.bone_collections_ui_groups)}

    # Group the collections based on the index in the groups list
    grouped_collections = defaultdict(lambda: defaultdict(list))
    ungrouped_pinned_collections = []

    for collection in armature.data.collections_all.values():
        if collection.get("rig_ui_pin", False):
            group_index = group_index_map.get(collection.get("group_id", None))
            row_index = collection.get("rig_ui_row", 0)
            if group_index is not None:
                grouped_collections[group_index][row_index].append(collection)
            else:
                ungrouped_pinned_collections.append(collection)

    # Sort each group's collections by priority and name
    for group_index, rows in grouped_collections.items():
        for row_index, collections in rows.items():
            collections.sort(key=lambda x: (x.get("rig_ui_priority", 0), x.name.lower()))

    vertical_spacing = armature.data.ui_button_vertical_separation * 1.5
    horizontal_spacing = armature.data.ui_button_horizontal_separation * 3
    for group_index in sorted(group_index_map.values()):
        if group_index in grouped_collections:
            group_item = armature.data.bone_collections_ui_groups[group_index]
            draw_bc_group_based_on_style(
                layout,
                grouped_collections[group_index],
                group_index,
                props,
                active_pose_bone,
                selected_bones,
                move_bone_active,
                armature,
                vertical_spacing,
                horizontal_spacing,
            )

    # Check if there are any groups created
    any_group_created = len(armature.data.bone_collections_ui_groups) > 0

    # Organize ungrouped pinned collections into rows
    if ungrouped_pinned_collections:
        ungrouped_pinned_row_collections = defaultdict(list)
        for collection in ungrouped_pinned_collections:
            row_index = collection.get("rig_ui_row", 0)
            ungrouped_pinned_row_collections[row_index].append(collection)

        # Sort collections within each row by priority and name
        for row_index in ungrouped_pinned_row_collections:
            ungrouped_pinned_row_collections[row_index].sort(
                key=lambda x: (x.get("rig_ui_priority", 0), x.name.lower())
            )

        # Draw ungrouped pinned collections
        # if PRO_VERSION and props.group_headers_boneCollections and any_group_created:
        layout.label(text="Ungrouped Pinned Bone Collections")
        ungrouped_container = layout.box()
        ungrouped_column = ungrouped_container.column(align=True)
        for row_index, collections_in_row in sorted(ungrouped_pinned_row_collections.items()):
            row_layout = ungrouped_column.row(align=True)
            for collection in collections_in_row:
                index = armature.data.bone_collection_properties.find(collection.name)
                draw_bc_ui_button(
                    row_layout,
                    collection,
                    index,
                    props,
                    active_pose_bone,
                    selected_bones,
                    move_bone_active,
                    vertical_spacing,
                    horizontal_spacing,
                )

    draw_unpinned_collections(
        layout,
        context,
        vertical_spacing,
        horizontal_spacing,
    )


# nested collection elements for the setup list
def draw_nested_collection_setup_list(layout, collection, depth=0):
    """Recursively draw a collection and its nested collections with indentation."""
    box = layout.box()
    row = box.row()
    split = row.split(factor=0.05 * depth)
    split.label(text="")  # Indentation
    main_row = split.row()

    # Example of toggling visibility, adapt as necessary
    main_row.prop(collection, "is_visible", text=collection.name, icon="OUTLINER_OB_ARMATURE")

    # Add any other controls you need for each collection here
    # For example, buttons for expanding/collapsing, adding/removing bones, etc.

    # Recurse into children if expanded (you need a property on the collection to track this)
    if getattr(collection, "expanded", True):  # Assuming 'expanded' is a custom property you manage
        for child_name, child in collection.children.items():
            draw_nested_collection_setup_list(box, child, depth + 1)


# All the drawing for the Setup panel happens in this function
def draw_bc_setup_list(layout, context):
    armature = context.view_layer.objects.active

    # Collapsible header for bone collections
    armature_props = armature.data.rig_ui_props

    list_container = layout.column()

    row_legend = list_container.row()
    row_legend.alignment = "CENTER"

    # if PRO_VERSION:
    row_legend.label(text=" Pin | Icon | Show Name | Name |  Group | Row | Priority ")
    # else:
    #     row_legend.label(text=" Pin | Icon | Show Name | Name |  Row | Priority ")

    # UI List
    row_list = list_container.row(align=True)
    col_list = row_list.column(align=True)
    col_list.template_list(
        "RIG_UI_UL_BoneCollections",
        "rig_ui",
        armature.data,
        "bone_collection_properties",
        armature.data,
        "active_bone_collection_index",
    )

    # Add and Remove buttons
    col_buttons = row_list.column(align=True)
    col_buttons.operator("rig_ui.add_bone_collection", **get_icon("Add"), text="")
    col_buttons.operator("rig_ui.remove_bone_collection", **get_icon("Remove"), text="")
    col_buttons.operator("rig_ui.refresh_bc_list", text="", **get_icon("Refresh"))

    # if PRO_VERSION:
    BoneCollections_Groups_Title_box = list_container.column()
    header_row = BoneCollections_Groups_Title_box.row()
    icon = "DOWNARROW_HLT" if not armature_props.rig_ui_setup_boneCollectionsgroup_collapsed else "RIGHTARROW"
    header_row.prop(
        armature_props,
        "rig_ui_setup_boneCollectionsgroup_collapsed",
        icon=icon,
        emboss=False,
        text="Bone Collections UI Groups",
    )

    if not armature_props.rig_ui_setup_boneCollectionsgroup_collapsed:
        draw_bc_ui_groups_list(context, list_container, armature)


def draw_bc_unpinned_buttons(
    layout,
    collections,
    props,
    active_pose_bone,
    selected_bones,
    move_bone_active,
    armature,
    context,
    vertical_spacing,
    horizontal_spacing,
):
    """Draw toggleable buttons for the included bone collections, organized by rows and priorities."""

    # Organize collections into rows
    row_collections = defaultdict(list)
    for collection in collections:
        row_index = collection.get("rig_ui_row", 0)
        row_collections[row_index].append(collection)

    # Sort collections within each row by priority and name
    for row_index in row_collections:
        row_collections[row_index].sort(key=lambda x: (x.get("rig_ui_priority", 0), x.name))

    # Draw collections for each row
    for row_index, collections_in_row in sorted(row_collections.items()):
        row_layout = layout.row(align=props.bone_collections_cozy_horizontal)
        armature = bpy.context.view_layer.objects.active
        for collection in collections_in_row:
            index = armature.data.bone_collection_properties.find(collection.name)
            draw_bc_ui_button(
                row_layout,
                collection,
                index,
                props,
                active_pose_bone,
                selected_bones,
                move_bone_active,
                0,
                0,
            )


def draw_bc_group_based_on_style(
    layout,
    rows,
    group_index,
    props,
    active_pose_bone,
    selected_bones,
    move_bone_active,
    armature,
    vertical_spacing=0.2,
    horizontal_spacing=0.2,
):
    # Ensure the group_index is valid
    if group_index >= len(armature.data.bone_collections_ui_groups):
        return  # Skip if the group index is not valid

    group_item = armature.data.bone_collections_ui_groups[group_index]
    group_style = group_item.display_type

    groups_separation = armature.data.ui_groups_vertical_separation
    # Render the group based on its style
    layout.separator(factor=groups_separation)
    if group_style == "HEADER" or group_style == "HEADER_BOX":
        draw_bc_header_group_style(
            layout,
            rows,
            group_item,
            props,
            active_pose_bone,
            selected_bones,
            move_bone_active,
            armature,
            vertical_spacing,
            horizontal_spacing,
        )
    elif group_style == "BOX" or group_style == "LABEL_BOX":
        draw_bc_box_group_style(
            layout,
            rows,
            group_item,
            props,
            active_pose_bone,
            selected_bones,
            move_bone_active,
            armature,
            vertical_spacing,
            horizontal_spacing,
        )
    elif group_style == "LABEL":
        draw_bc_label_group_style(
            layout,
            rows,
            group_item,
            props,
            active_pose_bone,
            selected_bones,
            move_bone_active,
            armature,
            vertical_spacing,
            horizontal_spacing,
        )
    elif group_style == "NONE":
        draw_bc_group_no_style(
            layout,
            rows,
            group_item,
            props,
            active_pose_bone,
            selected_bones,
            move_bone_active,
            armature,
            vertical_spacing,
            horizontal_spacing,
        )
    layout.separator(factor=groups_separation)


# Add the new helper functions for rendering group styles here
def draw_bc_header_group_style(
    layout,
    rows,
    group_item,
    props,
    active_pose_bone,
    selected_bones,
    move_bone_active,
    armature,
    vertical_spacing,
    horizontal_spacing,
):
    header_container = layout.column()
    header_container.alignment = "EXPAND"
    label = group_item.name if props.group_headers_boneCollections or not group_item.toggle else " "
    icon = "TRIA_DOWN" if group_item.toggle else "TRIA_RIGHT"

    if group_item.display_type == "HEADER_BOX":
        header_row = header_container.box()
        header_row.prop(group_item, "toggle", text=label, emboss=False, icon=icon)
        header_row.scale_y = 0.5
        if group_item.toggle:
            draw_bc_ui_buttons_in_group(
                layout,
                rows,
                props,
                active_pose_bone,
                selected_bones,
                move_bone_active,
                vertical_spacing,
                horizontal_spacing,
            )
    else:
        icon = "DOWNARROW_HLT" if group_item.toggle else "RIGHTARROW"
        header_container.prop(group_item, "toggle", text=label, emboss=False, icon=icon)
        if group_item.toggle:
            draw_bc_ui_buttons_in_group(
                layout,
                rows,
                props,
                active_pose_bone,
                selected_bones,
                move_bone_active,
                vertical_spacing,
                horizontal_spacing,
            )


def draw_bc_ui_buttons_in_group(
    container,
    rows,
    props,
    active_pose_bone,
    selected_bones,
    move_bone_active,
    vertical_spacing,
    horizontal_spacing,
):
    wrapper = container.column(align=props.bone_collections_cozy_vertical)
    for row_index, row_collections in sorted(rows.items()):
        wrapper.separator(factor=vertical_spacing)
        row_layout = wrapper.row(align=props.bone_collections_cozy_horizontal)
        armature = bpy.context.view_layer.objects.active
        for collection in row_collections:
            index = armature.data.bone_collection_properties.find(collection.name)
            draw_bc_ui_button(
                row_layout,
                collection,
                index,
                props,
                active_pose_bone,
                selected_bones,
                move_bone_active,
                vertical_spacing,
                horizontal_spacing,
            )


def draw_bc_box_group_style(
    layout,
    rows,
    group_item,
    props,
    active_pose_bone,
    selected_bones,
    move_bone_active,
    armature,
    vertical_spacing,
    horizontal_spacing,
):

    # Create a box for the group
    box = layout.box()

    if group_item.display_type == "LABEL_BOX" and props.group_headers_boneCollections:
        box.label(text=group_item.name)

    # Draw the collections in rows within the box
    wrapper = box.column(align=props.bone_collections_cozy_vertical)
    for row_index, row_collections in sorted(rows.items()):
        wrapper.separator(factor=vertical_spacing)
        row_layout = wrapper.row(align=props.bone_collections_cozy_horizontal)
        for collection in row_collections:
            index = armature.data.bone_collection_properties.find(collection.name)
            draw_bc_ui_button(
                row_layout,
                collection,
                index,
                props,
                active_pose_bone,
                selected_bones,
                move_bone_active,
                vertical_spacing,
                horizontal_spacing,
            )
        wrapper.separator(factor=vertical_spacing)


def draw_bc_label_group_style(
    layout,
    rows,
    group_item,
    props,
    active_pose_bone,
    selected_bones,
    move_bone_active,
    armature,
    vertical_spacing,
    horizontal_spacing,
):
    # Create a label for the group
    label_row = layout.row()
    if props.group_headers_boneCollections:
        label_row.label(text=group_item.name)

    # Create a box for the buttons
    box = layout.box()

    # Draw the collections in rows under the label
    wrapper = box.column(align=props.bone_collections_cozy_vertical)
    for row_index, row_collections in sorted(rows.items()):
        wrapper.separator(factor=vertical_spacing)
        row_layout = wrapper.row(align=props.bone_collections_cozy_horizontal)
        for collection in row_collections:
            index = armature.data.bone_collection_properties.find(collection.name)
            draw_bc_ui_button(
                row_layout,
                collection,
                index,
                props,
                active_pose_bone,
                selected_bones,
                move_bone_active,
                vertical_spacing,
                horizontal_spacing,
            )
        wrapper.separator(factor=vertical_spacing)


def draw_bc_group_no_style(
    layout,
    rows,
    group_item,
    props,
    active_pose_bone,
    selected_bones,
    move_bone_active,
    armature,
    vertical_spacing,
    horizontal_spacing,
):
    # Basic layout for the group without any specific style
    wrapper = layout.column(align=props.bone_collections_cozy_vertical)
    for row_index, row_collections in sorted(rows.items()):
        armature = bpy.context.view_layer.objects.active
        wrapper.separator(factor=vertical_spacing)
        row_layout = wrapper.row(align=props.bone_collections_cozy_horizontal)
        for collection in row_collections:
            index = armature.data.bone_collection_properties.find(collection.name)
            draw_bc_ui_button(
                row_layout,
                collection,
                index,
                props,
                active_pose_bone,
                selected_bones,
                move_bone_active,
                vertical_spacing,
                horizontal_spacing,
            )
        wrapper.separator(factor=vertical_spacing)


def draw_bc_ui_button(
    layout,
    collection,
    index,
    props,
    active_pose_bone,
    selected_bones,
    move_bone_active,
    vertical_spacing,
    horizontal_spacing,
):
    prefs = bpy.context.preferences.addons[ADDON_NAME].preferences
    obj = bpy.context.active_object
    armature = obj.data
    props = armature.rig_ui_props
    is_moving = armature.ui_moving_item_index == index and armature.ui_active_section == "bone_collections"
    element_name = armature.collections_all.get(collection.name)
    rig_ui_pin = element_name.get("rig_ui_pin", False)
    is_pro_version = PRO_VERSION
    if is_pro_version:
        special_feature_enabled = bpy.context.preferences.addons[ADDON_NAME].preferences.RIG_UI_bc_pro_ui
    else:
        special_feature_enabled = False

    # Set the alert flag based on the moving state
    layout.alert = is_moving

    # button_separator = 0.2
    # horizontal_separation = armature.ui_button_horizontal_separation * 3

    pre_button_row = layout.row(align=True)
    if element_name["rig_ui_priority"] != 1:
        pre_button_row.separator(factor=horizontal_spacing)

    if prefs.RIG_UI_config_mode:
        if prefs.Rig_UI_element_mode == "MOVE":
            draw_move_config_button_bc(pre_button_row, index, "bone_collection_properties", "bone_collections")

        elif prefs.Rig_UI_element_mode == "PIN":
            pre_button_row.prop(
                element_name,
                '["rig_ui_pin"]',
                icon_value=(get_icon_id("Pinned") if rig_ui_pin else get_icon_id("Unpinned")),
                text="",
                emboss=False,
            )

        elif prefs.Rig_UI_element_mode == "EDIT":
            edit_op = pre_button_row.operator(
                "rig_ui.edit_bone_collection",
                text="",
                icon_value=get_icon_id("Edit_prop"),
                emboss=False,
            )
            edit_op.collection_name = collection.name

        elif prefs.Rig_UI_element_mode == "ADD_REMOVE":
            delete_row = pre_button_row.row(align=True)
            delete_row.alert = True
            edit_op = delete_row.operator(
                "rig_ui.remove_bone_collection",
                text="",
                icon="TRASH",
                emboss=False,
            )
            edit_op.collection_name = collection.name

    # Check if in pose mode
    in_pose_mode = bpy.context.active_object.mode == "POSE"

    # Determine if the active pose bone is in the collection
    active_and_selected_bone = active_pose_bone in selected_bones if in_pose_mode else False

    bone_in_collection = active_and_selected_bone and active_pose_bone.name in collection.bones

    # Set icon based on visibility
    is_visible = collection.is_visible
    is_solo = collection.is_solo

    # Determine if the collection button should be faded
    fade_out = bone_in_collection if props.rig_ui_fade_non_current_bc and move_bone_active else is_visible

    # Determine if the collection button should be highlighted
    highlight = (
        (bone_in_collection and props.rig_ui_highlight_active_bc) or (is_solo)
        if (bone_in_collection is not None)
        else False
    )

    eye_icon = get_icon_id("Eye_on") if is_visible else get_icon_id("Eye_off")

    # Add the separator only if it is not the element in the row with the highest priority

    button_row = layout.row(align=True)
    button_row.active = fade_out

    # If move mode is active, draw the add or remove bone collection button
    if prefs.RIG_UI_config_mode and prefs.Rig_UI_element_mode == "UI_SCALE":
        factor_row = button_row.row(align=False)
        factor_row.scale_x = collection["button_factor"]

        if element_name["display_name"] == True:
            factor_row.prop(
                element_name,
                '["button_factor"]',
                text=element_name.name,
                icon=element_name["icon_name"],
                slider=False,
            )
        else:

            factor_row.enabled = False
            factor_row.prop(
                element_name,
                "is_visible",
                text="",
                icon=element_name["icon_name"],
                emboss=False,
            )

    else:
        if move_bone_active and is_pro_version and not prefs.RIG_UI_config_mode:
            if active_and_selected_bone:
                move_icon = get_icon_id("Remove_bone") if bone_in_collection else get_icon_id("Add_bone")

            else:
                move_icon = 101  # "BLANK1"

            op = pre_button_row.operator("rig_ui.move_bone_collections", text="", icon_value=move_icon)
            op.collection_name = collection.name

        # If the visibility preference is enabled, draw the visibility toggle per bone collection button
        elif PRO_VERSION and prefs.RIG_UI_display_bc_eyes and not prefs.RIG_UI_config_mode:
            pre_button_row.active = fade_out
            pre_button_row.prop(
                collection,
                "is_visible",
                text="",
                toggle=True,
                icon_value=eye_icon,
                emboss=False,
            )

        button_subrow = button_row.row(align=False)
        button_subrow.scale_x = collection["button_factor"]

        if special_feature_enabled and PRO_VERSION:
            draw_bc_ui_button_pro(
                button_subrow,
                collection,
                props,
                active_pose_bone,
                selected_bones,
                move_bone_active,
                highlight,
                prefs,
                fade_out,
                horizontal_spacing,
            )
        else:
            draw_bc_ui_button_basic(
                button_subrow,
                collection,
                props,
                active_pose_bone,
                selected_bones,
                move_bone_active,
                highlight,
                prefs,
                fade_out,
                horizontal_spacing,
            )

        # if prefs.RIG_UI_config_mode:
        #     button_row.separator(factor=0.2)


def draw_bc_ui_button_basic(
    layout,
    collection,
    props,
    active_pose_bone,
    selected_bones,
    move_bone_active,
    highlight,
    prefs,
    fade_out,
    horizontal_separation=0.2,
):
    """Draw a single collection button with specific properties."""
    # Original button drawing logic
    presub_layout = layout.row(align=False)
    sub_layout = presub_layout.row(align=True)
    is_pro_version = PRO_VERSION

    # Determine if the active pose bone is in the collection
    active_and_selected_bone = active_pose_bone and active_pose_bone in selected_bones
    bone_in_collection = active_and_selected_bone and active_pose_bone.name in collection.bones

    # # Determine if the collection button should be faded
    fade_out = (
        props.rig_ui_fade_non_current_bc
        and move_bone_active
        and active_and_selected_bone
        and active_pose_bone.name not in collection.bones
    )

    # Determine if the collection button should be highlighted
    # highlight = (
    #     (
    #         bone_in_collection
    #         and active_and_selected_bone
    #         and props.rig_ui_highlight_active_bc
    #     )
    #     if bone_in_collection is not None
    #     else False
    # )
    emboss_if_selected = bone_in_collection if active_and_selected_bone else True

    # Set active state and alert flag based on bone's presence in the collection
    sub_layout.active = highlight if (props.rig_ui_highlight_active_bc and selected_bones) else not fade_out
    # sub_layout.alert = highlight

    # Collection visibility toggle buttons
    icon_name = "NONE" if collection.get("icon_name", "BLANK1") == "BLANK1" else collection.get("icon_name")

    if move_bone_active and is_pro_version:
        if active_and_selected_bone:
            move_icon = get_icon_id("Add_bone") if bone_in_collection else get_icon_id("Remove_bone")
        else:
            move_icon = 101  # "BLANK1"
        op = sub_layout.operator("rig_ui.move_bone_collections", text="", icon_value=move_icon)
        op.collection_name = collection.name

    display_text = collection.name if collection.get("display_name", False) else ""
    sub_layout.prop(
        collection,
        "is_visible",
        text=display_text,
        toggle=True,
        icon=icon_name,
        emboss=True,  # (highlight if move_bone_active else True),
        event=True,
    )

    # sub_layout.separator(factor=horizontal_separation)


def draw_bc_ui_button_pro(
    layout,
    collection,
    props,
    active_pose_bone,
    selected_bones,
    move_bone_active,
    highlight,
    prefs,
    fade_out,
    horizontal_separation=0.2,
):
    """Draw a single collection button with specific properties."""

    # Collection visibility toggle buttons
    icon_name = "NONE" if collection.get("icon_name", "BLANK1") == "BLANK1" else collection.get("icon_name")

    display_text = collection.name if collection.get("display_name", False) else ""
    special_button = layout.operator(
        "rig_ui.bone_collection_action",
        text=display_text,
        icon=icon_name,
        emboss=fade_out if prefs.RIG_UI_high_contrast_fade else True,
        depress=highlight,
    )

    special_button.collection_name = collection.name


def draw_unpinned_collections(layout, context, vertical_spacing, horizontal_spacing):
    """Draws the unpinned collections in the Rig UI panel."""
    armature = context.view_layer.objects.active
    props = armature.data.rig_ui_props
    active_pose_bone = context.active_pose_bone
    selected_bones = context.selected_pose_bones
    move_bone_active = props.rig_ui_move_bone_collections_active
    prefs = bpy.context.preferences.addons[ADDON_NAME].preferences
    pin_mode = prefs.Rig_UI_element_mode == "PIN"
    add_remove_mode = prefs.Rig_UI_element_mode == "ADD_REMOVE"
    config_mode = prefs.RIG_UI_config_mode
    never_display_pinned = props.rig_ui_show_hidden_mode == "NEVER"
    on_move_display_pinned = props.rig_ui_show_hidden_mode == "ON_MOVE"
    section_headers = prefs.RIG_UI_section_headers

    if (
        (never_display_pinned and (not config_mode))
        or ((on_move_display_pinned and not move_bone_active) and (not config_mode))
        or (config_mode and not (pin_mode or add_remove_mode))
    ):
        return

    hidden_collections = [
        collection for collection in armature.data.collections_all.values() if not collection.get("rig_ui_pin", False)
    ]
    sorted_hidden_collections = sorted(
        hidden_collections,
        key=lambda l: (l.get("rig_ui_row", 0), -l.get("rig_ui_priority", 0), l.name),
    )

    hidden_collections_container = layout.column()
    hidden_collections_container.active = not props.bone_collections_grey_out_unpinned
    if section_headers or config_mode:
        label_name = "Unpinned Bone Collections"
        hidden_collections_container.label(text=label_name)

    buttons_box = (
        hidden_collections_container.column() if prefs.RIG_UI_section_boxes else hidden_collections_container.box()
    )
    buttons_col = buttons_box.column(align=props.bone_collections_cozy_vertical)
    draw_bc_unpinned_buttons(
        buttons_col,
        sorted_hidden_collections,
        props,
        active_pose_bone,
        selected_bones,
        move_bone_active,
        armature,
        context,
        vertical_spacing,
        horizontal_spacing,
    )


def draw_bone_collection_item_expanded(layout, bone_collection, collection_name):
    armature = bpy.context.view_layer.objects.active

    # Layout for a single bone collection
    box = layout.box()

    # First row: Pin state, Icon, Name, and Display Name
    row = box.row(align=True)

    # Pin state toggle
    rig_ui_pin = bone_collection.get("rig_ui_pin", False)
    ui_include_icon = "PINNED" if rig_ui_pin else "UNPINNED"
    row.prop(bone_collection, '["rig_ui_pin"]', icon=ui_include_icon, text="")

    # Icon selection
    icon_name = bone_collection.get("icon_name", "BLANK1")
    icon_selector_op = row.operator("rig_ui.icon_selector", text="", icon=icon_name)
    icon_selector_op.apply_context = "bone_collection"
    icon_selector_op.bone_collection_name = collection_name

    # Display Name
    row.prop(bone_collection, '["display_name"]', text="", emboss=True, icon="FILE_TEXT")
    # row.prop(
    #     bone_collection,
    #     "name",
    #     text="",
    #     emboss=True,
    # )
    row.separator(factor=0.5)

    # Button to rename the collection
    rename_op = row.operator(
        "rig_ui.rename_bone_collection",
        text=bone_collection.name,
        emboss=True,
        icon="GREASEPENCIL",
    )
    rename_op.collection_name = collection_name

    row.separator(factor=0.5)

    trash_op = row.row(align=True)
    trash_op.alert = True
    trash_op.operator(
        "rig_ui.remove_bone_collection",
        text="",
        icon="TRASH",
    ).collection_name = collection_name

    # Second row: Group, Row, and Priority
    row_2 = box.row(align=True)

    # Group selection
    group_label = "Ungrouped"
    group_id = bone_collection.get("group_id", "NONE")
    # Assuming armature.data.bone_collections_ui_groups contains group info
    # Replace with your group fetching logic if different
    for idx, group in enumerate(armature.data.bone_collections_ui_groups):
        if group.unique_id == group_id:
            group_label = group.name
            break

    select_group_op = row_2.operator("bonecollection.select_group", text=group_label)
    select_group_op.collection_name = collection_name
    row_2.separator(factor=0.5)
    # Row and Priority
    row_2.prop(bone_collection, '["rig_ui_row"]', text="Row")
    row_2.prop(bone_collection, '["rig_ui_priority"]', text="Priority")

    # # Third row: Visibility, Selectability, and Lock
    # row_3 = box.column(align=True)
    # row_3.label(text="Bone Collections Goups:")
    # draw_bc_ui_groups_list(collection_name, row_3, armature)

    # Toggle button for expanding the bone collection groups
    row_3 = box.row()
    is_expanded = RIG_UI_OT_ToggleCollectionGroups.toggle_state.get(collection_name, False)

    icon = "TRIA_DOWN" if is_expanded else "TRIA_RIGHT"
    toggle_op = row_3.operator(
        "rig_ui.toggle_collection_groups",
        text="Bone Collections Groups",
        icon=icon,
        emboss=False,
    )
    toggle_op.collection_name = collection_name

    if is_expanded:
        # Draw the expanded section
        group_box = box.column(align=True)
        draw_bc_ui_groups_list(collection_name, group_box, armature)


# We need an operator that uses the default Blender ADD bone collection and refreshes the UI
# This is only for creating new bone collections in Edit Mode
class RIG_UI_OT_AddBoneCollection(bpy.types.Operator):
    """Adds a new bone collection and refreshes the UI."""

    bl_idname = "rig_ui.add_bone_collection"
    bl_label = "Add Bone Collection"

    def execute(self, context):
        armature = context.active_object
        if armature and armature.type == "ARMATURE":
            # Add a new bone collection
            bpy.ops.armature.collection_add()

            # Calculate the maximum row number among existing collections
            max_row = 0
            for collection in armature.data.collections_all.values():
                if "rig_ui_row" in collection:
                    max_row = max(max_row, collection["rig_ui_row"])

            # Set the row number of the new collection to max_row + 1
            new_collection = armature.data.collections[-1]  # Last collection is the new one
            new_collection["rig_ui_row"] = max_row + 1
            new_collection["rig_ui_pin"] = True

            # Refresh the UI list automatically
            bpy.ops.rig_ui.refresh_bc_list()

            # Trigger UI redraw
            refresh_ui(context)

            return {"FINISHED"}
        else:
            self.report({"ERROR"}, "Active object is not an armature.")
            return {"CANCELLED"}


class RIG_UI_OT_RemoveBoneCollection(bpy.types.Operator):
    """Removes the specified bone collection or the one at the active index and refreshes the UI."""

    bl_idname = "rig_ui.remove_bone_collection"
    bl_label = "Remove Bone Collection"

    collection_name: bpy.props.StringProperty(default="")

    def execute(self, context):
        armature = context.active_object

        # Ensure armature is valid and in ARMATURE type
        if armature and armature.type == "ARMATURE":
            # Use the provided collection name or fallback to the active index
            collection_to_remove = None
            if self.collection_name:
                collection_to_remove = armature.data.collections_all.get(self.collection_name)
            else:
                active_index = armature.data.active_bone_collection_index
                if 0 <= active_index < len(armature.data.bone_collection_properties):
                    collection_name = armature.data.bone_collection_properties[active_index].name
                    collection_to_remove = armature.data.collections_all.get(collection_name)

            if collection_to_remove:
                armature.data.collections.remove(collection_to_remove)

                # Refresh the UI list
                bpy.ops.rig_ui.refresh_bc_list()

                # Trigger UI redraw
                refresh_ui(context)

                return {"FINISHED"}
            else:
                self.report({"WARNING"}, "Bone collection not found.")
                return {"CANCELLED"}

        self.report({"ERROR"}, "Active object is not an armature.")
        return {"CANCELLED"}


class RIG_UI_UL_BoneCollections(bpy.types.UIList):
    """UI List to display and edit bone collection properties."""

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):

        armature = context.view_layer.objects.active

        element_name = armature.data.collections_all.get(item.name)

        if element_name:
            icon_name = element_name.get("icon_name", "BLANK1")

            row = layout.row(align=True)

            # Determine if this item is the active one in the list
            active_index = armature.data.active_bone_collection_index
            collection_icon = "LAYER_ACTIVE" if index == active_index else "LAYER_USED"
            row.label(text="", icon=collection_icon)

            rig_ui_pin = element_name.get("rig_ui_pin", False)

            # * rig_ui_pin toggle ----------------------------------------------

            ui_include_icon = "PINNED" if rig_ui_pin else "UNPINNED"
            row.prop(element_name, '["rig_ui_pin"]', icon=ui_include_icon, text="")

            # * Icon selection ----------------------------------------------

            icon_name = element_name.get("icon_name", "BLANK1")
            icon_selector_op = row.operator("rig_ui.icon_selector", text="", icon=icon_name)
            icon_selector_op.apply_context = "bone_collection"
            icon_selector_op.bone_collection_name = item.name

            # * Display Name ----------------------------------------------
            row.prop(
                element_name,
                '["display_name"]',
                text="",
                icon="FILE_TEXT",
                toggle=True,
            )

            # * Rest of the row for name, group, row, and priority ----------

            split_1 = row.split(factor=0.3)

            # split_1.prop(
            #     element_name,
            #     "name",
            #     text="",
            #     emboss=False,
            # )

            # Button to rename the collection
            rename_op = split_1.operator(
                "rig_ui.rename_bone_collection",
                text=element_name.name,
                emboss=False,
            )
            rename_op.collection_name = item.name

            sub_row = split_1.row(align=True)
            split_2 = sub_row.split(factor=0.5, align=True)

            # if PRO_VERSION:
            group_label = "Ungrouped"
            group_id = element_name.get("group_id", "NONE")
            for idx, group in enumerate(armature.data.bone_collections_ui_groups):
                if group.unique_id == group_id:
                    group_label = group.name
                    break

            # Button to open the pop-up menu for group selection
            select_group_op = split_2.operator("bonecollection.select_group", text=group_label)
            select_group_op.collection_name = item.name

            split_2.prop(element_name, '["rig_ui_row"]', text="")
            split_2.prop(element_name, '["rig_ui_priority"]', text="")

        else:
            # Handle the case when element_name is None
            row = layout.row(align=True)
            row.label(text=f"{element_name}: Collection not found", icon="ERROR")


class RIG_UI_OT_RenameBoneCollection(bpy.types.Operator):
    """Rename Bone Collection"""

    bl_idname = "rig_ui.rename_bone_collection"
    bl_label = "Rename Bone Collection"
    bl_options = {"UNDO"}

    collection_name: bpy.props.StringProperty()
    new_name: bpy.props.StringProperty(name="New Name")

    def execute(self, context):
        armature = context.view_layer.objects.active
        if armature and armature.type == "ARMATURE":
            collection = armature.data.collections_all.get(self.collection_name)
            if collection:
                collection.name = self.new_name
                bpy.ops.rig_ui.refresh_bc_list()
                return {"FINISHED"}
            else:
                self.report({"ERROR"}, "Collection not found.")
                return {"CANCELLED"}
        else:
            self.report({"ERROR"}, "Active object is not an armature.")
            return {"CANCELLED"}

    def invoke(self, context, event):
        armature = context.view_layer.objects.active
        if armature and armature.type == "ARMATURE":
            collection = armature.data.collections_all.get(self.collection_name)
            if collection:
                self.new_name = collection.name  # Pre-fill with the current name
            else:
                self.new_name = ""  # Clear the field if collection is not found
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.prop(self, "new_name", text="New Name")


class PRINT_OT_ArmatureJson(bpy.types.Operator):
    """Print JSON dictionary of the selected armature"""

    bl_idname = "print.armature_json"
    bl_label = "Print Armature JSON"

    def execute(self, context):
        armature = context.active_object
        if armature and armature.type == "ARMATURE":
            properties_dict = {}
            for collection in armature.data.collections_all.values():
                properties_dict[collection.name] = {
                    "rig_ui_pin": collection.get("rig_ui_pin", False),
                    "display_name": collection.get("display_name", True),
                    "rig_ui_row": collection.get("rig_ui_row", 1),
                    "rig_ui_priority": collection.get("rig_ui_priority", 1),
                    "icon_name": collection.get("icon_name", "BLANK1"),
                    "group_id": collection.get("group_id", "NONE"),
                }
            print(json.dumps(properties_dict, indent=4))
            return {"FINISHED"}
        else:
            self.report({"WARNING"}, "No active armature found")
            return {"CANCELLED"}


class RIG_UI_OT_EditBoneCollection(bpy.types.Operator):
    """Edit the properties of the selected bone collection"""

    bl_idname = "rig_ui.edit_bone_collection"
    bl_label = "Edit Bone Collection"
    bl_options = {"UNDO"}

    collection_name: bpy.props.StringProperty()

    def execute(self, context):
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        armature = context.view_layer.objects.active.data
        bone_collection = armature.collections_all.get(self.collection_name)
        if bone_collection:
            draw_bone_collection_item_expanded(self.layout, bone_collection, self.collection_name)
        else:
            self.layout.label(text="Reopen the bone collection to continue editing.", icon="INFO")


# List of classes in this module
classes = [
    RIG_UI_UL_BoneCollections,
    RIG_UI_OT_AddBoneCollection,
    RIG_UI_OT_RemoveBoneCollection,
    RIG_UI_OT_RenameBoneCollection,
    PRINT_OT_ArmatureJson,
    RIG_UI_OT_EditBoneCollection,
]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    # Register the properties
    bpy.types.Armature.active_bone_collection_index = bpy.props.IntProperty(name="Active Bone Layer Index")


def unregister():
    # Unregister the properties
    del bpy.types.Armature.active_bone_collection_index

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()

# End of boneCollections.py
# ------------------------------------------------------------------------ #
