# ------------------------------------------------------------------------ #
# Start of Rig_UI_customIcons.py
# This module contains the code for adding custom icons

import bpy
import os
from bpy.utils import previews
from . import utils

ADDON_NAME = __package__.split(".")[0]
PRO_VERSION = utils.check_pro_version()

# Define a global variable to store the custom icons
custom_icons = None


def load_icons():
    global custom_icons
    custom_icons = previews.new()

    # Define the folders within 'Rig_UI_assets' to search for icons
    icon_folders = ["addon_icons"]
    if PRO_VERSION:
        icon_folders.append("pro_icons")
    # icon_folders.append("yet_another_folder")

    # Get the directory of the current file
    addon_dir = os.path.dirname(os.path.dirname(__file__))

    # Iterate through each folder and load the icons
    for folder in icon_folders:
        folder_path = os.path.join(addon_dir, "Rig_UI_assets", folder)
        if os.path.exists(folder_path):
            for icon_file in os.listdir(folder_path):
                if icon_file.endswith(".png"):
                    icon_path = os.path.join(folder_path, icon_file)
                    icon_name = os.path.splitext(icon_file)[0]
                    custom_icons.load(icon_name, icon_path, "IMAGE")


def unload_icons():
    global custom_icons
    # Check if custom_icons is not None and has been properly loaded
    if custom_icons is not None:
        try:
            # Attempt to remove the custom icons safely
            bpy.utils.previews.remove(custom_icons)
            custom_icons = None  # Reset custom_icons to None after successful removal
        except Exception as e:
            # Handle exceptions (e.g., KeyError if icons are already removed or not found)
            print(f"Error unloading custom icons: {e}")


def get_custom_icons():
    global custom_icons
    return custom_icons if "custom_icons" in globals() and custom_icons is not None else None


def get_icon_id(icon_name):
    """Get the icon ID for a given icon name, handling both Blender and custom icons."""

    # Check if it's a Blender internal icon first
    if icon_name in bpy.types.UILayout.bl_rna.functions["prop"].parameters["icon"].enum_items.keys():
        return bpy.types.UILayout.bl_rna.functions["prop"].parameters["icon"].enum_items[icon_name].value
    # Then check for custom icons safely
    elif custom_icons is not None and icon_name in custom_icons:
        return custom_icons[icon_name].icon_id
    else:
        return bpy.types.UILayout.bl_rna.functions["prop"].parameters["icon"].enum_items["ERROR"].value


def get_icon(icon_name):
    """Get the appropriate icon parameters for a UI element."""
    # Assuming custom_icons is a dictionary of your custom icons
    if icon_name in custom_icons:
        # It's a custom icon, return icon ID
        return {"icon_value": custom_icons[icon_name].icon_id}
    else:
        # It's a Blender built-in icon, return icon name
        return {"icon": icon_name}


# ------------------------------Registration------------------------------ #

classes = []


def register():
    # Register other classes
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    # Unregister other classes
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()

# End of Rig_UI_customIcons.py
# ------------------------------------------------------------------------ #
