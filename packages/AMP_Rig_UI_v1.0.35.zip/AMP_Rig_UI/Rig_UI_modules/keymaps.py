# Rig_UI_keymaps.py
# Key maps for the addon

import bpy

# Global dictionary to keep track of keymaps
addon_keymaps = {}


def register_keymaps():
    kc = bpy.context.window_manager.keyconfigs.addon
    if kc:
        # Keymap for 3D View
        km = kc.keymaps.new(name="3D View", space_type="VIEW_3D", region_type="WINDOW")

        # Keymap for toggling bone collections move
        kmi_collections = km.keymap_items.new(
            "rig_ui.toggle_move_bone_collections_active",
            "M",
            "PRESS",
            shift=True,
            ctrl=False,
            alt=False,
            oskey=False,
            repeat=False,
        )
        addon_keymaps["toggle_move_bone_collections"] = (km, kmi_collections)

        # Keymap for opening the Rig UI pop-up panel
        kmi_pop_up_panel = km.keymap_items.new(
            "wm.call_panel",
            "Y",
            "PRESS",
            shift=True,
            ctrl=False,
            alt=False,
            oskey=False,
            repeat=False,
        )
        kmi_pop_up_panel.properties.name = "RIG_UI_PT_openPopUp"
        addon_keymaps["open_rig_ui_panel"] = (km, kmi_pop_up_panel)


def unregister_keymaps():
    # Keymap unregistration
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()


def register():
    register_keymaps()


def unregister():
    unregister_keymaps()


# ------------------------------------------------------------------------ #
