# ------------------------------------------------------------------------ #
# Rig_UI_popUpPanel.py
# This module contains the code for the pop up panel logic for the Rig UI

import bpy

from .userInterface import draw_rig_ui_panel


class RIG_UI_PT_openPopUp(bpy.types.Panel):
    """Rig UI pop-up panel"""

    bl_idname = "RIG_UI_PT_openPopUp"
    bl_label = "Toggle Rig UI Pop-Up"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_context = ""
    bl_order = 0
    bl_options = {"HIDE_HEADER"}
    bl_ui_units_x = 15

    @classmethod
    def poll(cls, context):
        return True

    def invoke(self, context, event):
        context.window_manager.invoke_props_dialog(self, width=300)

    # def draw_header_main_ui(self, context):
    #     layout = self.layout

    def draw(self, context):
        draw_rig_ui_panel(self, self.layout, context)


def register_pop_up_panel_properties():
    pass


def unregister_pop_up_panel_properties():
    pass


classes = [
    RIG_UI_PT_openPopUp,
]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    register_pop_up_panel_properties()


def unregister():
    unregister_pop_up_panel_properties()
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()


# ------------------------------------------------------------------------ #
