# ------------------------------------------------------------------------ #
# userInterface.py
# Script for the user interface of the Rig UI addon


import bpy
import json

from .. import bl_info as addon_info

ADDON_VERSION = ".".join(map(str, addon_info["version"]))

from .boneCollections import (
    draw_bc_setup_list,
    draw_bc_main_ui,
    restore_bc_props_from_json,
    on_collection_name_update,
)
from .userInterfaceHeader import draw_header_main_ui
from .utils import (
    refresh_ui,
    save_bc_props_to_json,
    restore_bc_props_from_json,
    update_edit_mode,
    update_bone_collections,
    check_for_rigify_uid_in_collections,
)
from .customIcons import get_icon, get_icon_id

from . import utils

ADDON_NAME = __package__.split(".")[0]
PRO_VERSION = utils.check_pro_version()

if PRO_VERSION:
    from ..Rig_UI_pro_modules.pro_rigify_panel import draw_rigify_panel_main_ui
    from ..Rig_UI_pro_modules.pro_autorig_pro_panel import (
        draw_autorig_pro_panel_main_ui,
    )
    from ..Rig_UI_pro_modules.pro_rig_custom_properties import (
        draw_bone_custom_properties_setup,
        draw_cp_main_ui,
    )
    from ..Rig_UI_pro_modules.pro_custom_bone_properties_panel import (
        draw_blender_properties_panel_main_ui,
    )
    from ..Rig_UI_pro_modules.pro_visibility_bookmarks import (
        draw_vb_main_ui,
        draw_visibility_bookmarks_setup,
    )
    from ..Rig_UI_pro_modules.pro_utils import (
        draw_armature_extras_main_ui,
        draw_ui_extras_main_ui,
    )
else:

    def draw_armature_extras_main_ui(layout, context):
        pass

    def draw_visibility_bookmarks_setup(layout, context):
        pass

    def draw_vb_main_ui(layout, context):
        pass

    def draw_rigify_panel_main_ui(layout, context):
        pass

    def draw_blender_properties_panel_main_ui(layout, context):
        pass

    def draw_autorig_pro_panel_main_ui(layout, context):
        pass

    def draw_bone_custom_properties_setup(layout, context):
        pass

    def draw_cp_main_ui(layout, context):
        pass

    def draw_ui_extras_main_ui(layout, context):
        pass


# current_edit_armature_name = ""

# Define a global variable to store the mouse modifiers
_mouse_modifiers = []


class RIGUI_OT_get_mouse_event(bpy.types.Operator):
    bl_idname = "rig_ui.get_mouse_modifiers"
    bl_label = ""
    bl_description = "Get the mouse modifiers"

    def invoke(self, context, event):
        global _events
        _events = []

        if event.ctrl:
            _mouse_modifiers.append("CTRL")
        if event.shift:
            _mouse_modifiers.append("SHIFT")
        if event.alt:
            _mouse_modifiers.append("ALT")
        if event.oskey:
            _mouse_modifiers.append("OS")

        return {"FINISHED"}


def draw_rig_ui_main_setup(layout, context):
    # global current_edit_armature_name
    scene = context.scene
    armature = context.active_object
    addon_prefs = bpy.context.preferences.addons[ADDON_NAME].preferences

    # Check if the active object is an armature
    if armature and armature.type == "ARMATURE":
        text = "Edit Mode"
        # Check if the current armature is different from the one in edit mode
        # if (
        # armature and armature.name != current_edit_armature_name
        # ) or
        # if not scene.rig_ui_edit_mode:
        #     # Display a button for toggling edit mode
        #     edit_mode_row = layout.row()
        #     edit_mode_row.operator("rig_ui.toggle_edit_mode", text=text, icon=icon)
        # else:

        # Additional UI elements based on edit mode state
        section_container = layout.column(align=True)

        edit_mode_row = section_container.row()
        edit_mode_row.alert = scene.rig_ui_edit_mode
        edit_mode_row.prop(
            scene,
            "rig_ui_edit_mode",
            toggle=True,
            text=text,
            **get_icon("Edit_prop"),
            emboss=not scene.rig_ui_edit_mode,
        )
        if scene.rig_ui_edit_mode:
            sections_row = layout.row(align=True)
            sections_row.prop(addon_prefs, "edit_mode_sections", expand=True)

            # Display the selected section
            if addon_prefs.edit_mode_sections == "GENERAL_OPTIONS":
                draw_rig_ui_general_settings_setup(layout, context)
            elif addon_prefs.edit_mode_sections == "BONE_COLLECTIONS":
                draw_bc_setup_list(layout, context)
            elif addon_prefs.edit_mode_sections == "VISIBILITY_BOOKMARKS":
                draw_visibility_bookmarks_setup(layout, context, armature)
            elif addon_prefs.edit_mode_sections == "CUSTOM_PROPERTIES":
                draw_bone_custom_properties_setup(context, layout, armature)
    else:
        layout.label(text="Select an Armature for Rig UI Setup.")


def draw_rig_ui_preview_panel(self, layout, context):
    scene = context.scene
    armature = context.view_layer.objects.active
    props = armature.data.rig_ui_props if armature and armature.type == "ARMATURE" else None
    # Collapsible Rig UI Preview section
    if props and hasattr(props, "show_rig_ui_preview"):
        box = layout.box()
        row = box.row()
        row.prop(
            props,
            "show_rig_ui_preview",
            icon="TRIA_DOWN" if props.show_rig_ui_preview else "TRIA_RIGHT",
            emboss=False,
            text="Rig UI Preview",
        )
        row.scale_y = 0.5  # 1 if props.show_rig_ui_preview else 0.5
        if props.show_rig_ui_preview:
            draw_rig_ui_panel(self, layout, context)


def draw_rig_ui_general_settings_setup(layout, context):
    scene = context.scene
    armature = context.view_layer.objects.active
    prefs = bpy.context.preferences.addons[ADDON_NAME].preferences
    props = armature.data.rig_ui_props if armature and armature.type == "ARMATURE" else None

    # if props and hasattr(props, "show_rig_ui_edit_mode_general"):
    #     box = layout.box()
    #     row = box.row()
    #     row.prop(
    #         props,
    #         "show_rig_ui_edit_mode_general",
    #         icon="TRIA_DOWN" if props.show_rig_ui_edit_mode_general else "TRIA_RIGHT",
    #         emboss=False,
    #         text="General Options",
    #     )
    #     row.scale_y = 0.5

    #     if props.show_rig_ui_edit_mode_general:
    # container = box.row()
    container = layout.row()

    # * Left Column ----------------------------------------------------------

    left_column = container.column(align=True)
    left_column.label(text="Options")

    # Display sidepanel name field, and refresh button
    sidePanel_box = left_column.box()
    sidePanel_row = sidePanel_box.row()
    split = sidePanel_row.split(factor=0.4)
    split.label(text="Sidebar")
    split.prop(prefs, "rig_ui_sidepanel_location", text="")
    sidePanel_row.operator("rig_ui.redraw_panels", text="", **get_icon("Refresh"))

    left_column.separator(factor=1)

    left_column.label(text="Generate Rig UI")
    # Import from collections
    generate_box = left_column.box()
    generate_container = generate_box.column(align=True)

    generate_container.label(text="Bone Collections")
    import_from_bc = generate_container.box()
    import_from_bc.row().operator(
        "rig_ui.import_ui_from_bc",
        text="From Collections",
        icon="OUTLINER_COLLECTION",
    )
    generate_container.separator()
    # Rigify my Rig UI button, if applicable
    generate_container.label(text="Rigify")
    Rigify_box = generate_container.box()
    if check_for_rigify_uid_in_collections(armature):
        Rigify_box.row().operator(
            "rig_ui.rigify_my_rig_ui",
            text="Rigify my Rig UI",
            icon="ARMATURE_DATA",
        )

        # Re generate Rig UI, if applicable
        Rigify_box.row().operator(
            "rig_ui.regenerate_rigify_rig_ui",
            text="Re-Generate Rig",
            icon="POSE_HLT",
        )
    else:
        Rigify_box.label(text="Select a Rigify Rig")

    generate_container.separator()

    # AutoRigPro my Rig UI button, if applicable
    generate_container.label(text="Auto-Rig Pro")
    ARP_box = generate_container.box()
    if "arp_updated" in armature.data:
        ARP_box.label(text="ARP my Rig UI (soon)", icon="ERROR")
    else:
        ARP_box.label(text="Select an Auto-Rig Pro Rig")
        # Rigify_box.row().operator(
        #     "rig_ui.rigify_my_rig_ui",
        #     text="Rigify my Rig UI",
        #     icon="ARMATURE_DATA",
        # )

    left_column.separator(factor=1)

    if PRO_VERSION:
        # Export Label and button
        left_column.label(text="Export UI Script")
        Expoprt_box = left_column.box()
        Expoprt_row = Expoprt_box.row()
        Expoprt_row.row().label(text="Export Universal UI", **get_icon("OUTLINER_OB_POINTCLOUD"))
        Expoprt_row.row().operator("rig_ui.export_rig_ui", text="", **get_icon("Export")).export_generic_ui = True
        Expoprt_row2 = Expoprt_box.row()
        Expoprt_row2.row().label(text="Export Current Armature UI", **get_icon("POINTCLOUD_POINT"))
        Expoprt_row2.row().operator("rig_ui.export_rig_ui", text="", **get_icon("Export"))

        left_column.separator(factor=1)

        left_column.label(text="Transfer UI Setup")
        Transfer_box = left_column.box()
        row = Transfer_box.row()
        row.label(text="Export Rig UI Setup", icon="PRESET")
        row.operator("rig_ui.export_setup", text="", **get_icon("Export"))
        row = Transfer_box.row()
        row.label(text="Import Rig UI Setup", icon="PRESET_NEW")
        row.operator("rig_ui.import_setup", text="", **get_icon("Import"))

        left_column.separator(factor=1)

    # Clear Rig UI button
    left_column.label(text="Clear Rig UI")
    sidePanel_box = left_column.box()
    sidePanel_box.row().operator(
        "rig_ui.remove_rig_ui_from_armature",
        text="Delete Rig UI",
        icon="TRASH",
    )

    left_column.separator(factor=1)

    if PRO_VERSION:
        left_column.label(text="Modules Order")

        # Display the UI List for module order
        row = left_column.row(align=True)
        row.template_list(
            "RIG_UI_UL_ModulesOrder_items",
            "",
            armature.data,
            "rig_ui_list",
            armature.data,
            "active_rig_ui_list_index",
            rows=9,
        )

        col = row.column(align=True)
        col.operator("rig_ui.move_module_item", **get_icon("Up"), text="").direction = "UP"
        col.operator("rig_ui.move_module_item", **get_icon("Down"), text="").direction = "DOWN"
    else:
        layout.label(text="No Armature Selected.")

    # right_column = container.column(align=True)

    # *  Right column ----------------------------------------------------------


def draw_rig_ui_addon_modules_list(layout, armature):
    if armature and hasattr(armature.data, "rig_ui_list"):
        for item in armature.data.rig_ui_list:
            row = layout.row()
            row.label(text=item.name)


def draw_rig_ui_panel(self, layout, context):
    armature = context.view_layer.objects.active
    scene = context.scene

    if armature and armature.type == "ARMATURE":
        # Check for rig_ui_version custom property
        rig_ui_version = armature.data.get("rig_ui_version", None)

        # Convert versions to integers for comparison
        current_version_int = int(ADDON_VERSION.replace(".", ""))
        rig_ui_version_int = int(rig_ui_version.replace(".", "")) if rig_ui_version else 0

        if rig_ui_version_int < current_version_int:
            row = layout.row()
            row.alert = scene.rig_ui_edit_mode
            row.prop(
                scene,
                "rig_ui_edit_mode",
                toggle=True,
                text="Click to Update the Rig",
                icon="FILE_REFRESH",
                emboss=not scene.rig_ui_edit_mode,
            )
            row = layout.row()
            row.label(text="The current rig needs to be", icon="ERROR")
            row = layout.row()
            row.label(text="updated, please refresh.")
            return  # Exit early if the version is incorrect

        if rig_ui_version_int > current_version_int:
            row = layout.row()
            row.label(text="Your Rig UI addon is out of date,", icon="ERROR")
            row = layout.row()
            row.label(text="the current rig was made with a newer")
            row = layout.row()
            row.label(text="version of the addon.")
            row = layout.row()
            row.label(text="Please update to the latest version.")
            return  # Exit early if the version is incorrect

        props = armature.data.rig_ui_props
        prefs = bpy.context.preferences.addons[ADDON_NAME].preferences

        section_headers = prefs.RIG_UI_section_headers
        config_mode = prefs.RIG_UI_config_mode
        section_background = prefs.RIG_UI_section_boxes

        def draw_header_section(layout, context):
            draw_header_main_ui(layout, context)

        def draw_bone_collections_section(layout, context):
            if prefs.RIG_UI_bone_collections:
                container = layout.box() if section_background else layout.column()
                if section_headers or config_mode:
                    header_row = container.row()
                    header_row.label(text="Bone Collections")
                    header_row.scale_y = 0.4
                    if config_mode:
                        draw_config_buttons(header_row, "bone_collections")
                column = container.column(align=props.bone_collections_cozy_vertical)
                draw_bc_main_ui(column, context)

        def draw_visibility_bookmarks_section(layout, context):
            if PRO_VERSION:
                if prefs.RIG_UI_visibility_bookmarks:
                    container = layout.box() if section_background else layout.column()
                    if section_headers or config_mode:
                        header_row = container.row()
                        header_row.label(text="Visibility Bookmarks")
                        header_row.scale_y = 0.4
                        if config_mode:
                            draw_config_buttons(header_row, "visibility_bookmarks")
                    column = container.column(align=True)
                    draw_vb_main_ui(column, context, armature)

        def draw_custom_properties_section(layout, context):
            if PRO_VERSION:
                if prefs.RIG_UI_custom_properties:
                    container = layout.box() if section_background else layout.column()
                    if section_headers or config_mode:
                        header_row = container.row()
                        header_row.label(text="Control panel")
                        header_row.scale_y = 0.4
                        if config_mode:
                            draw_config_buttons(header_row, "custom_properties")
                    column = container.column(align=True)
                    draw_cp_main_ui(column, context)

        def draw_armature_extras_section(layout, context):
            if PRO_VERSION:
                if prefs.RIG_UI_extras_display:
                    container = layout.column()
                    if section_headers or config_mode:
                        Armature_extraes_row = container.row()
                        Armature_extraes_row.label(text="Armature Extras")
                        Armature_extraes_row.scale_y = 0.4
                    draw_armature_extras_main_ui(self, container, context)

        def draw_ui_extras_section(layout, context):
            if PRO_VERSION:
                if prefs.RIG_UI_ui_extras_display:
                    container = layout.column()
                    if section_headers or config_mode:
                        UI_extraes_row = container.row()
                        UI_extraes_row.label(text="UI Extras")
                        UI_extraes_row.scale_y = 0.4
                    draw_ui_extras_main_ui(self, container, context)

        def draw_autorig_pro_section(layout, context):
            if PRO_VERSION:
                if props.rig_ui_extras_autorig_pro_display or config_mode:
                    container = layout.column()
                    draw_autorig_pro_panel_main_ui(container, context)

        # Nested function for drawing Rigify panel section
        def draw_rigify_panel_section(layout, context):
            if PRO_VERSION:
                if props.rig_ui_extras_rigify_display or config_mode:
                    container = layout.column()
                    draw_rigify_panel_main_ui(container, context)

        # Nested function for drawing custom bone properties section
        def draw_custom_bone_properties_section(layout, context):
            if PRO_VERSION:
                if props.rig_ui_extras_custom_bone_properties_display or config_mode:
                    container = layout.column()
                    draw_blender_properties_panel_main_ui(container, context)

        if "rig_ui_list" in armature.data:
            for item in armature.data.rig_ui_list:
                if item.draw_function_name == "draw_header_section":
                    draw_header_section(layout, context)
                elif item.draw_function_name == "draw_bone_collections_section":
                    draw_bone_collections_section(layout, context)
                elif item.draw_function_name == "draw_visibility_bookmarks_section":
                    draw_visibility_bookmarks_section(layout, context)
                elif item.draw_function_name == "draw_custom_properties_section":
                    draw_custom_properties_section(layout, context)
                elif item.draw_function_name == "draw_armature_extras_section":
                    draw_armature_extras_section(layout, context)
                elif item.draw_function_name == "draw_ui_extras_section":
                    draw_ui_extras_section(layout, context)
                elif item.draw_function_name == "draw_autorig_pro_section":
                    draw_autorig_pro_section(layout, context)
                elif item.draw_function_name == "draw_rigify_panel_section":
                    draw_rigify_panel_section(layout, context)
                elif item.draw_function_name == "draw_custom_bone_properties_section":
                    draw_custom_bone_properties_section(layout, context)
        else:
            layout.label(text="UI List not initialized.")
            draw_header_section(layout, context)
            draw_armature_extras_section(layout, context)
            draw_ui_extras_section(layout, context)
            draw_bone_collections_section(layout, context)
            draw_visibility_bookmarks_section(layout, context)
            draw_custom_properties_section(layout, context)
    else:
        layout.label(text="No Armature Selected.")


def draw_config_buttons(layout, section_name=""):
    current_mode = bpy.context.preferences.addons[ADDON_NAME].preferences.Rig_UI_element_mode

    edit_elements_row = layout.row(align=True)
    edit_elements_row.scale_y = 2.5

    if section_name == "custom_properties":
        edit_elements_row.operator("rig_ui.delete_bone_custom_props_by_string", **get_icon("Clean"), text="")

        edit_elements_row.operator("rig_ui.edit_keyword_filter", text="", **get_icon("Filter"))

        edit_elements_row.separator()

    # Add element button if Add/Remove mode is active
    if current_mode == "ADD_REMOVE":
        add_op = edit_elements_row.operator(
            "rig_ui.add_element",
            text="",
            **get_icon("Add"),
            emboss=True,
        )
        add_op.section_name = section_name
        edit_elements_row.separator(factor=0.5)
    # Add/Remove button
    add_remove_row = edit_elements_row.row(align=True)
    add_remove_row.active = current_mode == "ADD_REMOVE"
    add_remove_op = add_remove_row.operator(
        "rig_ui.toggle_enum_property",
        text="",
        **get_icon("Add_Remove"),
        emboss=False,
    )
    add_remove_op.enum_path = f"context.preferences.addons['{ADDON_NAME}'].preferences.Rig_UI_element_mode"
    add_remove_op.enum_value = "ADD_REMOVE"

    # Pin button
    pin_row = edit_elements_row.row(align=True)
    pin_row.active = current_mode == "PIN"
    pin_op = pin_row.operator(
        "rig_ui.toggle_enum_property",
        text="",
        **get_icon("Pinned"),
        emboss=False,
    )
    pin_op.enum_path = f"context.preferences.addons['{ADDON_NAME}'].preferences.Rig_UI_element_mode"
    pin_op.enum_value = "PIN"

    # Edit button
    edit_row = edit_elements_row.row(align=True)
    edit_row.active = current_mode == "EDIT"

    edit_op = edit_row.operator(
        "rig_ui.toggle_enum_property",
        text="",
        **get_icon("Edit_prop"),
        emboss=False,
    )
    edit_op.enum_path = f"context.preferences.addons['{ADDON_NAME}'].preferences.Rig_UI_element_mode"
    edit_op.enum_value = "EDIT"

    # Scale UI
    scale_ui_row = edit_elements_row.row(align=True)
    scale_ui_row.active = current_mode == "UI_SCALE"

    scale_ui_op = scale_ui_row.operator(
        "rig_ui.toggle_enum_property",
        text="",
        # **get_icon("Edit_prop"),
        icon="ARROW_LEFTRIGHT",
        emboss=False,
    )
    scale_ui_op.enum_path = f"context.preferences.addons['{ADDON_NAME}'].preferences.Rig_UI_element_mode"
    scale_ui_op.enum_value = "UI_SCALE"

    # Move button
    move_row = edit_elements_row.row(align=True)
    move_row.active = current_mode == "MOVE"
    move_op = move_row.operator(
        "rig_ui.toggle_enum_property",
        text="",
        **get_icon("Move_on"),
        emboss=False,
    )
    move_op.enum_path = f"context.preferences.addons['{ADDON_NAME}'].preferences.Rig_UI_element_mode"
    move_op.enum_value = "MOVE"


class RIG_UI_List_Item(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty()
    draw_function_name: bpy.props.StringProperty()

    def draw(self, layout, context):
        if hasattr(bpy.types, self.draw_function_name):
            draw_func = getattr(bpy.types, self.draw_function_name)
            draw_func(layout, context)


class RIG_UI_OT_modulesOrderItem(bpy.types.Operator):
    """Move an item in the UI list up or down"""

    bl_idname = "rig_ui.move_list_item"
    bl_label = "Move List Item"

    direction: bpy.props.EnumProperty(items=[("UP", "Up", ""), ("DOWN", "Down", "")])
    index: bpy.props.IntProperty()

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == "ARMATURE"

    def execute(self, context):
        armature = context.active_object.data
        list = armature.rig_ui_list

        if self.direction == "UP" and self.index > 0:
            list.move(self.index, self.index - 1)
        elif self.direction == "DOWN" and self.index < len(list) - 1:
            list.move(self.index, self.index + 1)

        return {"FINISHED"}


class RIG_UI_BoneCollectionsProperties(bpy.types.PropertyGroup):
    """Property group for bone collection properties."""

    rig_ui_pin: bpy.props.BoolProperty(
        name="Pin",
        default=False,
    )

    rig_ui_row: bpy.props.IntProperty(
        name="Row",
        default=1,
        min=1,
    )

    unique_id: bpy.props.StringProperty(name="Unique ID", description="Unique ID for each bone collection")

    rig_ui_priority: bpy.props.IntProperty(
        name="Priority",
        default=1,
        min=1,
    )

    button_factor: bpy.props.FloatProperty(
        name="Button Factor",
        default=1,
        min=1,
        max=4,
        description="Adjust the button ui size",
    )

    group_id: bpy.props.StringProperty(name="Group ID", description="Unique identifier of the associated group")
    selected_icon: bpy.props.StringProperty(name="Selected Icon", default="BLANK1")

    icon_name: bpy.props.StringProperty(name="Icon Name", default="BLANK1")

    display_name: bpy.props.BoolProperty(name="Display Name", default=True)

    bc_display_name: bpy.props.StringProperty(
        name="Bone Collection Name",
        # update=on_collection_name_update,
    )

    is_separator: bpy.props.BoolProperty(
        name="""Use as a UI separator, it will appear empty in the UI, but you
will still be able to change its width.""",
        default=False,
    )


class RIG_UI_ArmatureProperties(bpy.types.PropertyGroup):
    """Armature level property group."""

    show_rig_ui_preview: bpy.props.BoolProperty(
        name="Show Rig UI Preview",
        description="Toggle to show or hide the Rig UI Preview",
        default=False,
        override={"LIBRARY_OVERRIDABLE"},
    )

    show_rig_ui_edit_mode_general: bpy.props.BoolProperty(
        name="Show General Options",
        description="Toggle to show or hide the General Options in Edit Mode",
        default=False,
        override={"LIBRARY_OVERRIDABLE"},
    )

    rig_ui_move_bone_collections_active: bpy.props.BoolProperty(
        name="Move Bone to Collections",
        description="Toggle to activate moving bones between collections",
        default=False,
        override={"LIBRARY_OVERRIDABLE"},
    )

    rig_ui_highlight_active_bc: bpy.props.BoolProperty(
        name="Highlight Active Layer",
        description="Highlight the layer with the currently selected bone",
        default=True if PRO_VERSION else False,
        override={"LIBRARY_OVERRIDABLE"},
    )

    rig_ui_fade_non_current_bc: bpy.props.BoolProperty(
        name="Fade out while moving",
        description="""Fade buttons for collections that don't contain the current bone
        while the move bone collections is active""",
        default=True,
        override={"LIBRARY_OVERRIDABLE"},
    )

    # Enum items for unpinned collection visibility options
    hidden_collections_visibility_items = [
        (
            "NEVER",
            "Never",
            "Never show unpinned collections in Rig UI",
            "RADIOBUT_OFF",
            0,
        ),
        (
            "ALWAYS",
            "Always",
            "Always show unpinned collections in Rig UI",
            "RADIOBUT_ON",
            1,
        ),
        (
            "ON_MOVE",
            "On Move",
            "Show unpinned collections in Rig UI when moving bones",
            "ONIONSKIN_ON",
            2,
        ),
    ]

    rig_ui_show_hidden_mode: bpy.props.EnumProperty(
        name="Unpinned visibility",
        description="Control the visibility of unpinned collections in Rig UI",
        items=hidden_collections_visibility_items,
        default="ON_MOVE",
        override={"LIBRARY_OVERRIDABLE"},
    )

    group_headers_boneCollections: bpy.props.BoolProperty(
        name="Toggle Group Headers",
        description="Hide or display the Groups Headers for the Bone Collections",
        default=True,
        override={"LIBRARY_OVERRIDABLE"},
    )

    group_headers_visibilityBookmarks: bpy.props.BoolProperty(
        name="Toggle Group Headers",
        description="Hide or display the Groups Headers for the Visibility Bookmarks",
        default=True,
        override={"LIBRARY_OVERRIDABLE"},
    )

    group_headers_customProperties: bpy.props.BoolProperty(
        name="Toggle Group Headers",
        description="Hide or display the Groups Headers for the Custom Properties",
        default=True,
        override={"LIBRARY_OVERRIDABLE"},
    )

    bone_collections_cozy_vertical: bpy.props.BoolProperty(
        name="Cozy/Compact horizontal UI",
        description="Toggle between compact horizontal alignment of Visibility Bookmarks UI",
        default=True,
        override={"LIBRARY_OVERRIDABLE"},
    )

    bone_collections_cozy_horizontal: bpy.props.BoolProperty(
        name="Cozy/Compact horizontal UI",
        description="Toggle between compact horizontal alignment bone collection UI",
        default=True,
        override={"LIBRARY_OVERRIDABLE"},
    )

    visibility_bookmarks_cozy_vertical: bpy.props.BoolProperty(
        name="Cozy/Compact vertical UI",
        description="Toggle between compact vertical alignment of Visibility Bookmarks UI",
        default=True,
        override={"LIBRARY_OVERRIDABLE"},
    )

    visibility_bookmarks_cozy_horizontal: bpy.props.BoolProperty(
        name="Cozy/Compact horizontal UI",
        description="Toggle between compact horizontal alignment of Visibility Bookmarks UI",
        default=True,
        override={"LIBRARY_OVERRIDABLE"},
    )

    custom_properties_cozy_vertical: bpy.props.BoolProperty(
        name="Cozy/Compact vertical UI",
        description="Toggle between compact vertical alignment of Custom Properties UI",
        default=True,
        override={"LIBRARY_OVERRIDABLE"},
    )

    custom_properties_cozy_horizontal: bpy.props.BoolProperty(
        name="Cozy/Compact horizontal UI",
        description="Toggle between compact horizontal alignment of Custom Properties UI",
        default=True,
        override={"LIBRARY_OVERRIDABLE"},
    )

    bone_collections_grey_out_unpinned: bpy.props.BoolProperty(
        name="Grey out unpinned",
        description="Toggle greying out of unpinned bone collections",
        default=True,
        override={"LIBRARY_OVERRIDABLE"},
    )

    bone_collection_options_display: bpy.props.BoolProperty(
        name="Options",
        description="Pin the bone collection options to the panel",
        default=True if PRO_VERSION else False,
        override={"LIBRARY_OVERRIDABLE"},
    )

    filter_custom_bone_properties: bpy.props.StringProperty(
        name="Filter Custom Properties",
        description="Filter the custom properties based on space separated names",
        default="",
        override={"LIBRARY_OVERRIDABLE"},
    )

    # show_bone_collections: bpy.props.BoolProperty(
    #     name="Show Bone Collections", default=True
    # )

    # rig_ui_custom_properties_groups_spacing = bpy.props.FloatProperty(
    #     name="Groups Spacing",
    #     description="Adjust the spacing between groups in custom properties",
    #     default=0.1,
    #     min=0.0,
    #     max=1.0,
    # )

    # rig_ui_ui_groups_spacing = bpy.props.FloatProperty(
    #     name="Groups Spacing",
    #     description="Adjust the spacing between groups in bone collections",
    #     default=0.0,
    #     min=0.0,
    #     max=1.0,
    # )

    rig_ui_setup_boneCollectionsgroup_collapsed: bpy.props.BoolProperty(
        name="Toggle  Group",
        description="Toggle the Bone Collections Group panel",
        default=False,
        override={"LIBRARY_OVERRIDABLE"},
    )
    # Only creates these properties if in the PRO_VERSION
    if PRO_VERSION:
        visibility_bookmarks_display: bpy.props.BoolProperty(
            name="Bookmarks",
            description="Pin the visibility bookmarks to the panel",
            default=False,
            override={"LIBRARY_OVERRIDABLE"},
        )

        visibility_bookmarks_at_top: bpy.props.BoolProperty(
            name="Move bookmarks top/bottom",
            description="Move the visibility bookmarks to the top or the bottom of the panel",
            default=True,
            override={"LIBRARY_OVERRIDABLE"},
        )
        show_visibility_bookmarks: bpy.props.BoolProperty(
            name="Show Visibility Bookmarks",
            default=False,
            override={"LIBRARY_OVERRIDABLE"},
        )
        visibility_bookmarks_row_pinned: bpy.props.BoolProperty(
            name="Visibility Bookmarks Row Pinned",
            description="Pin the visibility bookmarks row to the panel",
            default=False,
            override={"LIBRARY_OVERRIDABLE"},
        )
        visibility_bookmarks_index: bpy.props.IntProperty()
        rig_ui_extras_rigify_collapsed: bpy.props.BoolProperty(
            name="Toggle Rigify",
            description="Toggle the Rigify panel",
            default=True,
            override={"LIBRARY_OVERRIDABLE"},
        )
        show_custom_properties: bpy.props.BoolProperty(
            name="Show Custom Properties",
            default=False,
            override={"LIBRARY_OVERRIDABLE"},
        )
        rig_ui_extras_custom_bone_properties_collapsed: bpy.props.BoolProperty(
            name="Toggle Custom Bone Properties",
            description="Toggle the Custom Bone Properties panel",
            default=True,
            override={"LIBRARY_OVERRIDABLE"},
        )
        rig_ui_extras_autorig_pro_collapsed: bpy.props.BoolProperty(
            name="Toggle AutoRig Pro",
            description="Toggle the AutoRig Pro panel",
            default=True,
            override={"LIBRARY_OVERRIDABLE"},
        )
        rig_ui_extras_custom_bone_properties_display: bpy.props.BoolProperty(
            name="Display Custom Bone Properties",
            description="Pin the custom bone properties panel to the the UI",
            default=False,
            override={"LIBRARY_OVERRIDABLE"},
        )

        rig_ui_extras_rigify_display: bpy.props.BoolProperty(
            name="Display Riggify",
            description="Pin the Rigify panel to the the UI",
            default=False,
            override={"LIBRARY_OVERRIDABLE"},
        )

        rig_ui_extras_autorig_pro_display: bpy.props.BoolProperty(
            name="Display AutoRig Pro",
            description="Pin the AutRig Pro panel to the the UI",
            default=False,
            override={"LIBRARY_OVERRIDABLE"},
        )

        rig_ui_setup_customProperties_group_collapsed: bpy.props.BoolProperty(
            name="Toggle Group",
            description="Toggle the Custom Properties Group panel",
            default=False,
            override={"LIBRARY_OVERRIDABLE"},
        )


class RIG_UI_OT_UpdatePanels(bpy.types.Operator):
    """Update the sidepanel for the Rig UI panel"""

    bl_idname = "rig_ui.update_panels"
    bl_label = "Update sidepanel"

    def execute(self, context):
        armature = context.view_layer.objects.active
        if armature and armature.type == "ARMATURE":
            unregister_panels()
            register_panels()
        return {"FINISHED"}


class RIG_UI_PT_BoneCollectionsSetup(bpy.types.Panel):
    """Panel for managing Rig UI"""

    bl_label = "Rig UI Setup"
    bl_idname = "RIG_UI_PT_BoneCollectionsSetup"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    # bl_category = bpy.context.preferences.addons[
    #     ADDON_NAME
    # ].preferences.rig_ui_setup_sidepanel_location

    def draw(self, context):
        container = self.layout.column(align=True)
        draw_rig_ui_main_setup(container, context)
        draw_rig_ui_preview_panel(self, container, context)


class RIG_UI_PT_BoneCollectionsSidePanel(bpy.types.Panel):
    """Panel for displaying Rig UI in the side panel"""

    bl_label = "Rig UI"
    bl_idname = "RIG_UI_PT_BoneCollectionsSidePanel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    # bl_category = bpy.context.preferences.addons[
    #     ADDON_NAME
    # ].preferences.rig_ui_sidepanel_location

    def draw(self, context):
        draw_rig_ui_panel(self, self.layout, context)


class RIG_UI_PT_BoneCollectionsPropertiesPanel(bpy.types.Panel):
    """Panel for displaying Rig UI in the properties panel"""

    bl_label = "Rig UI Properties"
    bl_idname = "RIG_UI_PT_BoneCollectionsPropertiesPanel"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "data"
    bl_category = "Rig UI"

    def draw(self, context):
        draw_rig_ui_panel(self, self.layout, context)


class RIG_UI_OT_RefreshBCList(bpy.types.Operator):
    """Refresh Bone Collections Setup and UI Lists"""

    bl_idname = "rig_ui.refresh_bc_list"
    bl_label = "Refresh Rig UI List"

    def execute(self, context):
        armature = context.view_layer.objects.active
        if armature and armature.type == "ARMATURE":
            save_bc_props_to_json(armature)
            update_edit_mode(self, context)
        return {"FINISHED"}


class RIG_UI_OT_AddModuleItem(bpy.types.Operator):
    bl_idname = "rig_ui.add_module_item"
    bl_label = "Add Module Item"

    def execute(self, context):
        armature = context.active_object.data
        armature.rig_ui_list.add()
        return {"FINISHED"}


class RIG_UI_OT_RemoveModuleItem(bpy.types.Operator):
    bl_idname = "rig_ui.remove_module_item"
    bl_label = "Remove Module Item"

    def execute(self, context):
        armature = context.active_object.data
        index = armature.active_rig_ui_list_index
        armature.rig_ui_list.remove(index)
        return {"FINISHED"}


class RIG_UI_OT_MoveModuleItem(bpy.types.Operator):
    bl_idname = "rig_ui.move_module_item"
    bl_label = "Move Module Item"
    direction: bpy.props.EnumProperty(items=[("UP", "Up", ""), ("DOWN", "Down", "")])

    def execute(self, context):
        armature = context.active_object.data
        index = armature.active_rig_ui_list_index
        list = armature.rig_ui_list

        # Move the item up or down and update the active index to follow the moved item
        if self.direction == "UP" and index > 0:
            list.move(index, index - 1)
            armature.active_rig_ui_list_index -= 1  # Move the index up
        elif self.direction == "DOWN" and index < len(list) - 1:
            list.move(index, index + 1)
            armature.active_rig_ui_list_index += 1  # Move the index down

        return {"FINISHED"}


class RIG_UI_UL_ModulesOrder_items(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        # This is how each item in the list will be drawn
        row = layout.row(align=True)

        split = layout.split(factor=0.1)

        left_column = split.column(align=True)
        order_wrapper = left_column.row(align=True)
        order_wrapper.label(text=f"{index + 1}. ")

        right_column = split.column(align=True)
        section_wrapper = right_column.row(align=True)
        section_wrapper.label(text=item.name, translate=False, icon="NONE")


class RIG_UI_OT_ToggleEditMode(bpy.types.Operator):
    """Toggle the edit mode for Rig UI"""

    bl_idname = "rig_ui.toggle_edit_mode"
    bl_label = "Toggle Edit Mode"

    def execute(self, context):
        # global current_edit_armature_name
        # current_edit_armature_name = ""
        scene = context.scene
        if scene.rig_ui_edit_mode:
            scene.rig_ui_edit_mode = False
        scene.rig_ui_edit_mode = True
        return {"FINISHED"}


# Functions to register/unregister panels with dynamic Sidebar names
def register_panels():
    # Access the preferences, using a fallback if they're not available

    # prefs = (
    #     bpy.context.preferences.addons.get(ADDON_NAME).preferences
    #     if bpy.context.preferences.addons.get(ADDON_NAME)
    #     else None
    # )
    prefs = (
        bpy.context.preferences.addons[ADDON_NAME].preferences
        if bpy.context.preferences.addons[ADDON_NAME].preferences
        else None
    )

    setup_panel_name = prefs.rig_ui_setup_sidepanel_location if prefs else "Rig UI7"
    rig_ui_panel_name = prefs.rig_ui_sidepanel_location if prefs else "Rig UI7"
    print(setup_panel_name, rig_ui_panel_name)

    # Determine the side panel names based on stored properties or default values
    # setup_panel_name = getattr(prefs, "rig_ui_setup_sidepanel_location", "Rig UI")
    # rig_ui_panel_name = getattr(prefs, "rig_ui_sidepanel_location", "Rig UI")

    # Check and register the BoneCollectionsSetup panel
    if "RIG_UI_PT_BoneCollectionsSetup" not in bpy.types.Panel.__subclasses__():
        RIG_UI_PT_BoneCollectionsSetup.bl_category = setup_panel_name
        bpy.utils.register_class(RIG_UI_PT_BoneCollectionsSetup)

    # Check and register the BoneCollectionsSidePanel panel
    if (
        prefs is None or prefs.RIG_UI_side_bar_display
    ) and "RIG_UI_PT_BoneCollectionsSidePanel" not in bpy.types.Panel.__subclasses__():
        RIG_UI_PT_BoneCollectionsSidePanel.bl_category = rig_ui_panel_name
        bpy.utils.register_class(RIG_UI_PT_BoneCollectionsSidePanel)

    # Check and register the BoneCollectionsPropertiesPanel panel
    if (
        prefs is None or prefs.RIG_UI_properties_panel_display
    ) and "RIG_UI_PT_BoneCollectionsPropertiesPanel" not in bpy.types.Panel.__subclasses__():
        bpy.utils.register_class(RIG_UI_PT_BoneCollectionsPropertiesPanel)


def unregister_panels():
    # Safely attempt to unregister each panel
    try:
        bpy.utils.unregister_class(RIG_UI_PT_BoneCollectionsSetup)
    except RuntimeError:
        pass
    try:
        bpy.utils.unregister_class(RIG_UI_PT_BoneCollectionsSidePanel)
    except RuntimeError:
        pass
    try:
        bpy.utils.unregister_class(RIG_UI_PT_BoneCollectionsPropertiesPanel)
    except RuntimeError:
        pass


# List of classes in this module
classes = [
    RIG_UI_BoneCollectionsProperties,
    RIG_UI_ArmatureProperties,
    # RIG_UI_PT_BoneCollectionsSetup,
    # RIG_UI_PT_BoneCollectionsSidePanel,
    # RIG_UI_PT_BoneCollectionsPropertiesPanel,
    RIG_UI_OT_UpdatePanels,
    RIG_UI_OT_modulesOrderItem,
    RIG_UI_List_Item,
    RIG_UI_OT_RefreshBCList,
    # RIG_UI_OT_InitializeAddonModulesOrderList,
    RIG_UI_OT_AddModuleItem,
    RIG_UI_OT_RemoveModuleItem,
    RIG_UI_OT_MoveModuleItem,
    RIG_UI_UL_ModulesOrder_items,
    RIG_UI_OT_ToggleEditMode,
    RIGUI_OT_get_mouse_event,
]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    # Register properties
    bpy.types.Armature.bone_collection_properties = bpy.props.CollectionProperty(type=RIG_UI_BoneCollectionsProperties)

    bpy.types.Armature.rig_ui_list = bpy.props.CollectionProperty(type=RIG_UI_List_Item)
    bpy.types.Scene.rig_ui_edit_mode = bpy.props.BoolProperty(name="Edit Mode", default=True, update=update_edit_mode)
    bpy.types.Armature.active_rig_ui_list_index = bpy.props.IntProperty(default=0)
    bpy.types.Armature.ui_button_horizontal_separation = bpy.props.FloatProperty(
        default=0.2,
        min=0.0,
        max=1.0,
        description="Horizontal separation between buttons",
    )
    bpy.types.Armature.ui_button_vertical_separation = bpy.props.FloatProperty(
        default=0.2,
        min=0.0,
        max=1.0,
        description="Vertical separation between buttons",
    )
    bpy.types.Armature.ui_groups_vertical_separation = bpy.props.FloatProperty(
        default=0.0,
        min=0.0,
        max=1.0,
        description="Vertical separation between groups",
    )
    bpy.types.Armature.rig_ui_bone_collection_props = bpy.props.PointerProperty(type=RIG_UI_BoneCollectionsProperties)
    bpy.types.Armature.rig_ui_props = bpy.props.PointerProperty(type=RIG_UI_ArmatureProperties)
    bpy.types.Armature.ui_moving_item_index = bpy.props.IntProperty(default=-1)
    bpy.types.Armature.ui_active_section = bpy.props.StringProperty(name="UI Active Section", default="")
    bpy.types.Armature.bone_collection_properties_json = bpy.props.StringProperty(
        name="BC Properties Dictionary",
        description="Serialized dictionary of Bone Collections",
        default="{}",
    )

    # Get the preferences
    prefs = bpy.context.preferences.addons[ADDON_NAME].preferences

    # Set bl_category for each panel
    RIG_UI_PT_BoneCollectionsSetup.bl_category = prefs.rig_ui_setup_sidepanel_location
    RIG_UI_PT_BoneCollectionsSidePanel.bl_category = prefs.rig_ui_sidepanel_location
    RIG_UI_PT_BoneCollectionsPropertiesPanel.bl_category = "Rig UI"

    # Register the panel classes
    bpy.utils.register_class(RIG_UI_PT_BoneCollectionsSetup)
    bpy.utils.register_class(RIG_UI_PT_BoneCollectionsSidePanel)
    bpy.utils.register_class(RIG_UI_PT_BoneCollectionsPropertiesPanel)


def unregister():
    panel_classes = [
        RIG_UI_PT_BoneCollectionsSetup,
        RIG_UI_PT_BoneCollectionsSidePanel,
        RIG_UI_PT_BoneCollectionsPropertiesPanel,
    ]

    # Unregister properties
    del bpy.types.Armature.rig_ui_props
    del bpy.types.Armature.ui_active_section
    del bpy.types.Armature.ui_moving_item_index
    del bpy.types.Armature.bone_collection_properties
    del bpy.types.Armature.rig_ui_list
    del bpy.types.Scene.rig_ui_edit_mode
    del bpy.types.Armature.active_rig_ui_list_index
    del bpy.types.Armature.ui_button_horizontal_separation
    del bpy.types.Armature.ui_button_vertical_separation
    del bpy.types.Armature.ui_groups_vertical_separation

    for cls in reversed(classes + panel_classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()


# end of userInterface.py
# ------------------------------------------------------------------------ #
