# ------------------------------------------------------------------ #
# userInterfaceHeader.py

import bpy

from . import utils
from .customIcons import get_icon_id, get_icon

ADDON_NAME = __package__.split(".")[0]
PRO_VERSION = utils.check_pro_version()


def draw_header_main_ui(layout, context):
    # Conditions
    config_mode = bpy.context.preferences.addons[ADDON_NAME].preferences.RIG_UI_config_mode
    armature = context.view_layer.objects.active
    prefs = bpy.context.preferences.addons[ADDON_NAME].preferences
    props = bpy.context.active_object.data.rig_ui_props

    # Initialize the layout for the header
    layout = layout
    main_box = layout.box()

    # Create a row for the header elements
    header_row = main_box.row()

    # Row for displaying armature name
    armature_name_row = header_row.row(align=True)
    armature_name_row.alert = config_mode
    armature_name_row.label(text=armature.name, icon_value=172)

    # Center alignment row
    center_align_row = header_row.row(align=True)
    center_align_row.alignment = "Center".upper()

    # Configuration mode toggle row (always accessible)
    config_mode_alert_row = header_row.row(align=True)
    config_mode_alert_row.alert = config_mode
    config_mode_alert_row.prop(
        prefs,
        "RIG_UI_config_mode",
        text="",
        icon_value=(
            19 if prefs.RIG_UI_config_mode else get_icon_id("Tools")  # get_icon_id("Tools_faded")
        ),  # 19 if config_mode else 92,
        emboss=False,
    )

    # Sub-row for various options
    options_row = center_align_row.row()

    # Check for bone collection options display or config mode
    if props.bone_collection_options_display or config_mode:
        # Row for bone collection options
        bone_collection_row = options_row.row(align=True)
        bone_collection_row.active = props.bone_collection_options_display

        # Check for configuration mode for bone collection options
        if config_mode:
            config_mode_row = bone_collection_row.row()
            config_mode_row.alert = True
            config_mode_row.alignment = "Right".upper()

            # Property for bone collection options display
            config_mode_row.prop(
                props,
                "bone_collection_options_display",
                text="",
                icon_value=43 if props.bone_collection_options_display else 42,
                emboss=True,
            )

        if PRO_VERSION and prefs.RIG_UI_bone_collections:
            # Move bone collections active row
            bone_collections_box = bone_collection_row.box()
            bone_collections_box.scale_x = 0.65
            bone_collections_box.scale_y = 0.55
            bone_collections_box_row = bone_collections_box.row()
            move_bone_row = bone_collections_box_row.row()
            move_bone_row.active = props.rig_ui_move_bone_collections_active
            move_bone_subrow = move_bone_row.row(align=True)
            move_bone_subrow.prop(
                props,
                "rig_ui_move_bone_collections_active",
                text="",
                **get_icon("Move_bone_on"),
                emboss=False,
                toggle=True,
            )

            display_bc_eyes_row = bone_collections_box_row.row()
            # display_bc_eyes_row.enabled = not props.rig_ui_move_bone_collections_active
            display_bc_eyes_subrow = display_bc_eyes_row.row(align=True)
            display_bc_eyes_subrow.prop(
                prefs,
                "RIG_UI_display_bc_eyes",
                text="",
                icon_value=(get_icon_id("Eye_on") if prefs.RIG_UI_display_bc_eyes else get_icon_id("Eye_off")),
                emboss=False,
                toggle=True,
            )

        if PRO_VERSION:
            # Armature Extras row
            armature_row = bone_collection_row.row()
            armature_subrow = armature_row.row(align=True)
            armature_subrow.active = prefs.RIG_UI_extras_display
            armature_subrow.prop(
                prefs,
                "RIG_UI_extras_display",
                text="",
                **get_icon("Armature"),
                emboss=False,
                toggle=True,
            )

            # UI Extras row
            ui_row = bone_collection_row.row()
            ui_subrow = ui_row.row(align=True)
            ui_subrow.active = prefs.RIG_UI_ui_extras_display
            ui_subrow.prop(
                prefs,
                "RIG_UI_ui_extras_display",
                text="",
                **get_icon("TopBar"),
                emboss=False,
                toggle=True,
            )

        # Bone collections row
        bone_collections_row = bone_collection_row.row()
        bone_collections_subrow = bone_collections_row.row(align=True)
        bone_collections_subrow.active = prefs.RIG_UI_bone_collections
        bone_collections_subrow.prop(
            prefs,
            "RIG_UI_bone_collections",
            text="",
            **get_icon("Collections"),
            emboss=False,
            toggle=True,
        )

        if PRO_VERSION:
            # Visibility bookmarks row
            visibility_bookmarks_row = bone_collection_row.row()
            visibility_bookmarks_subrow = visibility_bookmarks_row.row(align=True)
            visibility_bookmarks_subrow.active = prefs.RIG_UI_visibility_bookmarks
            visibility_bookmarks_subrow.prop(
                prefs,
                "RIG_UI_visibility_bookmarks",
                text="",
                **get_icon("Bookmark"),
                emboss=False,
                toggle=True,
            )

            # Custom properties row
            custom_properties_row = bone_collection_row.row()
            custom_properties_subrow = custom_properties_row.row(align=True)
            custom_properties_subrow.active = prefs.RIG_UI_custom_properties
            custom_properties_subrow.prop(
                prefs,
                "RIG_UI_custom_properties",
                text="",
                **get_icon("Edit_prop"),
                emboss=False,
                toggle=True,
            )

        # Popover for section headers options
        section_headers_scale_row = bone_collection_row.row(align=True)
        section_headers_scale_row.scale_x = 1
        section_headers_scale_row.popover("RIG_UI_PT_All_In_One_Options", text="", icon_value=46)

        # # Check for configuration mode for bone collection options
        # if config_mode:
        #     config_mode_row = options_row.row()
        #     config_mode_row.alert = True
        #     config_mode_row.alignment = "Right".upper()

        #     # Property for bone collection options display
        #     config_mode_row.prop(
        #         props,
        #         "bone_collection_options_display",
        #         text="",
        #         icon_value=43 if props.bone_collection_options_display else 42,
        #         emboss=True,
        #     )

    # if prefs.RIG_UI_config_mode:
    #     sections_box = main_box.box()
    #     sections_row = sections_box.row(align=True)
    #     # sections_row.prop(prefs, "Rig_UI_element_mode", expand=True)

    #     move_row = sections_row.row(align=True)
    #     move_row.label(text="", **get_icon("Move_on"))
    #     move_row.prop_enum(prefs, "Rig_UI_element_mode", "MOVE")

    #     pin_row = sections_row.row(align=True)
    #     pin_row.label(text="", **get_icon("Pinned"))
    #     pin_row.prop_enum(prefs, "Rig_UI_element_mode", "PIN")

    #     edit_element_row = sections_row.row(align=True)
    #     edit_element_row.label(text="", **get_icon("Edit_prop"))
    #     edit_element_row.prop_enum(prefs, "Rig_UI_element_mode", "EDIT")


class RIG_UI_PT_Options_Move(bpy.types.Panel):
    """Additional optins for the move mode"""

    bl_label = ""
    bl_idname = "RIG_UI_PT_Options_Move"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_context = ""

    def draw(self, context):
        props = bpy.context.active_object.data.rig_ui_props
        # Set up the layout for the panel
        layout = self.layout
        main_column = layout.column()

        # Box for move options
        move_options_box = main_column.box()
        move_options_box.label(text="Move Options", icon_value=0)
        move_options_box.scale_y = 0.5

        # Label for "In Move Mode"
        main_column.label(text="In Move Mode", icon_value=0)

        # Row for fade non-current bone collections option
        fade_bone_collections_row = main_column.row()
        fade_bone_collections_row.prop(
            props,
            "rig_ui_fade_non_current_bc",
            text="",
            icon_value=239,
            emboss=True,
        )
        fade_bone_collections_row.label(text="Fade others", icon_value=0)

        # Row for grey out unpinned bone collections option
        grey_out_unpinned_row = main_column.row()
        grey_out_unpinned_row.prop(
            props,
            "bone_collections_grey_out_unpinned",
            text="",
            icon_value=53,
            emboss=True,
        )
        grey_out_unpinned_row.label(text="Ghost unpinned", icon_value=0)

        # Separator for clarity in the UI
        main_column.separator(factor=2.0)

        # Label for "Display Unpinned"
        main_column.label(text="Display Unpinned", icon_value=0)

        # Row for show hidden mode option
        show_hidden_mode_row = main_column.row()
        show_hidden_mode_row.prop(
            props,
            "rig_ui_show_hidden_mode",
            text="",
            icon_value=385,
            emboss=True,
        )
        show_hidden_mode_row.label(text="", icon_value=0)

        # Additional separator for UI clarity
        main_column.separator(factor=2.0)


class RIG_UI_PT_Options_boneCollections(bpy.types.Panel):
    """Additional options for bone collections UI"""

    bl_label = ""
    bl_idname = "RIG_UI_PT_Options_boneCollections"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_context = ""

    def draw(self, context):
        armature = context.active_object.data
        props = armature.rig_ui_props
        prefs = bpy.context.preferences.addons[ADDON_NAME].preferences

        # Main layout for the panel
        layout = self.layout

        # Box for bone collections options
        bone_collections_box = layout.box()
        bone_collections_box.label(text="Bone Collections Options", icon_value=0)
        bone_collections_box.scale_y = 0.5

        # Column for user interface options
        ui_options_column = layout.column()
        ui_options_column.label(text="User Interface", icon_value=0)

        if PRO_VERSION:
            # Row for group headers bone collections option
            group_headers_row = ui_options_column.row()
            group_headers_row.prop(
                props,
                "group_headers_boneCollections",
                text="",
                icon_value=49 if props.group_headers_boneCollections else 286,
                emboss=True,
            )
            group_headers_row.label(text="Group Headers", icon_value=0)

        # # Row for horizontal cozy bone collections option
        # horizontal_cozy_row = ui_options_column.row()
        # horizontal_cozy_row.prop(
        #     props,
        #     "bone_collections_cozy_horizontal",
        #     text="",
        #     icon_value=76 if props.bone_collections_cozy_horizontal else 75,
        #     emboss=True,
        # )
        # horizontal_cozy_row.label(text="Horizontal", icon_value=0)

        # # Row for vertical cozy bone collections option
        # vertical_cozy_row = ui_options_column.row()
        # vertical_cozy_row.prop(
        #     props,
        #     "bone_collections_cozy_vertical",
        #     text="",
        #     icon_value=76 if props.bone_collections_cozy_vertical else 75,
        #     emboss=True if PRO_VERSION else False,
        # )
        # vertical_cozy_row.label(text="Vertical", icon_value=0)

        # if PRO_VERSION:
        #     # Property to control the separation between the groups
        #     spacing_row = ui_options_column.row()

        if PRO_VERSION:
            # Separator for UI clarity
            ui_options_column.separator(factor=2.0)
            ui_options_column.label(text="Button Features", icon_value=0)

            # Row for bone collection special feature enabled option
            special_feature_row = ui_options_column.row()
            special_feature_row.prop(
                prefs,
                "RIG_UI_bc_pro_ui",
                text="",
                icon_value=505,
                emboss=True,
            )
            special_feature_row.label(text="Pro Mode", icon_value=0)

            # Row for highlight active layer option
            highlight_active_layer_row = ui_options_column.row()
            highlight_active_layer_row.prop(
                props,
                "rig_ui_highlight_active_bc",
                text="",
                icon_value=385,
                emboss=True,
            )
            highlight_active_layer_row.label(text="Highlight Active", icon_value=0)

            # Row for highlight active layer option
            high_contrast_layer_row = ui_options_column.row()
            high_contrast_layer_row.prop(
                prefs,
                "RIG_UI_high_contrast_fade",
                text="",
                icon="WORDWRAP_ON",
                emboss=True,
            )
            high_contrast_layer_row.label(text="High contrast", icon_value=0)

        # Final separator for layout
        layout.separator(factor=2.0)


class RIG_UI_PT_Options_VisibilityBookmarks(bpy.types.Panel):
    """Additional options for visibility bookmarks UI"""

    bl_label = ""
    bl_idname = "RIG_UI_PT_Options_VisibilityBookmarks"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_context = ""

    def draw(self, context):
        props = bpy.context.active_object.data.rig_ui_props
        # Setting up the main layout for the panel
        layout = self.layout

        # Box for visibility bookmarks options
        visibility_bookmarks_box = layout.box()
        visibility_bookmarks_box.label(text="Visibility Bookmarks Options", icon_value=0)
        visibility_bookmarks_box.scale_y = 0.5

        # Column for user interface options
        ui_options_column = layout.column()
        ui_options_column.label(text="User Interface", icon_value=0)

        # TODO reenable if groups are implemented for visibility bookmarks
        # Row for group headers visibility bookmarks option
        # group_headers_row = ui_options_column.row()
        # group_headers_row.prop(
        #     props,
        #     "group_headers_visibilityBookmarks",
        #     text="",
        #     icon_value=49 if props.group_headers_visibilityBookmarks else 286,
        #     emboss=True,
        # )
        # group_headers_row.label(text="Group Headers", icon_value=0)

        # Row for horizontal cozy visibility bookmarks option
        # horizontal_cozy_row = ui_options_column.row()
        # horizontal_cozy_row.prop(
        #     props,
        #     "visibility_bookmarks_cozy_horizontal",
        #     text="",
        #     icon_value=76 if props.visibility_bookmarks_cozy_horizontal else 75,
        #     emboss=True,
        # )
        # horizontal_cozy_row.label(text="Horizontal", icon_value=0)

        # # Row for vertical cozy visibility bookmarks option
        # vertical_cozy_row = ui_options_column.row()
        # vertical_cozy_row.prop(
        #     props,
        #     "visibility_bookmarks_cozy_vertical",
        #     text="",
        #     icon_value=76 if True else 75,
        #     emboss=True,
        # )
        # vertical_cozy_row.label(text="Vertical", icon_value=0)

        # Separator for layout clarity
        layout.separator(factor=2.0)


class RIG_UI_PT_Options_CustomProperties(bpy.types.Panel):
    """Additional options for custom properties UI"""

    bl_label = ""
    bl_idname = "RIG_UI_PT_Options_CustomProperties"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_context = ""

    def draw(self, context):
        props = bpy.context.active_object.data.rig_ui_props
        # Main layout for the panel
        layout = self.layout

        # Box for custom properties options
        custom_properties_box = layout.box()
        custom_properties_box.label(text="Custom Properties Options", icon_value=0)
        custom_properties_box.scale_y = 0.5

        # Column for user interface options
        ui_options_column = layout.column()
        ui_options_column.label(text="User Interface", icon_value=0)

        # Row for group headers custom properties option
        group_headers_row = ui_options_column.row()
        group_headers_row.prop(
            props,
            "group_headers_customProperties",
            text="",
            icon_value=49 if props.group_headers_customProperties else 286,
            emboss=True,
        )
        group_headers_row.label(text="Group Headers", icon_value=0)

        # # Row for horizontal cozy custom properties option
        # horizontal_cozy_row = ui_options_column.row()
        # horizontal_cozy_row.prop(
        #     props,
        #     "custom_properties_cozy_horizontal",
        #     text="",
        #     icon_value=76 if True else 75,
        #     emboss=True,
        # )
        # horizontal_cozy_row.label(text="Horizontal", icon_value=0)

        # # Row for vertical cozy custom properties option
        # vertical_cozy_row = ui_options_column.row()
        # vertical_cozy_row.prop(
        #     props,
        #     "custom_properties_cozy_vertical",
        #     text="",
        #     icon_value=76 if True else 75,
        #     emboss=True,
        # )
        # vertical_cozy_row.label(text="Vertical", icon_value=0)

        # Separator for layout clarity
        layout.separator(factor=2.0)


class RIG_UI_PT_Options_GeneralUI(bpy.types.Panel):
    """Additional options for general UI"""

    bl_label = ""
    bl_idname = "RIG_UI_PT_Options_GeneralUI"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_context = ""

    def draw(self, context):
        prefs = bpy.context.preferences.addons[ADDON_NAME].preferences
        armature = context.active_object.data
        layout = self.layout

        # Box for general UI options
        general_ui_box = layout.box()
        general_ui_box.label(text="Genral UI Options", icon_value=0)
        general_ui_box.scale_y = 0.5

        # Column for headers options
        headers_options_column = layout.column()
        # headers_options_column.label(text="Headers", icon_value=0)

        # Row for section headers option
        section_headers_row = headers_options_column.row()
        section_headers_row.prop(
            prefs,
            "RIG_UI_section_headers",
            text="",
            icon_value=(49 if bpy.context.preferences.addons[ADDON_NAME].preferences.RIG_UI_section_headers else 286),
            emboss=True,
        )
        section_headers_row.label(text="Section's Headers", icon_value=0)

        # Row for section background boxes
        section_box_row = headers_options_column.row()
        section_box_row.prop(
            prefs,
            "RIG_UI_section_boxes",
            text="",
            icon="SNAP_FACE" if prefs.RIG_UI_section_boxes else "MESH_PLANE",
            emboss=True,
        )
        section_box_row.label(text="Section's Background Box", icon_value=0)

        headers_options_column.label(text="Button Separation", icon_value=0)
        horizontal_factor_row = headers_options_column.row()
        horizontal_factor_row.prop(
            armature,
            "ui_button_horizontal_separation",
            text="Horizontal",
            slider=True,
            emboss=True,
        )

        vertical_factor_row = headers_options_column.row()
        vertical_factor_row.prop(
            armature,
            "ui_button_vertical_separation",
            text="Vertical",
            slider=True,
            emboss=True,
        )

        headers_options_column.label(text="Groups Separation", icon_value=0)
        vertical_factor_row = headers_options_column.row()
        vertical_factor_row.prop(
            armature,
            "ui_groups_vertical_separation",
            text="Vertical",
            slider=True,
            emboss=True,
        )

        # Separator for layout clarity
        layout.separator(factor=2.0)


class RIG_UI_PT_All_In_One_Options(bpy.types.Panel):
    """General display configuration for Rig UI"""

    bl_label = "UI Options"
    bl_idname = "RIG_UI_PT_All_In_One_Options"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"

    def draw(self, context):
        layout = self.layout

        # Panels for the popover menu
        RIG_UI_PT_Options_GeneralUI.draw(self, context)

        if PRO_VERSION:
            RIG_UI_PT_Options_Move.draw(self, context)

        RIG_UI_PT_Options_boneCollections.draw(self, context)

        if PRO_VERSION:
            # RIG_UI_PT_Options_VisibilityBookmarks.draw(self, context)

            RIG_UI_PT_Options_CustomProperties.draw(self, context)


# List of classes in this module
classes = [
    RIG_UI_PT_Options_Move,
    RIG_UI_PT_Options_boneCollections,
    RIG_UI_PT_Options_VisibilityBookmarks,
    RIG_UI_PT_Options_CustomProperties,
    RIG_UI_PT_Options_GeneralUI,
    RIG_UI_PT_All_In_One_Options,
]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()

# end of userInterfaceHeader.py
# ------------------------------------------------------------------ #
