# ------------------------------------------------------------------ #
# userInterfaceMoveButtons.py

import bpy
from bpy.props import StringProperty, IntProperty, BoolProperty
from bpy.types import Operator
from .utils import (
    refresh_ui,
    save_bc_props_to_json,
    get_item_type_from_list_id,
    get_pinned_status,
    get_item_name_and_group,
    get_item_properties,
    set_item_properties,
    reorganize_items,
)
from .customIcons import get_icon_id
from . import utils

ADDON_NAME = __package__.split(".")[0]
PRO_VERSION = utils.check_pro_version()


# ----------------------------------------------
# Move/Config Operator
# ----------------------------------------------
class UI_MoveConfig_Operator(Operator):
    """Move the element:
    - W/UP_ARROW: Move up
    - S/DOWN_ARROW: Move down
    - A/LEFT_ARROW: Move left
    - D/RIGHT_ARROW: Move right
    - SHIFT + W/UP_ARROW, or Q: Move up to previous group
    - SHIFT + S/DOWN_ARROW or E: Move down to next group
    """

    bl_idname = "ui.move_config_operator"
    bl_label = "Move or Configure UI Element"
    bl_options = {"REGISTER", "UNDO"}

    item_index: IntProperty()
    list_id: StringProperty()
    is_moving: BoolProperty(default=False)
    moving_item_index: IntProperty(default=-1)
    active_section: StringProperty(default="")

    row_property_name: bpy.props.StringProperty(default="row")
    priority_property_name: bpy.props.StringProperty(default="rig_ui_priority")

    def modal(self, context, event):
        # Change the cursor when the modal is running
        context.window.cursor_modal_set("HAND")
        obj = context.active_object

        if self.expect_direction:
            # Check for directional input
            direction = self.determine_direction(event.type)
            if direction:
                self.move_item(context, direction)
                self.expect_direction = True
                return {"RUNNING_MODAL"}

        if event.type in {"ESC", "RIGHTMOUSE", "RET", "SPACE", "LEFTMOUSE"} and event.value == "PRESS":
            return self.cancel_modal(context)

        if self.is_moving:
            shift_pressed = event.shift
            context.object["is_moving_ui_element"] = True

            # Check for directional input with shift key for group changing
            if event.type in {"W", "UP_ARROW", "S", "DOWN_ARROW"} and event.value == "RELEASE":
                direction = self.determine_direction(event.type)
                if shift_pressed:
                    self.change_group(context, direction)
                else:
                    self.move_item(context, direction)

            elif event.type in {"E", "Q"} and event.value == "RELEASE":
                direction = self.determine_direction(event.type)
                self.change_group(context, direction)

            elif (
                event.type
                in {
                    "A",
                    "LEFT_ARROW",
                    "D",
                    "RIGHT_ARROW",
                }
                and event.value == "RELEASE"
            ):
                direction = self.determine_direction(event.type)
                self.move_item(context, direction)

            # Refresh UI on release
            if event.type in {"LEFTMOUSE", "RIGHTMOUSE"} and event.value == "RELEASE":
                self.is_moving = False
                save_bc_props_to_json(obj)
                refresh_ui(context)
                return {"FINISHED"}
        else:
            context.object["is_moving_ui_element"] = False

        refresh_ui(context)
        return {"RUNNING_MODAL"}

    def determine_direction(self, event_type):
        if event_type in {"W", "UP_ARROW", "Q"}:
            return "up"
        elif event_type in {"S", "DOWN_ARROW", "E"}:
            return "down"
        elif event_type in {"A", "LEFT_ARROW"}:
            return "left"
        elif event_type in {"D", "RIGHT_ARROW"}:
            return "right"
        return None

    def change_group(self, context, direction):
        collection = getattr(context.active_object.data, self.list_id)
        armature = context.active_object.data
        item = collection[self.item_index]

        # Determine item_type based on list_id
        item_type = get_item_type_from_list_id(self.list_id)
        if item_type is None:
            self.report({"ERROR"}, f"Unsupported list ID: {self.list_id}")
            return

        # Call function to move the item between groups with item_type
        move_item_between_groups(item, direction, collection, armature, item_type, self.row_property_name)

        # Reorganize items in the collection after moving the item
        reorganize_items(
            item,
            collection,
            armature,
            item_type,
            self.row_property_name,
            self.priority_property_name,
        )

        refresh_ui(context)

    # def move_item(self, context, direction):
    #     context.active_object.data.ui_moving_item_index = self.item_index
    #     context.active_object.data.ui_active_section = self.active_section
    #     collection = getattr(context.active_object.data, self.list_id)
    #     obj = context.active_object
    #     armature = context.active_object.data
    #     item = collection[self.item_index]
    #     self.expect_direction = False

    #     item_type = get_item_type_from_list_id(self.list_id)
    #     if item_type is None:
    #         self.report({"ERROR"}, f"Unsupported list ID: {self.list_id}")
    #         return

    #     if direction in ["up", "down"]:
    #         handle_vertical_movement(
    #             item,
    #             direction,
    #             collection,
    #             armature,
    #             item_type,
    #             self.row_property_name,
    #             self.priority_property_name,
    #         )
    #     elif direction in ["left", "right"]:
    #         handle_horizontal_movement(
    #             item,
    #             direction,
    #             collection,
    #             armature,
    #             item_type,
    #             self.row_property_name,
    #             self.priority_property_name,
    #         )

    #     # Reorder elements after moving them
    #     reorganize_items(
    #         item,
    #         collection,
    #         armature,
    #         item_type,
    #         self.row_property_name,
    #         self.priority_property_name,
    #     )

    #     # Call debug_movement after reordering elements
    #     if bpy.context.preferences.addons[ADDON_NAME].preferences.RIG_UI_in_dev:
    #         debug_movement(
    #             "DEBUG after reordering items",
    #             direction,
    #             item_type,
    #             self.item_index,
    #             collection,
    #             armature,
    #             self.row_property_name,
    #             self.priority_property_name,
    #         )
    #     save_bc_props_to_json(obj)
    #     refresh_ui(context)

    def move_item(self, context, direction):
        context.active_object.data.ui_moving_item_index = self.item_index
        context.active_object.data.ui_active_section = self.active_section
        full_collection = getattr(context.active_object.data, self.list_id)
        obj = context.active_object
        armature = context.active_object.data
        item = full_collection[self.item_index]
        self.expect_direction = False

        item_type = get_item_type_from_list_id(self.list_id)
        if item_type is None:
            self.report({"ERROR"}, f"Unsupported list ID: {self.list_id}")
            return

        # Filter collection to only include pinned items
        pinned_collection = [i for i in full_collection if get_pinned_status(i, armature, item_type)]

        # Ensure the current item is pinned before proceeding with movement logic
        if get_pinned_status(item, armature, item_type):
            if direction in ["up", "down"]:
                handle_vertical_movement(
                    item,
                    direction,
                    pinned_collection,
                    armature,
                    item_type,
                    self.row_property_name,
                    self.priority_property_name,
                )
            elif direction in ["left", "right"]:
                handle_horizontal_movement(
                    item,
                    direction,
                    pinned_collection,
                    armature,
                    item_type,
                    self.row_property_name,
                    self.priority_property_name,
                )

        # Reorder elements after moving them, considering only the pinned ones
        reorganize_items(
            item,
            pinned_collection,
            armature,
            item_type,
            self.row_property_name,
            self.priority_property_name,
        )

        # Debugging and saving changes
        if bpy.context.preferences.addons[ADDON_NAME].preferences.RIG_UI_in_dev:
            debug_movement(
                "DEBUG after reordering items",
                direction,
                item_type,
                item,
                pinned_collection,
                armature,
                self.row_property_name,
                self.priority_property_name,
            )

        refresh_ui(context)

    def invoke(self, context, event):
        if PRO_VERSION:
            bpy.ops.rig_ui.update_custom_properties()
        # Set the section being manipulated
        if self.list_id == "bone_collection_properties":
            self.active_section = "bone_collections"
        elif self.list_id == "visibility_bookmarks":
            self.active_section = "visibility_bookmarks"
        elif self.list_id == "custom_properties":
            self.active_section = "custom_properties"
        else:
            self.active_section = ""  # Default or other sections

        # Activate moving state conditionally
        armature_data = context.active_object.data
        self.is_moving = (
            armature_data.ui_moving_item_index == self.item_index
            and armature_data.ui_active_section == self.active_section
        )

        self.is_moving = True
        self.expect_direction = False
        context.window_manager.modal_handler_add(self)

        # Set the moving item index and active section in the armature data
        armature_data.ui_moving_item_index = self.item_index
        armature_data.ui_active_section = self.active_section

        refresh_ui(context)
        return {"RUNNING_MODAL"}

    # def set_active_element(self, context, event):
    #     # Logic to change the active element
    #     pass

    def cancel_modal(self, context):
        # Reset the cursor to default when the modal is cancelled
        context.window.cursor_modal_set("DEFAULT")
        # Resetting the moving item index when cancelling
        context.active_object.data.ui_moving_item_index = -1
        refresh_ui(context)
        return {"CANCELLED"}


# ----------------------------------------------
# Function for Debugging Movement
# ----------------------------------------------


def debug_movement(
    argument,
    direction,
    item_type,
    moving_item,
    prop_collection,
    armature,
    row_prop_name,
    priority_prop_name,
):
    # Retrieve the item being moved
    # moving_item = prop_collection[item_index]

    # Determine the correct name and group_id attribute based on item type
    item_name, group_id = get_item_name_and_group(moving_item, armature, item_type)

    # Attempt to find the index of moving_item in prop_collection
    try:
        item_index = prop_collection.index(moving_item)
    except ValueError:
        item_index = -1

    # Debug information about the item being moved
    print("\n-----------------------------------------------------------")
    print(argument)
    print(f"Moving item: {item_name} (Index: {item_index}) in group: {group_id}")
    print("-----------------------------------------------------------")
    print(f"move_item called, direction: {direction}")

    # Grouping and printing elements by group_id, row, and priority, including pinned status
    group_map = {}
    for item in prop_collection:
        pinned_status = "(P)" if get_pinned_status(item, armature, item_type) else "(U)"
        item_name, item_group_id = get_item_name_and_group(item, armature, item_type)

        row = getattr(item, row_prop_name, "Unknown Row")
        priority = getattr(item, priority_prop_name, "Unknown Priority")
        group_map.setdefault(item_group_id, {}).setdefault(row, []).append((f"{item_name} {pinned_status}", priority))

    # Print debug information
    if bpy.context.preferences.addons[ADDON_NAME].preferences.RIG_UI_in_dev:
        for group_id, rows in group_map.items():
            debug_info = f"group_id {group_id}: "
            for row, elements in sorted(rows.items()):
                element_info = ", ".join(
                    [f"{name} {priority}" for name, priority in sorted(elements, key=lambda x: x[1])]
                )
                debug_info += f"row {row} -> [{element_info}] "
            print(debug_info)


# ----------------------------------------------
# Functions for Moving Logic
# ----------------------------------------------


def draw_move_config_button_bc(layout, item_index, list_id, active_section):
    op = layout.operator(
        UI_MoveConfig_Operator.bl_idname,
        text="",
        icon_value=get_icon_id("Move_on"),
        emboss=False,
    )
    op.item_index = item_index
    op.list_id = list_id
    op.row_property_name = "rig_ui_row"
    op.priority_property_name = "rig_ui_priority"
    op.is_moving = True
    op.active_section = active_section


def draw_move_config_button_vb(layout, item_index, list_id, active_section):
    op = layout.operator(
        UI_MoveConfig_Operator.bl_idname,
        text="",
        icon_value=get_icon_id("Move_on"),
        emboss=False,
    )
    op.item_index = item_index
    op.list_id = list_id
    op.row_property_name = "vb_row_int"
    op.priority_property_name = "vb_priority_int"
    op.is_moving = True
    op.active_section = active_section


def draw_move_config_button_cp(layout, item_index, list_id, active_section):
    op = layout.operator(
        UI_MoveConfig_Operator.bl_idname,
        text="",
        icon_value=get_icon_id("Move_on"),
        emboss=False,
    )
    op.item_index = item_index
    op.list_id = list_id
    op.row_property_name = "cp_row_int"
    op.priority_property_name = "cp_priority_int"
    op.is_moving = True
    op.active_section = active_section


def move_item_between_groups(item, direction, collection, armature, item_type, row_property_name):
    # Determine the group collection based on item_type
    if item_type == "bone_collection":
        group_collection = armature.bone_collections_ui_groups
    elif item_type == "custom_properties":
        group_collection = armature.custom_properties_ui_groups
    else:
        print("Unsupported item type for group movement.")
        return

    # Get the list of group IDs
    group_ids = [group.unique_id for group in group_collection]

    # Find the current group_id of the item
    current_group_id = (
        item.get("group_id", None)
        if item_type == "custom_properties"
        else armature.collections_all.get(item.name, {}).get("group_id", None)
    )
    if current_group_id not in group_ids:
        print(f"Current group ID '{current_group_id}' not in group list.")
        return

    current_index = group_ids.index(current_group_id)

    # Calculate new index based on direction
    if direction == "up":
        new_index = max(0, current_index - 1)
    elif direction == "down":
        new_index = min(len(group_ids) - 1, current_index + 1)
    else:
        print("Invalid direction for group change.")
        return

    # Update the group_id of the item
    new_group_id = group_ids[new_index]
    if item_type == "custom_properties":
        item["group_id"] = new_group_id
    else:
        armature.collections_all[item.name]["group_id"] = new_group_id

    # Set the priority of the moved element to -1
    set_item_properties(item, {"rig_ui_priority": -1}, armature, item_type)

    if direction == "up":
        # Find the max row number of pinned items in the target group
        max_row_pinned = max(
            (
                get_item_properties(i, armature, item_type).get(row_property_name, 0)
                for i in collection
                if get_pinned_status(i, armature, item_type)
                and get_item_properties(i, armature, item_type).get("group_id", None) == new_group_id
            ),
            default=0,
        )
        new_row = max_row_pinned + 1
        set_item_properties(item, {row_property_name: new_row}, armature, item_type)

    elif direction == "down":
        # Set the row to -1 if moving down
        set_item_properties(item, {row_property_name: -1}, armature, item_type)

    print(
        f"Changed group ID of '{item.name if item_type == 'bone_collection' else item.cp_prop_name}' to '{new_group_id}'"
    )


# ----------------------------------------------
# Functions for Moving Logic
# ----------------------------------------------


def handle_vertical_movement(
    item,
    direction,
    prop_collection,
    armature,
    item_type,
    row_prop_name,
    priority_prop_name,
):

    item_props = get_item_properties(item, armature, item_type)
    item_row = item_props.get(row_prop_name, 0)

    items_in_same_group = [
        i
        for i in prop_collection
        if get_item_properties(i, armature, item_type).get("group_id", "NONE") == item_props.get("group_id", "NONE")
    ]

    num_items_in_row = len(
        [
            i
            for i in items_in_same_group
            if get_item_properties(i, armature, item_type).get(row_prop_name, 0) == item_row
        ]
    )

    is_only_in_row = num_items_in_row == 1
    max_row_in_group = max(
        get_item_properties(i, armature, item_type).get(row_prop_name, 0) for i in items_in_same_group
    )

    # Handle the 'up' direction movement
    if direction == "up":
        if item_row > 1:
            if not is_only_in_row:
                for prop_item in items_in_same_group:
                    prop_item_props = get_item_properties(prop_item, armature, item_type)
                    if prop_item_props.get(row_prop_name, 0) < item_row:
                        set_item_properties(
                            prop_item,
                            {row_prop_name: prop_item_props[row_prop_name] - 1},
                            armature,
                            item_type,
                        )
            set_item_properties(
                item,
                {row_prop_name: item_row - 1, priority_prop_name: -1},
                armature,
                item_type,
            )

        elif num_items_in_row > 1:
            set_item_properties(item, {row_prop_name: 0, priority_prop_name: -1}, armature, item_type)

    # Handle the 'down' direction movement
    elif direction == "down":
        if item_row < max_row_in_group:
            if not is_only_in_row:
                for prop_item in items_in_same_group:
                    prop_item_props = get_item_properties(prop_item, armature, item_type)
                    if prop_item_props.get(row_prop_name, 0) > item_row:
                        set_item_properties(
                            prop_item,
                            {row_prop_name: prop_item_props[row_prop_name] + 1},
                            armature,
                            item_type,
                        )
            set_item_properties(
                item,
                {row_prop_name: item_row + 1, priority_prop_name: -1},
                armature,
                item_type,
            )

        elif num_items_in_row > 1:
            set_item_properties(
                item,
                {row_prop_name: max_row_in_group + 1, priority_prop_name: -1},
                armature,
                item_type,
            )


def handle_horizontal_movement(
    item,
    direction,
    prop_collection,
    armature,
    item_type,
    row_prop_name,
    priority_prop_name,
):

    # Get properties of the current item using the modular approach.
    item_props = get_item_properties(item, armature, item_type)
    item_row = item_props.get(row_prop_name, 0)
    item_priority = item_props.get(priority_prop_name, 0)
    item_group = item_props.get("group_id", "NONE")

    # Identify all items in the same row and group as the current item.
    items_in_same_group_and_row = [
        i
        for i in prop_collection
        if get_item_properties(i, armature, item_type).get("group_id", "NONE") == item_group
        and get_item_properties(i, armature, item_type).get(row_prop_name, 0) == item_row
    ]

    # Calculate the maximum priority in the current row within the same group.
    max_priority = max(
        get_item_properties(i, armature, item_type).get(priority_prop_name, 0) for i in items_in_same_group_and_row
    )

    # Handle leftward movement.
    if direction == "left" and item_priority > 1:
        # Multiply the priority of each item in the row by 3, including the current item.
        multiply_priority_in_row(items_in_same_group_and_row, armature, item_type, priority_prop_name, 3)
        # Decrease the current item's priority by 4.
        set_item_properties(item, {priority_prop_name: item_priority * 3 - 4}, armature, item_type)

    # Handle rightward movement.
    elif direction == "right" and item_priority < max_priority:
        # Multiply the priority of each item in the row by 3, including the current item.
        multiply_priority_in_row(items_in_same_group_and_row, armature, item_type, priority_prop_name, 3)
        # Increase the current item's priority by 4.
        set_item_properties(item, {priority_prop_name: item_priority * 3 + 4}, armature, item_type)


def multiply_priority_in_row(items, armature, item_type, priority_prop_name, factor):
    for i in items:
        i_props = get_item_properties(i, armature, item_type)
        new_priority = i_props.get(priority_prop_name, 0) * factor
        set_item_properties(i, {priority_prop_name: new_priority}, armature, item_type)


# ----------------------------------------------
# Registration
# ----------------------------------------------
classes = [UI_MoveConfig_Operator]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()

# end of userInterfaceMoveButtons.py
# ------------------------------------------------------------------ #
