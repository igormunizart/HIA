# ------------------------------------------------------------------------ #
# utils.py
# Various utility functions used by other modules


import bpy
import time
import random
import hashlib
import json
import os

from .. import bl_info as addon_info

ADDON_VERSION = ".".join(map(str, addon_info["version"]))

# from .. import ADDON_NAME  # , PRO_VERSION
from .keymaps import addon_keymaps


ADDON_NAME = __package__.split(".")[0]


# Function to check if the PRO version directory exists
def check_pro_version():
    # Construct the directory path
    addon_dir = os.path.dirname(__file__)  # Gets the directory of the current file
    pro_dir = os.path.join(addon_dir, "..", "Rig_UI_pro_modules")

    # Normalize the path to resolve any '..' and similar path elements
    pro_dir = os.path.normpath(pro_dir)

    # Check if the directory exists and is a directory
    return os.path.exists(pro_dir) and os.path.isdir(pro_dir)


# Set PRO_VERSION based on the existence of the directory
PRO_VERSION = check_pro_version()

# ----------------------------------------------
# Functions for Handling Properties
# ----------------------------------------------


def debug_items_state(stage, items, armature, item_type, row_prop_name, priority_prop_name):
    print(f"\n{stage} of Items:")
    for item in items:
        props = get_item_properties(item, armature, item_type)
        item_name, group_id = get_item_name_and_group(item, armature, item_type)
        row = props.get(row_prop_name, "Unknown")
        priority = props.get(priority_prop_name, "Unknown")
        print(f"Item: {item_name}, Group: {group_id}, Row: {row}, Priority: {priority}")


def get_item_properties(item, armature, item_type):
    if item_type == "bone_collection":
        return armature.collections_all.get(item.name, {})
    elif item_type == "visibility_bookmark":
        return {prop: getattr(item, prop) for prop in dir(item) if "__" not in prop}
    elif item_type == "custom_properties":
        return {prop: getattr(item, prop) for prop in dir(item) if "__" not in prop}
    else:
        # Include the invalid item_type in the error message for clarity
        raise ValueError(f"Invalid item type: {item_type}")


# def set_item_properties(item, properties, armature, item_type):
#     if item_type == "bone_collection":
#         for key, value in properties.items():
#             armature.collections_all[item.name][key] = value
#     elif item_type == "visibility_bookmark":
#         for key, value in properties.items():
#             setattr(item, key, value)
#     elif item_type == "custom_properties":
#         for key, value in properties.items():
#             setattr(item, key, value)
#     else:
#         raise ValueError("Invalid item type")


def set_item_properties(item, properties, armature, item_type):
    try:
        if item_type == "bone_collection":
            # Ensure the item exists before setting properties
            if item.name in armature.collections_all:
                for key, value in properties.items():
                    armature.collections_all[item.name][key] = value
            else:
                raise KeyError(f"Item with name '{item.name}' not found in armature.collections_all")
        elif item_type == "visibility_bookmark":
            for key, value in properties.items():
                setattr(item, key, value)
        elif item_type == "custom_properties":
            for key, value in properties.items():
                setattr(item, key, value)
        else:
            raise ValueError("Invalid item type")
    except KeyError as e:
        # Handle the missing key scenario
        print(f"Error: {str(e)}")
        # Optionally, log this error or handle it accordingly
    except Exception as e:
        # Handle other generic errors
        print(f"Unexpected error: {str(e)}")


def get_item_type_from_list_id(list_id):
    if list_id == "bone_collection_properties":
        return "bone_collection"
    elif list_id == "visibility_bookmarks":
        return "visibility_bookmark"
    elif list_id == "custom_properties":
        return "custom_properties"
    else:
        return None


def get_pinned_status(item, armature, item_type):
    """Check the pinned status based on item type."""
    if item_type == "bone_collection":
        return armature.collections_all.get(item.name, {}).get("rig_ui_pin", False)
    elif item_type == "visibility_bookmark":
        return getattr(item, "vb_pin_state", False)
    elif item_type == "custom_properties":
        return getattr(item, "cp_pin_state", False)
    return False


def get_item_name_and_group(item, armature, item_type):
    if item_type == "bone_collection":
        item_name = item.name
        group_id = armature.collections_all.get(item_name, {}).get("group_id", "Unknown Group")
    elif item_type == "visibility_bookmark":
        item_name = item.vb_name
        group_id = "N/A for Visibility Bookmark"
    elif item_type == "custom_properties":
        item_name = item.cp_prop_name
        group_id = item.group_id
    else:
        item_name = "Unknown Item Type"
        group_id = "Unknown Group"
    return item_name, group_id


def reorganize_items(item, prop_collection, armature, item_type, row_prop_name, priority_prop_name):
    # Check if the item is pinned before reorganizing
    if not get_pinned_status(item, armature, item_type):
        return

    # Identify groups
    groups = set(get_item_properties(i, armature, item_type).get("group_id", "NONE") for i in prop_collection)

    for group_id in groups:
        items_in_group = [
            i
            for i in prop_collection
            if get_item_properties(i, armature, item_type).get("group_id", "NONE") == group_id
        ]

        # Sort items based on whether they are pinned and then by row
        items_in_group.sort(
            key=lambda i: (
                not get_pinned_status(i, armature, item_type),
                get_item_properties(i, armature, item_type).get(row_prop_name, 0),
            )
        )

        # Reassign row numbers while preserving original row groupings
        current_row = 0
        last_original_row = None
        for item in items_in_group:

            original_row = get_item_properties(item, armature, item_type).get(row_prop_name, 0)
            if last_original_row is None or original_row != last_original_row:
                last_original_row = original_row
                current_row += 1
            set_item_properties(item, {row_prop_name: current_row}, armature, item_type)

        # Sort items in each row by priority
        for row_number in range(1, current_row + 1):
            items_in_row = [
                i
                for i in items_in_group
                if get_item_properties(i, armature, item_type).get(row_prop_name, 0) == row_number
            ]
            items_in_row.sort(key=lambda i: get_item_properties(i, armature, item_type).get(priority_prop_name, 0))
            for priority_index, item in enumerate(items_in_row, start=1):
                set_item_properties(item, {priority_prop_name: priority_index}, armature, item_type)

        # Debug: Print final state of each item
        if bpy.context.preferences.addons[ADDON_NAME].preferences.RIG_UI_in_dev:
            debug_items_state(
                "Final State",
                items_in_group,
                armature,
                item_type,
                row_prop_name,
                priority_prop_name,
            )


def fix_priorities(
    prop_collection,
    armature,
    item_type,
    group_id_prop,
    row_prop_name,
    priority_prop_name,
):
    # Separate items by group
    groups = {}
    for item in prop_collection:
        group_id = get_item_properties(item, armature, item_type).get(group_id_prop, "NONE")
        if group_id not in groups:
            groups[group_id] = []
        groups[group_id].append(item)

    for group_id, items in groups.items():
        # Separate pinned and unpinned items within the group
        pinned_items = [i for i in items if get_pinned_status(i, armature, item_type)]
        unpinned_items = [i for i in items if not get_pinned_status(i, armature, item_type)]

        # Sort pinned items by name to resolve any priority conflicts alphabetically
        pinned_items.sort(key=lambda i: i.name)
        process_items_sequentially(pinned_items, armature, item_type, 1, row_prop_name, priority_prop_name)

        # Determine starting row for unpinned items based on the highest row number among pinned items
        max_pinned_row = max(
            [get_item_properties(i, armature, item_type).get(row_prop_name, 0) for i in pinned_items],
            default=0,
        )
        start_row_for_unpinned = max_pinned_row + 1 if pinned_items else 1

        # Sort unpinned items by name to preserve original order and resolve priority conflicts alphabetically
        unpinned_items.sort(key=lambda i: i.name)
        process_items_sequentially(
            unpinned_items,
            armature,
            item_type,
            start_row_for_unpinned,
            row_prop_name,
            priority_prop_name,
        )


def process_items_sequentially(items, armature, item_type, start_row, row_prop_name, priority_prop_name):
    current_row = start_row
    last_row = None

    # Group items by their original row
    items_by_original_row = {}
    for item in items:
        original_row = get_item_properties(item, armature, item_type).get(row_prop_name, 0)
        if original_row not in items_by_original_row:
            items_by_original_row[original_row] = []
        items_by_original_row[original_row].append(item)

    # Process each group of items that shared the same original row
    for original_row, items_in_row in sorted(items_by_original_row.items()):
        if last_row is None or original_row != last_row:
            # Only increment current_row if we're moving to a new group of items (by original row)
            if last_row is not None:
                current_row += 1
            last_row = original_row

        # Sort items in the current group by their original priority
        # This ensures the lowest original priority gets the lowest new priority
        items_in_row.sort(
            key=lambda i: get_item_properties(i, armature, item_type).get(priority_prop_name, float("inf"))
        )

        # Update row and priority for items in the current group
        for current_priority, item in enumerate(items_in_row, start=1):
            set_item_properties(
                item,
                {row_prop_name: current_row, priority_prop_name: current_priority},
                armature,
                item_type,
            )


def print_bone_collection_properties(armature_name):
    """Debug function to print the bone collection properties of an armature."""
    armature = bpy.data.armatures.get(armature_name)
    in_dev = bpy.context.preferences.addons[ADDON_NAME].preferences.RIG_UI_in_dev
    if not armature:
        print(f"Armature '{armature_name}' not found.")
        return

    # Bone Collection Properties
    bone_collection_properties = []
    for i, prop_group in enumerate(armature.bone_collection_properties):
        row = getattr(prop_group, "rig_ui_row", "N/A")
        priority = getattr(prop_group, "rig_ui_priority", "N/A")
        bone_collection_properties.append(f"{i+1}.{prop_group.name}: [{row}, {priority}]")
    print("Bone Collection Properties: " + ", ".join(bone_collection_properties))

    # Decoded bone_collection_properties_json
    if "bone_collection_properties_json" in armature:
        properties_json = json.loads(armature["bone_collection_properties_json"])
        json_properties = []
        for i, (collection_name, props) in enumerate(properties_json.items()):
            row = props.get("rig_ui_row", "N/A")
            priority = props.get("rig_ui_priority", "N/A")
            json_properties.append(f"{i+1}.{collection_name}: [{row}, {priority}]")
        print("Decoded bone_collection_properties_json: " + ", ".join(json_properties))

    # Custom Properties of Bone Collections
    custom_properties = []
    for i, (collection_name, collection) in enumerate(armature.collections_all.items()):
        row = collection.get("rig_ui_row", "N/A")
        priority = collection.get("rig_ui_priority", "N/A")
        custom_properties.append(f"{i+1}.{collection_name}: [{row}, {priority}]")
    if in_dev:
        print("Custom Properties of Bone Collections: " + ", ".join(custom_properties))


# def save_bc_props_to_json(armature):
#     """
#     Saves custom properties of bone collections to a JSON dictionary.
#     Skips saving if no custom properties are found on bone collections.

#     Args:
#     armature (bpy.types.Armature): The armature whose bone collections properties are to be saved.
#     """
#     # Ensure the provided armature is valid and of type 'ARMATURE'
#     if armature and armature.type == "ARMATURE":
#         properties_dict = {}
#         properties_exist = False  # Flag to check if any properties exist

#         # Iterate over each collection in the armature
#         for collection in armature.data.collections_all.values():
#             # Check if at least one custom property exists in the collection
#             if any(
#                 key in collection
#                 for key in [
#                     "rig_ui_pin",
#                     "display_name",
#                     "rig_ui_row",
#                     "rig_ui_priority",
#                     "icon_name",
#                     "group_id",
#                 ]
#             ):
#                 properties_exist = True  # Set the flag as true if any property exists
#                 properties_dict[collection.name] = {
#                     "rig_ui_pin": collection.get("rig_ui_pin", False),
#                     "display_name": collection.get("display_name", True),
#                     "rig_ui_row": collection.get("rig_ui_row", 1),
#                     "rig_ui_priority": collection.get("rig_ui_priority", 1),
#                     "icon_name": collection.get("icon_name", "BLANK1"),
#                     "group_id": collection.get("group_id", "NONE"),
#                 }

#         # Only save properties to JSON if at least one custom property was found
#         if properties_exist:
#             armature.data["bone_collection_properties_json"] = json.dumps(
#                 properties_dict
#             )
#             if in_dev:
#                 print(f"Saved bone collection properties to {armature.name}")
#         else:
#             print(
#                 f"No custom properties found in bone collections of {armature.name}, nothing saved."
#             )


# def restore_bc_props_from_json(armature):
#     # Check if the armature is valid, is of type "ARMATURE", and has stored JSON properties
#     if (
#         armature
#         and armature.type == "ARMATURE"
#         and "bone_collection_properties_json" in armature.data
#     ):
#         if in_dev:
#             print(f"Found stored properties for {armature.name}, restoring...")
#         # Load properties from JSON string stored in armature data
#         properties_dict = json.loads(armature.data["bone_collection_properties_json"])

#         # Initialize variable to track the maximum row number among collections
#         max_row = 0
#         for collection in armature.data.collections_all.values():
#             # Update max_row if the collection has a higher row number
#             if "rig_ui_row" in collection:
#                 max_row = max(max_row, collection["rig_ui_row"])

#         # Iterate over each collection in the armature
#         for collection in armature.data.collections_all.values():
#             # Retrieve properties for this collection from the dictionary, or use default if not found
#             collection_props = properties_dict.get(collection.name, {})
#             for key, default_value in [
#                 ("rig_ui_pin", False),  # Pin status
#                 ("display_name", True),  # Whether to display the name
#                 ("rig_ui_priority", 1),  # Priority for sorting
#                 ("icon_name", "BLANK1"),  # Name of the icon
#                 ("group_id", "NONE"),  # ID of the group this collection belongs to
#             ]:
#                 # Assign each property from JSON or use default value
#                 collection[key] = collection_props.get(key, default_value)

#             # Assign a new row number if it does not already exist
#             if "rig_ui_row" not in collection:
#                 max_row += 1
#                 collection["rig_ui_row"] = max_row

#         # Call function to update bone collection properties in UI
#         update_bone_collection_properties_list_from_json(armature)
#         update_bone_collections_custom_properties_from_json(armature)
#         if in_dev:
#             print(f"Restored bone collection properties for {armature.name}")

#     else:
#         print(f"No stored properties found for {armature.name}.")


# def save_bc_props_to_json(armature):
#     """
#     Saves custom properties of all bone collections to a JSON dictionary, including nested collections.
#     Collections are stored at the same level with a 'parent' property indicating hierarchy.
#     Only properties found in the collections are saved.
#     """
#     in_dev = bpy.context.preferences.addons[ADDON_NAME].preferences.RIG_UI_in_dev
#     if armature and armature.type == "ARMATURE":

#         def collect_properties(collection):
#             # Only include keys that exist in the collection
#             keys = [
#                 "rig_ui_pin",
#                 "display_name",
#                 "rig_ui_row",
#                 "rig_ui_priority",
#                 "icon_name",
#                 "group_id",
#                 "button_factor",
#                 "is_separator",
#             ]
#             props = {key: collection.get(key) for key in keys if key in collection}
#             if props:  # Only include parent if there are properties to save
#                 props["parent"] = collection.parent.name if collection.parent else ""
#             return props

#         all_props = {}

#         def traverse_collections(collection, parent=""):
#             props = collect_properties(collection)
#             if props:  # Only add collection if it has custom properties
#                 all_props[collection.name] = props
#             for child_name, child_collection in collection.children.items():
#                 traverse_collections(child_collection, collection.name)

#         for name, col in armature.data.collections_all.items():
#             if col.parent is None:
#                 traverse_collections(col)

#         if all_props:  # Only save if there are properties to save
#             armature.data["bone_collection_properties_json"] = json.dumps(all_props)

#         # Call function to update bone collection properties in UI
#         update_bone_collection_properties_list_from_json(armature)
#         update_bone_collections_custom_properties_from_json(armature)
#         if in_dev:
#             print(f"Restored bone collection properties for {armature.name}")

#         # else:
#         #     print("No custom properties found in bone collections, nothing saved.")


def save_bc_props_to_json(armature):
    """
    Saves custom properties of all bone collections to a JSON dictionary.
    Collections are stored with a 'parent' property indicating hierarchy where applicable.
    Only properties found in the collections are saved.
    """
    if armature and armature.type == "ARMATURE":
        all_props = {}

        # Function to collect properties from a collection
        def collect_properties(collection):
            keys = [
                "rig_ui_pin",
                "display_name",
                "rig_ui_row",
                "rig_ui_priority",
                "icon_name",
                "group_id",
                "button_factor",
                "is_separator",
            ]
            # Collect existing properties
            props = {key: collection.get(key) for key in keys if key in collection}
            # Include 'parent' key if the collection has a parent
            props["parent"] = collection.parent.name if collection.parent else None
            return props

        # Iterate over all collections and collect their properties
        for name, col in armature.data.collections_all.items():
            props = collect_properties(col)
            if props:  # Save properties if the collection has any relevant custom properties
                all_props[name] = props

        print(all_props)

        # Save collected properties to JSON if there are any to save
        if all_props:
            armature.data["bone_collection_properties_json"] = json.dumps(all_props)
            print(f"Saved bone collection properties for {armature.name}")
        else:
            print("No custom properties found in bone collections, nothing saved.")


def restore_bc_props_from_json(armature):
    """
    Restores custom properties of bone collections from a JSON dictionary.
    Assigns new row numbers based on the maximum existing row if a collection doesn't have one.
    """
    if "bone_collection_properties_json" in armature.data:
        properties_dict = json.loads(armature.data["bone_collection_properties_json"])

        max_row = 0
        for collection in armature.data.collections_all.values():
            if "rig_ui_row" in collection:
                max_row = max(max_row, collection["rig_ui_row"])

        for name, props in properties_dict.items():
            if name in armature.data.collections:
                collection = armature.data.collections[name]
                for key, value in props.items():
                    if key != "parent":  # Ignore 'parent' property for direct assignment
                        collection[key] = value
                if "rig_ui_row" not in collection:
                    max_row += 1
                    collection["rig_ui_row"] = max_row


def update_bone_collection_properties_list_from_json(armature):
    """
    Updates the bone_collection_properties list from the armature's data collections.

    Args:
    armature (bpy.types.Armature): The armature to be updated.
    """
    in_dev = bpy.context.preferences.addons[ADDON_NAME].preferences.RIG_UI_in_dev
    if in_dev:
        print("Updating bone collection properties")

    # Check if the JSON string exists in the armature data
    if "bone_collection_properties_json" not in armature.data:
        print("No bone collection properties JSON found")
        return

    # Parse the JSON string to a dictionary
    properties_dict = json.loads(armature.data["bone_collection_properties_json"])

    # Create a dictionary mapping property group names to their instances for easy access
    prop_group_dict = {pg.name: pg for pg in armature.data.bone_collection_properties}

    # Iterate over the JSON properties
    for collection_name, props in properties_dict.items():
        # Update existing property groups or create new ones based on JSON data
        if collection_name in prop_group_dict:
            # Update existing property group
            prop_group = prop_group_dict[collection_name]
        else:
            # Create a new property group
            prop_group = armature.data.bone_collection_properties.add()
            prop_group.name = collection_name

        # Update properties based on JSON data
        if "rig_ui_pin" in props:
            prop_group.rig_ui_pin = props.get("rig_ui_pin", False)
        else:
            prop_group.rig_ui_pin = False

        if "display_name" in props:
            prop_group.display_name = props.get("display_name", True)
        else:
            prop_group.display_name = True

        if "rig_ui_row" in props:
            prop_group.rig_ui_row = props.get("rig_ui_row", 1)
        else:
            prop_group.rig_ui_row = 1

        if "rig_ui_priority" in props:
            prop_group.rig_ui_priority = props.get("rig_ui_priority", 1)
        else:
            prop_group.rig_ui_priority = 1

        if "icon_name" in props:
            prop_group.icon_name = props.get("icon_name", "BLANK1")
        else:
            prop_group.icon_name = "BLANK1"

        if "group_id" in props:
            prop_group.group_id = props.get("group_id", "NONE")
        else:
            prop_group.group_id = "NONE"

        if "is_separator" in props:
            prop_group.is_separator = props.get("is_separator", False)
        else:
            prop_group.is_separator = False

        if "button_factor" in props:
            prop_group.button_factor = props.get("button_factor", max(1.0, min(1.0, 4.0)))
        else:
            prop_group.button_factor = max(1.0, min(1.0, 4.0))

    # Remove any property groups that are not in the JSON data
    for pg_name in list(prop_group_dict.keys()):
        if pg_name not in properties_dict:
            index = armature.data.bone_collection_properties.find(pg_name)
            armature.data.bone_collection_properties.remove(index)


def update_bone_collections_custom_properties_from_json(armature):
    """
    Updates the custom properties of bone collections in the armature based on JSON data.

    Args:
    armature (bpy.types.Armature): The armature to be updated.
    """

    in_dev = bpy.context.preferences.addons[ADDON_NAME].preferences.RIG_UI_in_dev

    if in_dev:
        print("Updating bone collections custom properties from JSON")

    # Check if the JSON string exists in the armature data
    if "bone_collection_properties_json" not in armature.data:
        print("No bone collection properties JSON found")
        return

    # Parse the JSON string to a dictionary
    json_properties = json.loads(armature.data["bone_collection_properties_json"])

    # Iterate over each collection in the armature
    for collection in armature.data.collections_all.values():
        # Fetch the corresponding properties from the JSON data
        props = json_properties.get(collection.name, {})

        # Update the custom properties of the collection based on JSON data
        if "rig_ui_pin" in props:
            collection["rig_ui_pin"] = props.get("rig_ui_pin", False)
        else:
            collection["rig_ui_pin"] = False

        if "display_name" in props:
            collection["display_name"] = props.get("display_name", True)
        else:
            collection["display_name"] = True

        if "rig_ui_row" in props:
            collection["rig_ui_row"] = props.get("rig_ui_row", 1)
        else:
            collection["rig_ui_row"] = 1

        if "rig_ui_priority" in props:
            collection["rig_ui_priority"] = props.get("rig_ui_priority", 1)
        else:
            collection["rig_ui_priority"] = 1

        if "icon_name" in props:
            collection["icon_name"] = props.get("icon_name", "BLANK1")
        else:
            collection["icon_name"] = "BLANK1"

        if "group_id" in props:
            collection["group_id"] = props.get("group_id", "NONE")
        else:
            collection["group_id"] = "NONE"

        if "is_separator" in props:
            collection["is_separator"] = props.get("is_separator", False)
        else:
            collection["is_separator"] = False

        if "button_factor" in props:
            collection["button_factor"] = props.get("button_factor", max(1.0, min(1.0, 4.0)))
        else:
            collection["button_factor"] = max(1.0, min(1.0, 4.0))

    if in_dev:
        print(f"Updated bone collections custom properties for {armature.name}")


def initialize_bc_properties(armature):
    # Check if the object is an armature and proceed if true
    if armature and armature.type == "ARMATURE":
        # Create a default group for bone collections and get its unique ID
        default_group_id = check_and_create_default_bc_group(armature.data)

        # Extract all existing group IDs for validation
        existing_group_ids = {group.unique_id for group in armature.data.bone_collections_ui_groups}

        # Find the maximum existing row number among all collections
        max_row = 0
        for collection in armature.data.collections_all.values():
            if "rig_ui_row" in collection:
                max_row = max(max_row, collection["rig_ui_row"])

            # Initialize missing custom properties for each collection
            for collection in armature.data.collections_all.values():
                # Assign default values if custom properties don't exist
                if "rig_ui_pin" not in collection:
                    collection["rig_ui_pin"] = False
                if "display_name" not in collection:
                    collection["display_name"] = True
                if "rig_ui_priority" not in collection:
                    collection["rig_ui_priority"] = 1
                if "icon_name" not in collection:
                    collection["icon_name"] = "BLANK1"
                if "is_separator" not in collection:
                    collection["is_separator"] = False
                if "button_factor" not in collection:
                    collection["button_factor"] = max(1.0, min(1.0, 4.0))

                prop_name = "button_factor"
                # collection[prop_name] = collection.get(prop_name, 1.0)

                # Make sure the ID properties are initialized
                collection.id_properties_ensure()

                # Access the property manager for the custom property
                property_manager = collection.id_properties_ui(prop_name)

                # Update the property manager with desired UI hints
                property_manager.update(
                    min=1.0,
                    max=5.0,
                    soft_min=1.0,  # Optionally set to the same as min if you want
                    soft_max=5.0,  # Optionally set to the same as max if you want
                    default=1.0,
                    precision=2,
                    description="""Adjust the button size factor
The size factor will change the scale of the button relative to all
other elements in the same row""",
                    # Additional parameters can be set here as needed
                )

            # Check if the group_id exists in the list of existing group IDs
            group_id = collection.get("group_id", None)
            if group_id not in existing_group_ids:
                collection["group_id"] = default_group_id
            elif "group_id" not in collection:
                collection["group_id"] = default_group_id

            # Assign a new row number if it does not exist
            if "rig_ui_row" not in collection:
                max_row += 1
                collection["rig_ui_row"] = max_row

        # Unique ID for the armature to identify it from the panel
        if "rig_ui_id" not in armature.data:
            armature.data["rig_ui_id"] = generate_unique_id()


def check_and_create_default_bc_group(armature_data):
    # Define the default group name
    default_group_name = "Default Group"
    # Access the bone collections UI groups from the armature data
    groups = armature_data.bone_collections_ui_groups

    # Check if a group with the default name already exists
    for group in groups:
        if group.name == default_group_name:
            # Return the unique ID of the existing default group
            return group.unique_id

    # If the default group does not exist, create it
    new_group = groups.add()
    new_group.name = default_group_name
    # Generate and assign a unique ID to the new group
    new_group.unique_id = generate_unique_id()
    return new_group.unique_id


def init_rig_ui_modules_list(armature):
    in_dev = bpy.context.preferences.addons[ADDON_NAME].preferences.RIG_UI_in_dev
    if in_dev:
        print("init_rig_ui_modules_list called")
    if armature.type != "ARMATURE":
        return

    # Define the items that should be in rig_ui_list
    items = [
        {"name": "Header", "draw_function_name": "draw_header_section"},
        {
            "name": "Armature Extras",
            "draw_function_name": "draw_armature_extras_section",
        },
        {"name": "UI Extras", "draw_function_name": "draw_ui_extras_section"},
        {
            "name": "Bone Collections",
            "draw_function_name": "draw_bone_collections_section",
        },
        {
            "name": "Visibility Bookmarks",
            "draw_function_name": "draw_visibility_bookmarks_section",
        },
        {
            "name": "Custom Properties",
            "draw_function_name": "draw_custom_properties_section",
        },
        {"name": "AutoRig Pro Panel", "draw_function_name": "draw_autorig_pro_section"},
        {"name": "Rigify Panel", "draw_function_name": "draw_rigify_panel_section"},
        {
            "name": "Blender Custom Bone Properties",
            "draw_function_name": "draw_custom_bone_properties_section",
        },
    ]

    # Check if 'rig_ui_list' exists and if the existing list matches the items
    if (
        "rig_ui_list" not in armature.data
        or len(armature.data.rig_ui_list) != len(items)
        or any(armature.data.rig_ui_list[i].name != item["name"] for i, item in enumerate(items))
    ):
        if in_dev:
            print("rig_ui_list not found or needs update, initializing/updating")
        armature.data["rig_ui_list"] = []
        armature.data.rig_ui_list.clear()
        for item in items:
            list_item = armature.data.rig_ui_list.add()
            list_item.name = item["name"]
            list_item.draw_function_name = item["draw_function_name"]
    else:
        if in_dev:
            print("rig_ui_list already exists and is up to date")

    # Additional debugging to print the contents of rig_ui_list
    if in_dev:
        for item in armature.data.rig_ui_list:
            print("Item in rig_ui_list:", item.name)

        print(f"Rig UI panel list initialized/updated for: {armature.name}")


def update_bc_list(self, context):
    """Updates the bone collection list in the Setup Panel, and assigns default values if they do not exist."""
    armature = context.view_layer.objects.active
    if armature and armature.type == "ARMATURE":
        # Calculate the maximum row number among existing collections
        max_row = 0
        for collection in armature.data.collections_all.values():
            if "rig_ui_row" in collection:
                max_row = max(max_row, collection["rig_ui_row"])

        # Assign new row numbers to collections without 'row' property
        for collection in armature.data.collections_all.values():
            if "rig_ui_pin" not in collection:
                collection["rig_ui_pin"] = False
            if "rig_ui_row" not in collection:
                max_row += 1
                collection["rig_ui_row"] = max_row
            if "rig_ui_priority" not in collection:
                collection["rig_ui_priority"] = 1
            if "display_name" not in collection:
                collection["display_name"] = True
            if "icon_name" not in collection:
                collection["icon_name"] = "BLANK1"
            if "group_id" not in collection:
                collection["group_id"] = "NONE"
            if "is_separator" not in collection:
                collection["is_separator"] = True
            if "button_factor" not in collection:
                collection["button_factor"] = max(1.0, min(1.0, 4.0))

            prop_name = "button_factor"
            # collection[prop_name] = collection.get(prop_name, 1.0)

            # Make sure the ID properties are initialized
            collection.id_properties_ensure()

            # Access the property manager for the custom property
            property_manager = collection.id_properties_ui(prop_name)

            # Update the property manager with desired UI hints
            property_manager.update(
                min=1.0,
                max=5.0,
                soft_min=1.0,  # Optionally set to the same as min if you want
                soft_max=5.0,  # Optionally set to the same as max if you want
                default=1.0,
                precision=2,
                description="""Adjust the button size factor
The size factor will change the scale of the button relative to all
other elements in the same row""",
                # Additional parameters can be set here as needed
            )

        # Call sort_bc_setup_list to sort and organize collections in the setup list
        sort_bc_setup_list(armature)

    # Save the current state of the bone collection properties
    save_bc_props_to_json(armature)


def sort_bc_setup_list(armature):
    """Updates the rig UI bone collection properties for the given armature."""

    if armature and armature.type == "ARMATURE":
        # rig_ui_should_update = False

        existing_collections = {collection.name: collection for collection in armature.data.collections_all.values()}

        # Calculate the maximum row number among existing collections
        max_row = 0
        for collection in existing_collections.values():
            if "rig_ui_row" in collection:
                max_row = max(max_row, collection["rig_ui_row"])

        # Sort collections with 'rig_ui_pin' on top, then by group index(ascending ungrouped last),
        # then by row (ascending) and priority (ascending), then alphabetically
        sorted_collections = sorted(
            existing_collections.values(),
            key=lambda l: (
                -l.get("rig_ui_pin", False),  # False values on top
                get_group_index(armature.data.bone_collections_ui_groups, l.get("group_id", "NONE")),
                l.get("rig_ui_row", max_row + 1),  # Default to max_row + 1 for ungrouped
                l.get("rig_ui_priority", 1),  # Default priority
                l.name,
            ),
            reverse=False,
        )

        armature.data.bone_collection_properties.clear()
        for collection in sorted_collections:
            collection_props = armature.data.bone_collection_properties.add()
            collection_props.name = collection.name
            collection_props.row = collection.get("rig_ui_row", max_row + 1)
            collection_props.priority = collection.get("rig_ui_priority", 1)
            collection_props.display_name = collection.get("display_name", True)
            collection_props.icon_name = collection.get("icon_name", "BLANK1")
            collection_props.group_id = collection.get("group_id", "NONE")
            collection_props.is_separator = collection.get("is_separator", False)
            collection_props.button_factor = collection.get("button_factor", max(1.0, min(1.0, 4.0)))


def update_bone_collections(self, context):
    """Updates the armature's edit mode based on the rig UI properties."""
    # global current_edit_armature_name
    armature = context.active_object
    if armature.type == "ARMATURE":
        # Entering edit mode
        save_bc_props_to_json(armature)
        restore_bc_props_from_json(armature)

        # Initialize or update the UI list for the current armature
        initialize_bc_properties(armature)
        init_rig_ui_modules_list(armature)

        # Sort the bone collections setup list
        # sort_bc_setup_list(armature)

        # save_bc_props_to_json(armature)
        update_bc_list(self, context)
        # current_edit_armature_name = armature.name

    # Trigger UI redraw
    refresh_ui(context)


def update_edit_mode(self, context):
    obj = context.active_object
    armature = context.active_object.data

    bc_collections = armature.bone_collection_properties

    if armature and obj.type == "ARMATURE":
        # Check for rig_ui_version custom property
        rig_ui_version = armature.get("rig_ui_version", None)

        # Convert versions to integers for comparison
        current_version_int = int(ADDON_VERSION.replace(".", ""))
        rig_ui_version_int = int(rig_ui_version.replace(".", "")) if rig_ui_version else 0

        if rig_ui_version_int < current_version_int:
            armature["rig_ui_version"] = ADDON_VERSION
            print(ADDON_VERSION)

    if PRO_VERSION:
        vb_collections = armature.visibility_bookmarks
        cp_collections = armature.custom_properties

    group_id_prop_name = "group_id"
    row_property_name = "rig_ui_row"
    priority_property_name = "rig_ui_priority"

    # Correct item type identifiers
    if PRO_VERSION:
        sections = {
            "visibility_bookmark": vb_collections,
            "custom_properties": cp_collections,
            "bone_collection": bc_collections,
        }

    else:

        sections = {"bone_collection": bc_collections}

    # Iterate through each section and apply fix_priorities
    for section_name, section in sections.items():
        print(f"Section: {section}, Item Type: {section_name}")

        # Ensure you pass the corrected item type
        fix_priorities(
            section,
            armature,
            section_name,
            group_id_prop_name,
            row_property_name,
            priority_property_name,
        )

    # Call update_bone_collections after fixing priorities for all sections
    update_bone_collections(self, context)

    if PRO_VERSION:
        # sort_and_update_visibility_bookmarks(self, armature)
        bpy.ops.rig_ui.sort_and_refresh_visibility_bookmarks()
        print("Visibility Bookmarks Updated")
        bpy.ops.rig_ui.update_custom_properties()
        # update_custom_properties(self, armature)
        print("Custom Properties Updated")


def check_for_rigify_uid_in_collections(armature):
    # Iterate over all bone collections in the armature
    for collection in armature.data.collections_all.values():
        # Use the .get() method to safely check for the 'rigify_uid' custom property
        # This method returns None if the property does not exist, avoiding an error
        if "rigify_uid" in collection.keys():
            return True
    return False


class RIG_UI_OT_RigifyMyRigUI(bpy.types.Operator):
    """Import the Rigify bone collections setup for this armature into Rig UI
    Warning: it will overwrite the current setup
    (can be undone if you press CTRL+Z right after)"""

    bl_idname = "rig_ui.rigify_my_rig_ui"
    bl_label = "Rigify my Rig UI"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        armature = context.active_object

        # Update the current bone collections setup
        self.update_armature_collections(context)

        # Regenerate or initiate the bone collections list
        bpy.ops.rig_ui.refresh_bc_list()

        # Activate the Rigify panel if not on and is pro version
        if PRO_VERSION:
            armature.data.rig_ui_props.rig_ui_extras_rigify_display = True
            armature.data.rig_ui_props.rig_ui_extras_rigify_collapsed = True

            pass

        # Refresh the UI to display changes
        refresh_ui(context)

        return {"FINISHED"}

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.label(
            text="If you press ok you will overwrite the current setup",
            icon="ERROR",
        )
        layout.label(
            text="Only works on armatures generated with Rigify",
        )
        layout.label(
            text="(can be undone if you press CTRL+Z right after)",
        )

    def set_collection_properties(self, armature):
        """Set the row, priority, and rig_ui_pin properties for bone collections in an armature."""
        if armature and armature.type == "ARMATURE":
            row_counts = {}
            for collection in armature.data.collections_all.values():
                if "rigify_ui_row" in collection:
                    row = collection["rigify_ui_row"]

                    # Assign the row value and set rig_ui_pin to True
                    collection["rig_ui_row"] = row
                    collection["rig_ui_pin"] = True
                    collection["group_id"] = "NONE"
                    collection["is_separator"] = False
                    collection["button_factor"] = max(1.0, min(1.0, 4.0))

                    prop_name = "button_factor"
                    collection[prop_name] = collection.get(prop_name, 1.0)  # Default to 1.0 if not set

                    # Make sure the ID properties are initialized
                    collection.id_properties_ensure()

                    # Access the property manager for the custom property
                    property_manager = collection.id_properties_ui(prop_name)

                    # Update the property manager with desired UI hints
                    property_manager.update(
                        min=1.0,
                        max=5.0,
                        soft_min=1.0,
                        soft_max=5.0,
                        default=1.0,
                        precision=2,
                        description="""Adjust the button size factor
The size factor will change the scale of the button relative to all
other elements in the same row""",
                    )

                    # Calculate and assign the priority
                    priority = row_counts.get(row, 0) + 1

                    # Modify priority based on collection name
                    if ".L" in collection.name:
                        priority = 1
                    elif ".R" in collection.name:
                        priority = 2

                    collection["rig_ui_priority"] = priority

                    # Update the row count
                    row_counts[row] = priority
                else:
                    # Set rig_ui_pin to False for collections without rigify_ui_row
                    collection["rig_ui_pin"] = False

    # def update_armature_collections(self):
    #     """Update all armatures in the current Blender file."""
    #     for obj in bpy.data.objects:
    #         if obj.type == "ARMATURE":
    #             self.set_collection_properties(obj)
    def update_armature_collections(self, context):
        """Update the currently selected armature in the Blender file."""
        armature = context.active_object

        if armature and armature.type == "ARMATURE":
            self.set_collection_properties(armature)


class RIG_UI_OT_RegenerateRigifyRigUI(bpy.types.Operator):
    """Regenerate the Rigify rig based on the selected Meta rig."""

    bl_idname = "rig_ui.regenerate_rigify_rig_ui"
    bl_label = "Regenerate Rigify Rig"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        in_dev = bpy.context.preferences.addons[ADDON_NAME].preferences.RIG_UI_in_dev
        source_armature = context.active_object
        update_edit_mode(self, context)

        if source_armature and source_armature.type == "ARMATURE":
            target_armature_name = source_armature.name
            if in_dev:
                print(f"Selected Armature: {target_armature_name}")

            # Store JSON in a temp variable in the scene
            if "bone_collection_properties_json" in source_armature.data:
                context.scene["temp_bc_json"] = source_armature.data["bone_collection_properties_json"]

            for armature in bpy.data.armatures:
                if "rigify_target_rig" in armature:
                    rigify_target_rig_obj = armature["rigify_target_rig"]
                    if (
                        isinstance(rigify_target_rig_obj, bpy.types.Object)
                        and rigify_target_rig_obj.name == target_armature_name
                    ):
                        for obj in bpy.data.objects:
                            if obj.data == armature:
                                context.view_layer.objects.active = obj
                                obj.select_set(True)

                                # Check if selected and active object is obj, if not pop up message and stop the operator
                                if context.view_layer.objects.active != obj or not obj.select_get():
                                    self.report(
                                        {"ERROR"},
                                        f"Failed to select the {obj.name} metarig. Make it visible and selectable.",
                                    )
                                    context.view_layer.objects.active = source_armature
                                    source_armature.select_set(True)
                                    return {"CANCELLED"}

                                # Generate the rig
                                bpy.ops.pose.rigify_generate()

                                # Restore JSON to the source armature
                                if "temp_bc_json" in context.scene:
                                    source_armature.data["bone_collection_properties_json"] = context.scene[
                                        "temp_bc_json"
                                    ]
                                    del context.scene["temp_bc_json"]
                                restore_bc_props_from_json(source_armature)
                                self.report(
                                    {"INFO"},
                                    f"Rigify: Regenerated {target_armature_name} from {obj.name}.",
                                )
                                return {"FINISHED"}
            if in_dev:
                self.report({"WARNING"}, "No matching armature found.")
        else:
            if in_dev:
                self.report({"ERROR"}, "No active armature selected.")

        return {"CANCELLED"}


class RIG_UI_OT_ClearRigUIFromArmature(bpy.types.Operator):
    """Remove all custom lists and properties from the active armature."""

    bl_idname = "rig_ui.remove_rig_ui_from_armature"
    bl_label = "Remove Armature Data"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        in_dev = bpy.context.preferences.addons[ADDON_NAME].preferences.RIG_UI_in_dev
        armature = context.active_object

        if not armature or armature.type != "ARMATURE":
            self.report({"ERROR"}, "No active armature found")
            return {"CANCELLED"}

        # Debugging: Print all properties at the armature object level
        if in_dev:
            print("Properties at the armature object level:")
            for key, value in armature.items():
                print(f"  {key}: {value}")

            # Debugging: Print all properties at the armature data block level
            print("Properties at the armature data block level:")
            for key, value in armature.data.items():
                print(f"  {key}: {value}")

        # Remove custom properties for each bone collection
        for collection in armature.data.collections_all.values():
            keys_to_remove = [
                "rig_ui_pin",
                "display_name",
                "rig_ui_row",
                "rig_ui_priority",
                "icon_name",
                "group_id",
                "button_factor",
                "is_separator",
            ]
            for key in keys_to_remove:
                if key in collection:
                    del collection[key]

        # Clear bone collections UI groups
        if "bone_collections_ui_groups" in armature.data:
            armature.data.bone_collections_ui_groups.clear()

        # Clear rig UI list
        if "rig_ui_list" in armature.data:
            if in_dev:
                print("Clearing rig_ui_list")
            armature.data.rig_ui_list.clear()
            if in_dev:
                print(f"rig_ui_list: {armature.data.rig_ui_list}")
            del armature.data["rig_ui_list"]

        # Clear rig UI custom properties
        if "custom_properties" in armature.data:
            if in_dev:
                print("Clearing custom_properties")
            armature.data.custom_properties.clear()

        # Clear rig UI custom properties ui groups
        if "custom_properties_ui_groups" in armature.data:
            if in_dev:
                print("Clearing custom_properties_ui_groups")
            armature.data.custom_properties_ui_groups.clear()

        # Clear rig UI props
        # if "rig_ui_props" in armature.data:
        #     print("Clearing rig_ui_props")
        #     armature.data.rig_ui_props = None

        # Reset active bone collection index
        if "active_bone_collection_index" in armature.data:
            if in_dev:
                print("Resetting active_bone_collection_index")
            armature.data.active_bone_collection_index = -1

        # Clear bone collection properties list
        if "bone_collection_properties" in armature.data:
            if in_dev:
                print("Clearing bone_collection_properties")
            armature.data.bone_collection_properties.clear()

        if in_dev:
            print(f"Active object: {armature.name}")

        # Clear bone collection properties list
        if "visibility_bookmarks" in armature.data:
            if in_dev:
                print("Clearing bone_collection_properties")
            armature.data.visibility_bookmarks.clear()

        print(f"Active object: {armature.name}")

        if "cp_properties_dict" in armature.data:
            if in_dev:
                print("Deleting property from armature data")
            del armature.data["cp_properties_dict"]
        else:
            if in_dev:
                print("Property not found in armature data")

        if "vb_properties_dict" in armature.data:
            if in_dev:
                print("Deleting property from armature data")
            del armature.data["vb_properties_dict"]
        else:
            if in_dev:
                print("Property not found in armature data")

        if "bone_collection_properties_json" in armature.data:
            if in_dev:
                print("Deleting property from armature data")
            del armature.data["bone_collection_properties_json"]
        else:
            if in_dev:
                print("Property not found in armature data")

        if "bone_collection_properties_json" in armature:
            if in_dev:
                print("Deleting property from armature object")
            del armature["bone_collection_properties_json"]
        else:
            if in_dev:
                print("Property not found in armature object")

        # Remove JSON stored properties
        if "rig_ui" in armature:
            del armature["rig_ui"]

        self.report({"INFO"}, "Armature data removed")
        return {"FINISHED"}


def get_group_index(groups_list, group_id):
    """
    Return the index of the group in the provided groups_list based on group_id.
    """
    if group_id == "NONE":
        return float("inf")  # Assign a high number for 'NONE' to sort at the end.

    for idx, group in enumerate(groups_list):
        if group.unique_id == group_id:
            return idx
    return float("inf")  # Assign a high number if group_id is not found.


def refresh_ui(context):
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            area.tag_redraw()


def register_classes(classes):
    for cls in classes:
        if cls.__name__ in dir(bpy.types):
            bpy.utils.unregister_class(cls)
        bpy.utils.register_class(cls)


def unregister_classes(classes):
    for cls in classes:
        # Check if the class is registered and has an 'unregister' method
        if cls.__name__ in dir(bpy.types) and hasattr(cls, "unregister"):
            bpy.utils.unregister_class(cls)


def find_user_keyconfig(key):
    """Find a specific keymap item in the user key configurations."""
    # Function to find user keyconfig
    km, kmi = addon_keymaps[key]
    for item in bpy.context.window_manager.keyconfigs.user.keymaps[km.name].keymap_items:
        found_item = False
        if kmi.idname == item.idname:
            found_item = True
            for name in dir(kmi.properties):
                if not name in ["bl_rna", "rna_type"] and not name[0] == "_":
                    if (
                        name in kmi.properties
                        and name in item.properties
                        and not kmi.properties[name] == item.properties[name]
                    ):
                        found_item = False
        if found_item:
            return item
    return kmi


def find_blender_keyconfig(idname, properties=None):
    """Find a specific keymap item in Blender's key configurations."""
    wm = bpy.context.window_manager
    for keymap in wm.keyconfigs.user.keymaps:
        for item in keymap.keymap_items:
            if item.idname == idname:
                if properties:
                    if all(getattr(item.properties, k, None) == v for k, v in properties.items()):
                        return item
                else:
                    return item
    return None


def generate_unique_id():
    # Current time in milliseconds
    current_time = str(time.time()).encode("utf-8")
    # Random number
    random_num = str(random.random()).encode("utf-8")
    # Combine and hash
    unique_string = hashlib.md5(current_time + random_num).hexdigest()
    return unique_string


class OPEN_URL_OT_operator(bpy.types.Operator):
    """Open URL (link) in browser"""

    bl_idname = "openurl.open"
    bl_label = "Open URL"

    url: bpy.props.StringProperty()

    def execute(self, context):
        import webbrowser

        webbrowser.open(self.url)
        return {"FINISHED"}


# TODO make the modular import of modules work depending on the context
def import_if_pro_version(function_module_map, default_condition=True, caller_globals=None):
    """
    Dynamically imports functions based on a condition and updates the caller's global namespace.

    :param function_module_map: Dictionary mapping function names to their module paths.
    :param default_condition: Condition to check before attempting to import. Defaults to True.
    :param caller_globals: The global namespace of the caller, to be updated with imported functions.
    """
    imported_functions = {}

    def empty_func(layout, context):
        pass

    for func_name, module_path in function_module_map.items():
        if default_condition:
            try:
                module = __import__(module_path, fromlist=[func_name])
                imported_functions[func_name] = getattr(module, func_name)
            except ImportError:
                imported_functions[func_name] = empty_func
        else:
            imported_functions[func_name] = empty_func

    if caller_globals is not None:
        caller_globals.update(imported_functions)


class RIG_UI_OT_ToggleEnumProperty(bpy.types.Operator):

    bl_idname = "rig_ui.toggle_enum_property"
    bl_label = "Turn on"
    bl_description = "Turn on this mode"

    enum_path: bpy.props.StringProperty(
        name="Enum Property Path",
        description="Path to the enum property, e.g., 'preferences.addons[\"Rig_UI\"].preferences.Rig_UI_element_mode'",
    )
    enum_value: bpy.props.StringProperty(
        name="Enum Value",
        description="Value to set for the enum property",
    )

    def execute(self, context):
        # Attempt to resolve the path to the enum property and set its value
        try:
            # Dynamically evaluate the enum path to get to the property's parent object
            path_parts = self.enum_path.rsplit(".", 1)  # Split into target and property name
            if len(path_parts) != 2:
                self.report(
                    {"ERROR"},
                    "Invalid path format. Path must lead to an enum property.",
                )
                return {"CANCELLED"}
            target_path, property_name = path_parts

            # Evaluate the target path to get the target object
            target = eval(target_path, {"__builtins__": None, "bpy": bpy, "context": context})

            # Set the enum property value
            setattr(target, property_name, self.enum_value)
        except Exception as e:
            self.report({"ERROR"}, f"Failed to set enum value: {e}")
            return {"CANCELLED"}

        return {"FINISHED"}


class RIG_UI_OT_ToggleCollectionGroups(bpy.types.Operator):
    """Toggle the visibility of collection groups"""

    bl_idname = "rig_ui.toggle_collection_groups"
    bl_label = "Toggle Bone Collection Groups"

    collection_name: bpy.props.StringProperty()

    # Assuming toggle_state is a class attribute of RIG_UI_OT_ToggleCollectionGroups
    toggle_state = {}

    def execute(self, context):
        # Toggle the state
        current_state = RIG_UI_OT_ToggleCollectionGroups.toggle_state.get(self.collection_name, False)
        RIG_UI_OT_ToggleCollectionGroups.toggle_state[self.collection_name] = not current_state

        context.area.tag_redraw()
        return {"FINISHED"}


class RIG_UI_OT_add_element(bpy.types.Operator):
    """Add a new element to the list"""

    bl_idname = "rig_ui.add_element"
    bl_label = "Add Element"

    section_name: bpy.props.StringProperty(
        name="Section Name",
        description="Name of the section to add the element to",
        default="bone_collections",
    )

    def execute(self, context):
        section_name = self.section_name
        if section_name == "bone_collections":
            bpy.ops.rig_ui.add_bone_collection()
        elif section_name == "visibility_bookmarks":
            bpy.ops.rig_ui.add_visibility_bookmark()
        elif section_name == "custom_properties":
            bpy.ops.rig_ui.add_property()

        return {"FINISHED"}


def has_ancestor_with_marker(self, collection_name, hierarchy, marker):
    # Check if the collection_name is in the hierarchy and has a 'parent' attribute or key
    collection_info = hierarchy.get(collection_name)
    if collection_info and isinstance(collection_info, dict):
        parent_name = collection_info.get("parent")
        if parent_name:
            if marker in parent_name:
                return True
            else:
                return self.has_ancestor_with_marker(parent_name, hierarchy, marker)
    return False


classes = [
    OPEN_URL_OT_operator,
    # RIG_UI_OT_GenericRemoveULItem,
    RIG_UI_OT_RigifyMyRigUI,
    RIG_UI_OT_RegenerateRigifyRigUI,
    RIG_UI_OT_ClearRigUIFromArmature,
    RIG_UI_OT_ToggleEnumProperty,
    RIG_UI_OT_add_element,
    RIG_UI_OT_ToggleCollectionGroups,
]


def register():
    # Register other classes
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except:
            # dprint(f"Could not register class {cls}")
            pass


def unregister():
    # Unregister other classes
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except:
            # dprint(f"Could not unregister class {cls}")
            pass


if __name__ == "__main__":
    register()

# end of utils.py
# ------------------------------------------------------------------------ #
