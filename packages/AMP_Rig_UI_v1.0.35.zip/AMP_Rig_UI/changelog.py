changelog = {
    "1.0.3": """
Highlights:
- New improved export Rig UI experience and output.
- Default hotkeys changed for bone collection buttons.
- New generate Rig UI from bone collections feature.
- New UI customization options for the interface for elements.

New features:
- New UI customization options:
  - General UI:
    - Vertical and Horizontal spacing for the whole Rig UI replaces the previous "cozy" toggles.
    - Now you can determine how separated groups are.
  - UI buttons:
    - Now you can interactively change the width of the buttons relative to each other per row.
    
- Transfer UI Setup:
  - Export Rig UI Setup: Exports the current Rig UI setup to a JSON file.
  - Import Rig UI Setup: Imports a Rig UI setup from a JSON file.
  - It will work for most setups, but they need to be similar in structure.
  - It will transfer over bone collections, visibility bookmarks, custom properties, and any internal setups such as button width, pin status, custom names, groups, group types...
 
- Improvements in the Export feature:
  - Custom properties are now implemented in the export.
  - The exported script is bound to the rig_ui_id property.
  - If the armature is present in the scene it will always be displayed in the panel regardless of being selected.
  - Any changes or improvements made on the armature with the addon will be reflected in the panel without exporting again, unless a new version is released that has more features.
  - The export reflects the new UI improvements.
  
- Added new optional row to the Armature extras:
  - Key selected bones/objects you can choose loc/rot/scale/custom props.
  - Call the Baking menu directly from the UI.
    
- Added a button to the UI extras to call the available workspaces directly from the UI.
- Added support for some of the AnimToolBox new menus if the addon is enabled.
- Added support for nested bone collections.
- Changelog implemented in the preferences.

UI changes:
- Renamed the "Custom Properties" panel to "Control Panel" as it will contain more than just custom properties soon.

UX changes:
- Hotkey changes and behaviour adjustments for bone collection buttons:
    - LMB now selects the bones in the bone collection acting as a picker by default
    - Shift + LMB now toggles the bone collection visibility if the colection was hidden and adds the bones to the current selection.
      
- Adopted the new solo toggle for bone collections. Now isolating a bone collection does not hide the collections, and any other action will keep the previous visibility state.

4.1 code changes:
- Correctly mapped the Move bone key to the new 4.1 operator.
- All operators have been updated to 4.1 and the new bone collection system and code changes.
  
Bug Fixes:
- Keymaps for some keys were not displaying correctly in the preferences for some people.
- Fixed an issue where adding a custom property through the panel was causing an error.
- Fixed an issue where deleted bone collections were giving an error.
- Fixed an issue where using custom names for custom properties was being reset when refreshing the custom properties list.
- Fixed an issue where adding a custom property through the panel was causing an error.
- Fixed an issue where deleted bone collections were giving an error.
- Fixed an issue where using custom names for custom properties was being reset when refreshing the custom properties list.
- Removed the pesky Misc panel with the workspaces, it can still be found in the UI extras as a popover.
- Bookmarks can now be deleted and will not reappear when refreshed.
- Renaming collections now updates the UI properly when refreshing.
- Custom names of custom properties are not kept after refreshing.

Work in progress:
- Auto-Rig Pro button to generate Rig UI starrting point.
- Redefining and challening how the IK/FK workflows are generally done, and do it the Rig UI way.
- Parent space switcher tools and experience integration.
- Groups visibility based on bone selection.
- Visual inconsistencies with spaces in the UI fixed.
- Refreshing the UI from edit mode correctly sorts groups, rows and priorities automatically.
""",
}
