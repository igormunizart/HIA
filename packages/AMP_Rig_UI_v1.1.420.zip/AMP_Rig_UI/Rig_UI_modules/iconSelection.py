# ------------------------------------------------------------------------ #
# Rig_UI_iconSelection.py
# Icon slection pop up operator to set Blender icons for UI elements

import bpy

from .customIcons import get_icon_id, get_custom_icons
from .utils import refresh_ui


# Array property type for storing recent icons
def get_recent_icons(self):
    """Returns a list of recently used icons."""
    return self.get("recent_icons", "")


def set_recent_icons(self, value):
    """Sets the list of recently used icons."""
    if isinstance(value, list):
        self["recent_icons"] = ",".join(value)
    elif isinstance(value, str):
        self["recent_icons"] = value
    else:
        self["recent_icons"] = ""


def update_recent_icons(context, icon_name):
    """Updates the list of recently used icons."""
    recent_icons = context.scene.recent_icons.split(",") if context.scene.recent_icons else []
    if icon_name not in recent_icons:
        recent_icons.append(icon_name)
        if len(recent_icons) > 20:
            recent_icons.pop(0)
    context.scene.recent_icons = ",".join(recent_icons)


class RIG_UI_OT_IconSelector(bpy.types.Operator):
    """Select an icon for the User Interface Eelement
    - LMB to select an icon from a list
    - Shift + LMB to set the icon to the icon in the clipboard
    - Ctrl + LMB to copy the icon name to the clipboard
    - Alt + LMB to clear the icon"""

    bl_idname = "rig_ui.icon_selector"
    bl_label = "Select Icon"
    bl_options = {"UNDO"}

    # Define the apply_context property
    apply_context: bpy.props.StringProperty()

    # Define the bone_collection_name property
    bone_collection_name: bpy.props.StringProperty()

    # Define the bookmark_index property
    bookmark_index: bpy.props.IntProperty()

    # Define the filter_text property
    filter_text: bpy.props.StringProperty(name="Filter", description="Filter icons by name")

    is_visibility_bookmark: bpy.props.BoolProperty(default=False)

    all_icons = bpy.types.UILayout.bl_rna.functions["prop"].parameters["icon"].enum_items.keys()

    def draw_custom_icons(self, layout, custom_icons):
        box = layout.box()
        col = box.column(align=True)
        for icon_name in custom_icons:
            if icon_name.startswith("AniMatePro"):
                icon_id = get_icon_id(icon_name)
                row = col.row(align=True)
                row.template_icon(icon_value=icon_id, scale=6)
                row.operator("rig_ui.apply_icon", text="").icon_name = icon_name

    def invoke(self, context, event):
        global rig_ui_popup_instance
        rig_ui_popup_instance = self

        # Get the current item's icon name based on the context
        current_icon_name = self.get_current_icon_name(context)

        if event.alt:
            # Set to blank icon
            self.set_icon_directly(context, "BLANK1")
            return {"FINISHED"}
        elif event.shift:
            # Existing shift behavior
            clipboard_icon = context.window_manager.clipboard
            if clipboard_icon in self.all_icons:
                self.set_icon_directly(context, clipboard_icon)
                return {"FINISHED"}
            else:
                return {"CANCELLED"}
        elif event.ctrl:
            # Copy current icon name to clipboard
            context.window_manager.clipboard = current_icon_name
            return {"FINISHED"}

        # Open the popup normally if no modifier key is pressed
        return context.window_manager.invoke_props_dialog(self, width=820)

    def get_current_icon_name(self, context):
        """Retrieve the current icon name based on the apply_context."""
        colls_all = getattr(context.active_object.data, "collections_all", context.active_object.data.collections)
        if self.apply_context == "visibility_bookmark":
            bookmark = context.active_object.data.visibility_bookmarks[self.bookmark_index]
            return bookmark.icon_name
        elif self.apply_context == "bone_collection":
            bone_collection = colls_all.get(self.bone_collection_name)
            return bone_collection["icon_name"] if "icon_name" in bone_collection else "NONE"
        else:
            return "NONE"

    def filter_icons(self):
        # Use the filter_text property for filtering
        filter_lower = self.filter_text.lower()
        return [icon for icon in self.all_icons if filter_lower in icon.lower()]

    def draw(self, context):
        self.draw_ui(context)

    def draw_ui(self, context):
        layout = self.layout
        scene = context.scene

        # Filter field with VIEWZOOM icon
        filter_row = layout.row()
        filter_row.prop(self, "filter_text", text="", icon="VIEWZOOM")

        # Recent Icons Section
        recent_icons_box = layout.box()
        recent_icons_box.alignment = "CENTER"
        recent_row = recent_icons_box.row(align=True)
        recent_row.alignment = "CENTER"
        recent_icons = scene.recent_icons.split(",")[-20:] if scene.recent_icons else []
        for icon in recent_icons:
            if icon and icon in self.all_icons:
                icon_button = recent_row.operator("rig_ui.apply_icon", text="", icon=icon, emboss=False)
                icon_button.icon_name = icon
                icon_button.bone_collection_name = self.bone_collection_name
                icon_button.modifier_key = "NONE"

        # TODO include custom icons in the menu
        # # Display custom icons
        # custom_icons = get_custom_icons()  # Use the function to get custom_icons
        # if custom_icons:
        #     custom_icons_box = layout.box()
        #     custom_icons_row = custom_icons_box.row(align=True)
        #     for icon_name in custom_icons.keys():
        #         if icon_name.startswith("AniMatePro"):
        #             custom_icon_id = get_icon_id(icon_name)
        #             if custom_icon_id:
        #                 custom_icons_row.operator(
        #                     "rig_ui.apply_icon", text="", icon_value=custom_icon_id
        #                 ).icon_name = icon_name

        # All Icons Section
        all_icons_box = layout.box()
        all_col = all_icons_box.column(align=True)
        filtered_icons = self.filter_icons()
        row = None
        for i, icon in enumerate(filtered_icons):
            if icon == "NONE":
                continue

            if i % 40 == 0 or row is None:
                row = all_col.row(align=True)
                row.alignment = "CENTER"

            # Change to use a method call or custom operator
            icon_button = row.operator(
                "rig_ui.apply_icon",
                text="",
                icon=icon,
                emboss=False,
            )
            icon_button.bone_collection_name = self.bone_collection_name
            icon_button.icon_name = icon
            icon_button.modifier_key = "NONE"

    def execute(self, context):
        # This operator only opens the dialog, actual icon setting is handled in another operator
        return {"FINISHED"}

    def set_icon_directly(self, context, icon_name):
        """Set the icon directly based on the apply_context."""
        colls_all = getattr(context.active_object.data, "collections_all", context.active_object.data.collections)
        if self.apply_context == "visibility_bookmark":
            bookmark = context.active_object.data.visibility_bookmarks[self.bookmark_index]
            bookmark.icon_name = icon_name
        elif self.apply_context == "bone_collection":
            bone_collection = colls_all.get(self.bone_collection_name)
            if bone_collection:
                bone_collection["icon_name"] = icon_name
        self.refresh_ui(context)

    def refresh_ui(self, context):
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == "VIEW_3D":
                    area.tag_redraw()


class RIG_UI_OT_ApplyIcon(bpy.types.Operator):
    """Apply an icon for the User Interface Eelement"""

    bl_idname = "rig_ui.apply_icon"
    bl_label = "Apply Icon"
    bl_options = {"UNDO"}

    icon_name: bpy.props.StringProperty()
    apply_context: bpy.props.StringProperty()  # Context of application (e.g., 'bone_collection', 'visibility_bookmark')
    bone_collection_name: bpy.props.StringProperty()  # Name used for bone collections
    bookmark_index: bpy.props.IntProperty()  # Index used for visibility bookmarks

    modifier_key: bpy.props.StringProperty(default="NONE")

    def execute(self, context):
        # Retrieve the context information from the global instance of RIG_UI_OT_IconSelector
        global rig_ui_popup_instance
        # Check if rig_ui_popup_instance is set and use its properties
        if rig_ui_popup_instance:
            self.apply_context = rig_ui_popup_instance.apply_context
            self.bone_collection_name = rig_ui_popup_instance.bone_collection_name
            self.bookmark_index = rig_ui_popup_instance.bookmark_index

        # Call the appropriate function based on the context
        if self.apply_context == "visibility_bookmark":
            self.apply_icon_to_visibility_bookmark(context)
        elif self.apply_context == "bone_collection":
            self.apply_icon_to_bone_collection(context)
        # Future contexts can be added here
        else:
            self.report({"ERROR"}, f"Unknown apply context: {self.apply_context}")
            return {"CANCELLED"}

        # Close the popup if it's open
        if rig_ui_popup_instance:
            bpy.context.window.screen = bpy.context.window.screen
            rig_ui_popup_instance = None

        # Copy the icon name to the clipboard
        bpy.context.window_manager.clipboard = self.icon_name

        # Update recent icons list after applying the icon
        update_recent_icons(context, self.icon_name)

        # Refresh the UI when appliying the icon to reflect the changes
        refresh_ui(context)

        return {"FINISHED"}

    def apply_icon_to_visibility_bookmark(self, context):
        armature = context.active_object.data
        if armature and self.bookmark_index < len(armature.visibility_bookmarks):
            bookmark = armature.visibility_bookmarks[self.bookmark_index]
            bookmark.icon_name = self.icon_name
        # else:
        #     self.report({"ERROR"}, "Invalid visibility bookmark index")

    def apply_icon_to_bone_collection(self, context):
        armature = context.active_object.data
        colls_all = getattr(armature, "collections_all", armature.collections)
        if self.bone_collection_name in colls_all:
            bone_collection = colls_all[self.bone_collection_name]
            bone_collection["icon_name"] = self.icon_name
        # else:
        #     self.report({"ERROR"}, "Invalid bone collection name")


class RIG_UI_OT_ApplyCustomIcon(bpy.types.Operator):
    """Apply an icon for the User Interface Eelement"""

    bl_idname = "rig_ui.apply_custom_icon"
    bl_label = "Apply Custom Icon"

    # Properties
    icon_name: bpy.props.StringProperty()
    bone_collection_name: bpy.props.StringProperty()

    def execute(self, context):
        colls_all = getattr(context.active_object.data, "collections_all", context.active_object.data.collections)
        # Retrieve the bone collection
        bone_collection = colls_all.get(self.bone_collection_name)
        # if not bone_collection:
        #     self.report({"ERROR"}, "Invalid bone collection name")
        #     return {"CANCELLED"}

        # Check if the icon name is a valid custom icon
        if self.icon_name.startswith("AniMatePro"):
            # Apply the custom icon name
            bone_collection["custom_icon_name"] = self.icon_name
            self.report({"INFO"}, f"Custom icon '{self.icon_name}' applied.")
        else:
            self.report({"ERROR"}, "Not a valid custom icon")
            return {"CANCELLED"}

        # Optional: Update UI or other elements as needed
        context.area.tag_redraw()

        return {"FINISHED"}


classes = [RIG_UI_OT_ApplyIcon, RIG_UI_OT_IconSelector, RIG_UI_OT_ApplyCustomIcon]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.recent_icons = bpy.props.StringProperty(
        name="Recent Icons",
        description="List of recently selected icons",
        get=get_recent_icons,
        set=set_recent_icons,
        default="",
    )


def unregister():
    del bpy.types.Scene.recent_icons

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
# ------------------------------------------------------------------------ #
