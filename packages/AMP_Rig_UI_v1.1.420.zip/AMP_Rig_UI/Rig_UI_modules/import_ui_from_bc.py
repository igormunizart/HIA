# ----------------------------------------------------------------------------------------------------
# import_ui_from_bc.py

import bpy
from collections import defaultdict
from .utils import refresh_ui
from . import utils


class RIG_UI_OT_import_ui_from_bc(bpy.types.Operator):
    """Import Rig UI setup from bone collections"""

    bl_idname = "rig_ui.import_ui_from_bc"
    bl_label = "Import UI from Bone Collections"
    bl_description = """Import Rig UI setup from bone collections structure.
- Can create groups with the top level or inlcude it in the collections.
- Can pin all or only visible.
- Will go up to 3 levels deep to create the UI.
"""
    bl_options = {"REGISTER", "UNDO"}

    # Operator properties

    use_g_groups: bpy.props.BoolProperty(
        name="Use (G) groups as containers",
        default=True,
        description="""If a top level group has (G) in its name,
it will be used as a container for its children making it a 
bone collection group in Rig UI.""",
    )

    only_include_visible: bpy.props.BoolProperty(
        name="Only Include Visible",
        default=True,
        description="""Only include visible bone collections in the UI.""",
    )

    ignore_empty: bpy.props.BoolProperty(
        name="Ignore Empty Collections",
        default=False,
        description="""Ignore empty bone collections in the UI.""",
    )

    use_t_tweaks: bpy.props.BoolProperty(
        name="Use (T) tweaks",
        default=True,
        description="""Use (T) in bone collection name to hide the name and
use a sphere icon, for tweak controls.""",
    )

    align_LR: bpy.props.BoolProperty(
        name="Align L/R elements",
        default=True,
        description="Automatically align (L) and (R) elements in the UI in the same row.",
    )

    align_PS: bpy.props.BoolProperty(
        name="Align Primary/Secondary elements",
        default=True,
        description="Automatically align Primary and Secondary elements in the UI in the same row.",
    )

    sort_LR: bpy.props.EnumProperty(
        name="Sort Left/Right",
        items=[
            ("NONE", "Current Order", ""),
            ("LEFT_RIGHT_A", "Left <> Right (A)", ""),
            ("LEFT_RIGHT_B", "Left <> Right (B)", ""),
            ("LEFT_RIGHT_C", "Left <> Right (C)", ""),
            ("RIGHT_LEFT_A", "Right <> Left (A)", ""),
            ("RIGHT_LEFT_B", "Right <> Left (B)", ""),
            ("RIGHT_LEFT_C", "Right <> Left (C)", ""),
            ("ALPHA_A", "Alphabetical", ""),
            ("ALPHA_B", "Alphabetical (Reverse)", ""),
        ],
        default="RIGHT_LEFT_B",
        description="""Sort the (L) and (R) elements in the UI.""",
    )

    group_type: bpy.props.EnumProperty(
        name="Group Type",
        items=[
            ("BOX", "Box", ""),
            ("LABEL", "Label", ""),
            ("LABEL_BOX", "Box with Label", ""),
            ("HEADER", "Toggleable header", ""),
            ("HEADER_BOX", "Toggleable header Box", ""),
            ("NONE", "No style", ""),
        ],
        default="LABEL",
    )

    levels_deep: bpy.props.IntProperty(
        name="Levels Deep",
        default=3,
        min=1,
    )

    def execute(self, context):
        armature = context.active_object
        bpy.ops.rig_ui.refresh_bc_list()
        if not armature or armature.type != "ARMATURE":
            self.report({"ERROR"}, "No active armature found")
            return {"CANCELLED"}
        self.import_ui_setup(armature, context)
        return {"FINISHED"}

    def import_ui_setup(self, armature, context):
        armature.data.bone_collections_ui_groups.clear()
        default_group = self.create_default_group(armature)
        collections_hierarchy = self.build_collections_hierarchy(armature)

        self.handle_collection_nesting(armature, None, collections_hierarchy, parent_group=default_group)
        self.assign_priorities(armature)

        refresh_ui(context)

    def create_default_group(self, armature):
        # Check if a default group already exists to avoid duplicates
        default_group_name = "Default Group"
        for group in armature.data.bone_collections_ui_groups:
            if group.name == default_group_name:
                return group  # Return existing default group if found

        # If not found, create a new default group
        default_group = armature.data.bone_collections_ui_groups.add()
        default_group.name = default_group_name
        default_group.unique_id = self.generate_unique_id(armature, default_group_name)
        default_group.display_type = self.group_type
        return default_group

    def build_collections_hierarchy(self, armature):
        hierarchy = defaultdict(list)
        colls_all = getattr(armature.data, "collections_all", armature.data.collections)
        for collection in colls_all.values():
            parent_name = collection.parent.name if collection.parent else None
            hierarchy[parent_name].append(collection)
        return hierarchy

    def handle_collection_nesting(
        self,
        armature,
        parent_name,
        hierarchy,
        level=0,
        parent_group=None,
        group_id=None,
        index=0,
    ):
        if level > self.levels_deep:
            return

        collections = hierarchy.get(parent_name, [])

        collections = hierarchy.get(parent_name, [])
        group_child_counter = {}

        for idx, collection in enumerate(collections):  # Use enumerate to get the index

            is_visible = collection.is_visible
            has_children = collection.name in hierarchy and len(hierarchy[collection.name]) > 0

            # * Skip if hidden or empty -----------------------------------

            if (self.only_include_visible and not is_visible) or (self.ignore_empty and not has_children):
                continue

            # * Initialize collection properties ---------------------------

            collection["rig_ui_pin"] = False
            collection["icon_name"] = "BLANK1"
            collection["display_name"] = True

            # * Define the conditions as local variables -------------------

            is_parent = level == 0 and has_children
            is_group = self.use_g_groups and "(G)" in collection.name
            is_top_group = self.use_g_groups and is_parent and is_group
            is_tweak = "(T)" in collection.name
            l_group = has_children and "(L)" in collection.name
            r_group = has_children and "(R)" in collection.name
            l_element = utils.has_ancestor_with_marker(self, collection.name, hierarchy, "(L)")
            r_element = utils.has_ancestor_with_marker(self, collection.name, hierarchy, "(R)")
            x_element = not (l_element or r_element)

            # * Handle top level groups ------------------------------------

            if is_top_group:
                group_name = collection.name.replace("(G)", "")
                group_id = self.generate_unique_id(armature, group_name)
                parent_group = armature.data.bone_collections_ui_groups.add()
                parent_group.name = group_name
                parent_group.unique_id = group_id
                parent_group.display_type = self.group_type
            else:
                group_name = armature.name if level == 0 else parent_group.name

            # Assuming 'all_groups' is a list that tracks the order of group creation/addition
            all_groups = [group.name for group in armature.data.bone_collections_ui_groups]

            # Then, when you need to find the index of 'parent_group':
            if parent_group:
                parent_group_index = all_groups.index(parent_group.name) if parent_group.name in all_groups else None
            else:
                parent_group_index = None

            # * Determine the relative index within the group --------------

            # Check for parent_group's existence to determine the group name for tracking
            current_group_name = parent_group.name if parent_group else "root"
            # parent_index = parent_group_index if parent_group and level > 1 else 0

            # Initialize or increment the child counter for the current group
            if current_group_name not in group_child_counter:
                group_child_counter[current_group_name] = 1
            else:
                group_child_counter[current_group_name] += 1

            # The 'group_index' for the current collection within its group
            group_index = group_child_counter[current_group_name]

            # # Determine the element's group index
            # collection["group_index"] = group_index

            # * Handle collection properties --------------------------------

            if level >= self.levels_deep or is_top_group or is_group:
                collection["rig_ui_pin"] = False
            else:
                collection["rig_ui_pin"] = True

            if self.use_t_tweaks and is_tweak:
                collection["display_name"] = False
                collection["icon_name"] = "SPHERE"

            # * Assign group ID ---------------------------------------------

            collection["group_id"] = group_id if group_id else parent_group.unique_id if parent_group else ""

            # * Assign row number -------------------------------------------

            # collection["rig_ui_row"] = index + idx + 1
            # collection["rig_ui_row"] = parent_group_index + group_index + 1
            collection["rig_ui_row"] = parent_group_index + group_index

            # Assign priorities to the row based on operator properties
            # self.assign_priorities(armature)

            # Recursive call, now passing down the adjusted index for the next level
            self.handle_collection_nesting(
                armature,
                collection.name,
                hierarchy,
                level + 1,
                parent_group,
                group_id,
                index + idx,  # Pass the current index to the next level
            )

            # Adjust the index for siblings at the same level based on visibility and inclusion logic
            index += idx

            for collection in collections:
                base_name_LR = collection.name.replace("L", "R")
                base_name_RL = collection.name.replace("R", "L")
                base_name_lr = collection.name.replace("l", "r")
                base_name_rl = collection.name.replace("r", "l")
                base_names = [base_name_LR, base_name_RL, base_name_lr, base_name_rl]
                if self.align_LR:
                    # Iterate through all collections again to find a base collection with a matching name
                    for base_collection in collections:
                        if base_collection.name in base_names and base_collection.name != collection.name:
                            # If a matching base collection is found and it's not the same collection,
                            # assign the (L/R) version the same row as its base version.
                            collection["rig_ui_row"] = base_collection["rig_ui_row"]

            for collection in collections:
                base_name_PS = collection.name.replace("Primary", "Secondary")
                base_name_SP = collection.name.replace("Secondary", "Primary")
                base_name_ps = collection.name.replace("primary", "secondary")
                base_name_sp = collection.name.replace("secondary", "primary")

                base_names = [base_name_PS, base_name_SP, base_name_ps, base_name_sp]
                if self.align_PS:
                    # Iterate through all collections again to find a base collection with a matching name
                    for base_collection in collections:
                        if base_collection.name in base_names and base_collection.name != collection.name:
                            # If a matching base collection is found and it's not the same collection,
                            # assign the (L/R) version the same row as its base version.
                            collection["rig_ui_row"] = base_collection["rig_ui_row"]

            for collection in collections:
                base_name = collection.name.replace("(T)", "")
                if self.use_t_tweaks and is_tweak:
                    # Find the base collection's row number
                    for base_collection in collections:
                        if base_collection.name == base_name:
                            # Assign the (T) version the same row as its base version
                            collection["rig_ui_row"] = base_collection["rig_ui_row"]

    # def handle_collection_nesting(
    #     self,
    #     armature,
    #     parent_name,
    #     hierarchy,
    #     level=0,
    #     parent_group=None,
    #     group_id=None,
    # ):
    #     if level > self.levels_deep:
    #         return

    #     collections = hierarchy.get(parent_name, [])

    #     for collection in collections:
    #         if self.only_include_visible and not collection.is_visible:
    #             continue

    #         collection["rig_ui_pin"] = False

    #         # Determine if the current collection is a group
    #         is_top_group = self.use_g_groups and "(G)" in collection.name and level == 0
    #         is_group = self.use_g_groups and "(G)" in collection.name
    #         is_tweak = "(T)" in collection.name

    #         # Setup group and collection properties for level 0 groups with (G) in their name
    #         if is_top_group:
    #             group_name = collection.name.replace(" (G)", "")
    #             # Generate a unique group ID for new groups at level 0
    #             group_id = self.generate_unique_id(armature, group_name)

    #             parent_group = armature.data.bone_collections_ui_groups.add()
    #             parent_group.name = group_name
    #             parent_group.unique_id = group_id
    #             parent_group.display_type = self.group_type
    #         else:
    #             # For non-group collections or children, use the inherited group_id
    #             group_name = armature.name if level == 0 else parent_group.name

    #         if level >= self.levels_deep or is_top_group or is_group:
    #             collection["rig_ui_pin"] = False
    #         else:
    #             collection["rig_ui_pin"] = True

    #         if self.use_t_tweaks and is_tweak:
    #             collection["display_name"] = False
    #             collection["icon_name"] = "SPHERE"

    #         # Set group_id for the collection, using the parent group's ID or the inherited one
    #         collection["group_id"] = (
    #             group_id if group_id else parent_group.unique_id if parent_group else ""
    #         )
    #         collection["rig_ui_row"] = level + 1

    #         # Assign priorities to the row based on operator properties
    #         self.assign_priorities(armature)

    #         # Recursive call, passing down the group_id to children
    #         self.handle_collection_nesting(
    #             armature, collection.name, hierarchy, level + 1, parent_group, group_id
    #         )

    def assign_priorities(self, armature):
        # Group collections by their assigned rows
        row_collections = defaultdict(list)
        colls_all = getattr(armature.data, "collections_all", armature.data.collections)
        for collection in colls_all.values():
            row = collection.get("rig_ui_row", 0)
            row_collections[row].append(collection)

        # Iterate through each row and assign priorities based on sorted order
        for row, collections in row_collections.items():
            sorted_collections = self.sort_collections_priorities(collections)
            for priority, collection in enumerate(sorted_collections, start=1):
                collection["rig_ui_priority"] = priority

    def sort_collections_priorities(self, collections):
        left_col = [".L", "_L", "_l", ".l"]
        right_col = [".R", "_R", "_r", ".r"]

        all_collections = [col for col in collections if any(col.name)]
        l_collections = [col for col in collections if any(sub in col.name for sub in left_col)]
        no_lr_collections = [
            col for col in collections if not any(sub in col.name.lower() for sub in (right_col + left_col))
        ]
        r_collections = [col for col in collections if any(sub in col.name for sub in right_col)]

        # Sort collections
        all_by_index = sorted(all_collections, key=lambda x: x.index)
        all_alphabetical_a = sorted(all_collections, key=lambda x: x.name)
        all_alphabetical_b = sorted(all_collections, key=lambda x: x.name, reverse=True)
        l_sorted_a = sorted(l_collections, key=lambda x: x.name)
        l_sorted_b = sorted(l_collections, key=lambda x: x.name, reverse=True)
        no_lr_sorted_a = sorted(no_lr_collections, key=lambda x: x.name)
        no_lr_sorted_b = sorted(no_lr_collections, key=lambda x: x.name, reverse=True)
        r_sorted_a = sorted(r_collections, key=lambda x: x.name)
        r_sorted_b = sorted(r_collections, key=lambda x: x.name, reverse=True)

        if self.sort_LR == "LEFT_RIGHT_A":
            sorted_row = l_sorted_a + no_lr_sorted_a + r_sorted_a
        elif self.sort_LR == "LEFT_RIGHT_B":
            sorted_row = l_sorted_a + no_lr_sorted_a + r_sorted_b
        elif self.sort_LR == "LEFT_RIGHT_C":
            sorted_row = l_sorted_b + no_lr_sorted_a + r_sorted_b
        elif self.sort_LR == "RIGHT_LEFT_A":
            sorted_row = r_sorted_a + no_lr_sorted_a + l_sorted_a
        elif self.sort_LR == "RIGHT_LEFT_B":
            sorted_row = r_sorted_a + no_lr_sorted_a + l_sorted_b
        elif self.sort_LR == "RIGHT_LEFT_C":
            sorted_row = r_sorted_b + no_lr_sorted_a + l_sorted_b
        elif self.sort_LR == "ALPHA_A":
            sorted_row = all_alphabetical_a
        elif self.sort_LR == "ALPHA_B":
            sorted_row = all_alphabetical_b
        else:
            sorted_row = all_by_index

        # Combine sorted lists
        return sorted_row

    def generate_unique_id(self, armature, group_name):
        return f"{len(armature.data.bone_collections_ui_groups)}_{group_name}"


def register():
    bpy.utils.register_class(RIG_UI_OT_import_ui_from_bc)


def unregister():
    bpy.utils.unregister_class(RIG_UI_OT_import_ui_from_bc)


if __name__ == "__main__":
    register()
