# ------------------------------------------------------------------------ #
# Rig_UI_preferences.py
# Preferences script for the addon

import bpy
import re
import textwrap
import importlib

from .userInterface import (
    register_panels,
    unregister_panels,
)

from .utils import (
    find_blender_keyconfig,
    find_user_keyconfig,
    update_edit_mode,
)
from .customIcons import get_icon_id
from ..changelog import changelog
from . import utils
from .. import __package__ as base_package
from ..documentation import docs

PRO_VERSION = utils.check_pro_version()

panels_visibility = {}


class RIG_UI_KeymapPreferences(bpy.types.PropertyGroup):
    """Keymaps to register for the addon"""

    keymap_toggle_bone_collections: bpy.props.StringProperty(name="Toggle Bone Collections Key", default="M")
    keymap_open_pop_up_panel: bpy.props.StringProperty(name="Open Pop Up Panel Key", default="Y")


class RIG_UI_AddonPreferences(bpy.types.AddonPreferences):
    """General preferences for the addon and the UI
    of the preferences menu"""

    bl_idname = base_package

    if PRO_VERSION:
        settings_section: bpy.props.EnumProperty(
            name="Settings Section",
            items=[
                ("GENERAL", "General", ""),
                ("KEYMAPS", "Keymaps", ""),
                ("CHANGELOG", "Changelog", ""),
                ("EXTRAS", "Extras", ""),
                ("SUPPORT", "Support", ""),
            ],
            default="GENERAL",
        )
    else:
        settings_section: bpy.props.EnumProperty(
            name="Settings Section",
            items=[
                ("GENERAL", "General", ""),
                ("KEYMAPS", "Keymaps", ""),
                ("SUPPORT", "Support", ""),
            ],
            default="GENERAL",
        )

    if PRO_VERSION:
        edit_mode_sections: bpy.props.EnumProperty(
            name="Edit Mode Sections",
            items=[
                ("GENERAL_OPTIONS", "General", "Configure the general options"),
                ("BONE_COLLECTIONS", "Collections", "Customize Bone collections"),
                ("VISIBILITY_BOOKMARKS", "Bookmarks", "Customize Visibility Bookmarks"),
                ("CUSTOM_PROPERTIES", "Properties", "Customize Custom Properties"),
            ],
            default="BONE_COLLECTIONS",
        )
    else:
        edit_mode_sections: bpy.props.EnumProperty(
            name="Edit Mode Sections",
            items=[
                ("GENERAL_OPTIONS", "General", "Configure the general options"),
                ("BONE_COLLECTIONS", "Collections", "Customize Bone collections"),
            ],
            default="BONE_COLLECTIONS",
        )

    Rig_UI_element_mode: bpy.props.EnumProperty(
        name="Mode",
        items=[
            (
                "MOVE",
                "Move",
                "Display the move button for all the UI elements",
                0,
            ),
            (
                "PIN",
                "Pin",
                "Display the pin button for all the UI elements",
                1,
            ),
            (
                "EDIT",
                "Edit",
                "Display the edit button for all the UI elements",
                2,
            ),
            (
                "ADD_REMOVE",
                "Add / Remove",
                "Display the Add / Remove button for all the UI elements",
                3,
            ),
            (
                "UI_SCALE",
                "Scale UI elements",
                "Scale the UI elements",
                4,
            ),
        ],
        default="MOVE",
    )

    rig_ui_setup_sidepanel_location: bpy.props.StringProperty(
        name="Setup Panel",
        default="Rig UI",
        description="""Change the Sidebar location of Rig UI Setup
Needs to refresh with the Update Panels button""",
    )

    rig_ui_sidepanel_location: bpy.props.StringProperty(
        name="Sidebar Panel",
        default="Rig UI",
        description="""Change the Sidebar location of Rig UI
Needs to refresh with the Update Panels button""",
    )

    RIG_UI_pop_up_panel_display: bpy.props.BoolProperty(
        name="Pop Up Panel",
        description="""Toggle display of the Rig UI in the floating panel
Needs to refresh with the Update Panels button""",
        default=True,
    )

    RIG_UI_side_bar_display: bpy.props.BoolProperty(
        name="Sidebar panel",
        description="""Toggle display of the Rig UI in the side panel
Needs to refresh with the Update Panels button""",
        default=True,
    )

    RIG_UI_properties_panel_display: bpy.props.BoolProperty(
        name="Properties Panel",
        description="""Toggle display of the Rig UI in the properties panel
Needs to refresh with the Update Panels button""",
        default=True,
    )
    keymap_prefs: bpy.props.PointerProperty(type=RIG_UI_KeymapPreferences)

    RIG_UI_config_mode: bpy.props.BoolProperty(
        name="Toggle Panel Config Mode",
        description="""Toggle Configuration mode to turn on or off
elements in the Rig UI panel""",
        default=False,
        update=update_edit_mode,
    )

    RIG_UI_section_headers: bpy.props.BoolProperty(
        name="Sections Headers",
        description="Hide or display the Sections Headers",
        default=True if PRO_VERSION else False,
    )

    RIG_UI_section_boxes: bpy.props.BoolProperty(
        name="Sections Background Box",
        description="Hide or display the Sections Background Box",
        default=True if PRO_VERSION else False,
    )

    RIG_UI_bc_pro_ui: bpy.props.BoolProperty(
        name="Pro Mode UI",
        description="""Enable the Professional, Superior and Elegant Bone Collection UI
and extended functionalities for advanced riggers and animators
or swap back to the old boring basic UI for basic users""",
        default=True,
    )

    RIG_UI_bone_collections: bpy.props.BoolProperty(
        name="Bone Collections",
        description="Display or hide the bone collections UI",
        default=True,
    )

    # In development and extras toggle
    RIG_UI_in_dev: bpy.props.BoolProperty(
        name="Experimental & in Dev",
        description="""Display the experimental and in development features in the UI, things may break,
recommended to keep off.
The changes will take effect when you restart Blender.""",
        default=False,
    )

    # Only creates these properties if in the PRO_VERSION
    if PRO_VERSION:
        RIG_UI_group_headers: bpy.props.BoolProperty(
            name="Toggle Group Headers",
            description="Hide or display the Groups Headers for the Bone Collections",
            default=True,
        )

        RIG_UI_display_bc_eyes: bpy.props.BoolProperty(
            name="Display eye icons",
            description="Hide or display Visibility Toggles (eye icons) for the Bone Collections",
            default=True,
        )

        RIG_UI_high_contrast_fade: bpy.props.BoolProperty(
            name="High contrast fade",
            description="Higher contrast fade for hidden Bone Collections buttons",
            default=False,
        )

        RIG_UI_custom_properties: bpy.props.BoolProperty(
            name="Custom Properties",
            description="Hide or display the custom properties",
            default=True,
        )

        RIG_UI_visibility_bookmarks: bpy.props.BoolProperty(
            name="Visibility Bookmarks",
            description="Store and restore visibility bookmarks of the bone collection view states",
            default=True,
        )

        RIG_UI_extras_display: bpy.props.BoolProperty(
            name="Armature Extras",
            description="Pin the armature extras to the the Rig UI panel",
            default=False,
        )

        RIG_UI_ui_extras_display: bpy.props.BoolProperty(
            name="UI Extras",
            description="Pin the UI extras to the the Rig UI panel",
            default=False,
        )

        RIG_UI_extras_pose_mode_display: bpy.props.BoolProperty(
            name="Pose/Rest Pose Mode",
            description="Display normal pose/rest pose in extras",
            default=True,
        )

        RIG_UI_extras_object_mode_display: bpy.props.BoolProperty(
            name="Object Mode Options",
            description="Display object mode options for the armature in extras",
            default=True,
        )

        RIG_UI_extras_bones_display: bpy.props.BoolProperty(
            name="Bones Extras",
            description="Display the extras for bone visibility",
            default=True,
        )

        RIG_UI_extras_bone_display_as_display: bpy.props.BoolProperty(
            name="Display Bone As...",
            description="Pin the bone display as... bar to the the panel",
            default=True,
        )

        RIG_UI_extras_shading: bpy.props.BoolProperty(
            name="3D View Shading",
            description="Pin the 3D View Shading to the the panel",
            default=True,
        )

        RIG_UI_extras_bone: bpy.props.BoolProperty(
            name="Bone Extras",
            description="Pin the bone extras to the the panel",
            default=True,
        )

        RIG_UI_extras_Transoforms: bpy.props.BoolProperty(
            name="Transoforms",
            description="Pin the transforms row to the the panel",
            default=True,
        )

        RIG_UI_extras_keying_display: bpy.props.BoolProperty(
            name="Keying",
            description="Pin the keying row to the the panel",
            default=True,
        )

        RIG_UI_extras_keying_loc: bpy.props.BoolProperty(
            name="Keying Loc",
            description="Key Location when keying",
            default=True,
        )

        RIG_UI_extras_keying_rot: bpy.props.BoolProperty(
            name="Keying Rot",
            description="Key Rotation when keying",
            default=True,
        )

        RIG_UI_extras_keying_scale: bpy.props.BoolProperty(
            name="Keying Scale",
            description="Key Scale when keying",
            default=True,
        )

        RIG_UI_extras_keying_custom: bpy.props.BoolProperty(
            name="Keying Custom",
            description="Key Custom Properties when keying",
            default=True,
        )

        ## --------------------------------------------------- ##
        ## Hotkey configurations for bone collection modifiers ##
        ## --------------------------------------------------- ##

        special_actions = [
            ("NONE", "None", ""),
            ("TOGGLE", "Toggle", ""),
            ("ISOLATE", "Isolate", ""),
            ("SELECT", "Select", ""),
            ("SELECT_ADD", "Select Add", ""),
            ("EDIT", "Edit", ""),
            # ("SELECT_REMOVE", "Select Remove", ""),
        ]
        RIG_UI_no_mod: bpy.props.EnumProperty(
            name="No modifier",
            items=special_actions,
            default="SELECT",
            override={"LIBRARY_OVERRIDABLE"},
        )
        RIG_UI_shift_mod: bpy.props.EnumProperty(
            name="Shift modifier",
            items=special_actions,
            default="SELECT_ADD",
            override={"LIBRARY_OVERRIDABLE"},
        )
        RIG_UI_ctrl_mod: bpy.props.EnumProperty(
            name="Control modifier",
            items=special_actions,
            default="ISOLATE",
            override={"LIBRARY_OVERRIDABLE"},
        )
        RIG_UI_alt_mod: bpy.props.EnumProperty(
            name="Alt modifier",
            items=special_actions,
            default="EDIT",
            override={"LIBRARY_OVERRIDABLE"},
        )
        RIG_UI_shifctrl_mod: bpy.props.EnumProperty(
            name="Shift and Control",
            items=special_actions,
            default="TOGGLE",
            override={"LIBRARY_OVERRIDABLE"},
        )
        RIG_UI_shifalt_mod: bpy.props.EnumProperty(
            name="Shift and Alt",
            items=special_actions,
            default="NONE",
            override={"LIBRARY_OVERRIDABLE"},
        )
        RIG_UI_ctrlalt_mod: bpy.props.EnumProperty(
            name="Control and Alt",
            items=special_actions,
            default="NONE",
            override={"LIBRARY_OVERRIDABLE"},
        )


    def draw_general_section(self, layout):
        # General settings
        settings_box = layout.box()
        settings_box.label(text="General Settings:")

        settings_row = settings_box.row()

        settings_left_col = settings_row.column()

        settings_left_col.label(text="WIP section")

        settings_right_col = settings_row.column()
        experimental_row = settings_right_col.row()
        experimental_row.prop(
            self,
            "RIG_UI_in_dev",
            toggle=False,
            icon="EXPERIMENTAL",
            text="Experimental and in dev features",
        )

        # Panels settings
        panels_box = layout.box()
        panels_box.label(text="Panels Settings:")

        # Create a row inside the box
        panels_row = panels_box.row()

        # Create columns within the row
        column_panels = panels_row.column()
        column_panels.prop(
            self,
            "RIG_UI_side_bar_display",
            toggle=False,
            icon="MENU_PANEL",
            text="Sidebar panel",
        )
        column_panels.prop(
            self,
            "RIG_UI_properties_panel_display",
            toggle=False,
            icon="PROPERTIES",
            text="Properties panel",
        )
        column_panels.prop(
            self,
            "RIG_UI_pop_up_panel_display",
            toggle=False,
            icon="WINDOW",
            text="Pop Up Panel",
        )

        column_location = panels_row.column()
        column_location.prop(self, "rig_ui_setup_sidepanel_location")
        column_location.prop(self, "rig_ui_sidepanel_location")

        # The operator can be added to the box or the row, as preferred
        panels_box.operator("rig_ui.redraw_panels", icon="FILE_REFRESH")

    def draw_keymaps_section(self, layout):
        keymaps_box = layout.box()
        keymaps_col = keymaps_box.column()
        header_split = keymaps_col.split(factor=0.5)
        header_split.label(text="Keymap Settings:")
        docs_icon = header_split.row()
        docs_icon.alignment = "RIGHT"
        docs_icon.active = False
        docs_icon.operator("rig_ui.help_popup", text="", icon="QUESTION", emboss=False).docs = "bc_keymaps"
        # keymaps_box.label(text="Keymap Settings:")

        if PRO_VERSION:
            # Improved Move Bone Collections Key
            bc_key_row = keymaps_box.row()
            bc_key_row.alignment = "LEFT"
            bc_key_row.prop(
                find_user_keyconfig("toggle_move_bone_collections"),
                "type",
                text="",
                full_event=True,
            )
            bc_key_row.label(text="Improved Move Bone Collections")

        # Open Pop Up Panel Key
        popup_key_row = keymaps_box.row()
        popup_key_row.alignment = "LEFT"
        popup_key_row.prop(
            find_user_keyconfig("open_rig_ui_panel"),
            "type",
            text="",
            full_event=True,
        )
        popup_key_row.label(text="Open Pop Up Panel")

        if PRO_VERSION:
            # Default Move Bone Collections Key
            default_bc_key_row = keymaps_box.row()
            default_bc_key_row.alignment = "LEFT"
            call_menu_keymap = find_blender_keyconfig("armature.assign_to_collection")
            if call_menu_keymap:
                default_bc_key_row.prop(
                    call_menu_keymap,
                    "type",
                    text="",
                    full_event=True,
                )
                default_bc_key_row.label(text="Default Move Bone Collections")
            else:
                default_bc_key_row.label(text="Default Move Bone Collections Key not found.")
            layout.separator()
            mods_col = layout.box()
            header_split = mods_col.split(factor=0.5)
            header_split.label(text="Modifiers for Bone Collection Buttons:")
            docs_icon = header_split.row()
            docs_icon.alignment = "RIGHT"
            docs_icon.active = False
            docs_icon.operator("rig_ui.help_popup", text="", icon="QUESTION", emboss=False).docs = "bc_modifier_keys"
            mods_col.separator()
            mods_col.prop(self, "RIG_UI_no_mod", text="LMB")
            mods_col.prop(self, "RIG_UI_shift_mod", text="LMB + Shift")
            mods_col.prop(self, "RIG_UI_ctrl_mod", text="LMB + Ctrl")
            mods_col.prop(self, "RIG_UI_shifctrl_mod", text="LMB + Shift + Ctrl")
            mods_col.prop(self, "RIG_UI_alt_mod", text="LMB + Alt")
            mods_col.prop(self, "RIG_UI_shifalt_mod", text="LMB + Shift + Alt")
            mods_col.prop(self, "RIG_UI_ctrlalt_mod", text="LMB + Ctrl + Alt")

    def draw_extras_section(self, layout):
        # Extra settings
        extras_box = layout.box()
        extras_box.prop(self, "RIG_UI_extras_display", toggle=True)

        # Nested box for additional extra settings
        nested_extras_box = extras_box.box()
        nested_extras_box.enabled = self.RIG_UI_extras_display

        row = nested_extras_box.row()
        row.prop(self, "RIG_UI_extras_object_mode_display", toggle=True)

        row = nested_extras_box.row()
        row.prop(self, "RIG_UI_extras_pose_mode_display", toggle=True)

        row = nested_extras_box.row()
        row.prop(self, "RIG_UI_extras_bone_display_as_display", toggle=True)

        row = nested_extras_box.row()
        row.prop(self, "RIG_UI_extras_bones_display", toggle=True)

    def draw_support_section(self, layout):
        support_box = layout.box()
        support_box.label(text="Support Information:")

        row = support_box.row()

        column_left = row.column()
        column_left.label(text="Commuity & Support:")
        column_left.operator("openurl.open", text="Twitter", icon_value=get_icon_id("Twitter")).url = (
            "https://www.twitter.com/notthatnda"
        )
        column_left.operator("openurl.open", text="Discord", icon_value=get_icon_id("Discord")).url = (
            "https://discord.gg/JWzJxTKx48"
        )
        column_left.operator("openurl.open", text="Patreon", icon_value=get_icon_id("Patreon")).url = (
            "https://www.patreon.com/AniMatePro/"
        )

        column_right = row.column()
        column_right.label(text="Download:")
        column_right.operator(
            "openurl.open",
            text="Blender Market",
            icon_value=get_icon_id("BlenderMarket"),
        ).url = "https://blendermarket.com/products/rig-ui"
        column_right.operator(
            "openurl.open",
            text="Gumroad",
            icon_value=get_icon_id("Gumroad"),
        ).url = "https://nda.gumroad.com/l/rig-ui"

    def draw(self, context):
        layout = self.layout

        # Draw the enum for selecting the section
        settings_row = layout.row()
        settings_row.prop(self, "settings_section", expand=True)

        # Draw the corresponding section based on the enum value
        if self.settings_section == "GENERAL":
            self.draw_general_section(layout)
        elif self.settings_section == "KEYMAPS":
            self.draw_keymaps_section(layout)
        elif self.settings_section == "CHANGELOG":
            self.draw_changelog(layout)
        elif self.settings_section == "EXTRAS" and PRO_VERSION:
            self.draw_extras_section(layout)
        elif self.settings_section == "SUPPORT":
            self.draw_support_section(layout)

    def draw_version_section(self, layout, version, changes):
        box = layout.box()
        row = box.row()
        icon = "TRIA_DOWN" if panels_visibility.get(version, False) else "TRIA_RIGHT"
        prop = row.operator(
            "rig_ui.toggle_panels_visibility",
            text="",
            icon=icon,
        )
        prop.version = version  # Pass the version to the operator
        row = row.row()
        row.alignment = "LEFT"
        prop = row.operator(
            "rig_ui.toggle_panels_visibility",
            text=f"Version {version}",
            icon="INFO",
            emboss=False,
        )
        prop.version = version  # Pass the version to the operator

        if panels_visibility.get(version, False):
            col = box.column(align=True)
            formatted_changes = parse_and_format_changes(self, changes, 70)
            for icon, text in formatted_changes:
                if icon != "NONE":
                    if isinstance(icon, int):
                        # If icon is an integer, use icon_value argument
                        col.label(text=text, icon_value=icon)
                    else:
                        # If icon is a string (icon name), use icon argument
                        col.label(text=text, icon=icon)
                else:
                    col.label(text=text)

    def draw_changelog(self, context):
        layout = self.layout
        versions = list(changelog.keys())
        changelog_container = layout.split(factor=0.5)
        col1 = changelog_container.column(align=True)
        col2 = changelog_container.column(align=True)

        # Determine if we need an "Archive" section
        archive_start_index = 10  # Adjust based on when you want to start archiving versions

        # Draw sections for recent changelog entries
        for index, version in enumerate(versions):
            changes = changelog[version]
            if index < archive_start_index:
                self.draw_version_section(col1, version, changes)
            else:
                # Only create and draw the Archive box if there are versions to be archived
                if index == archive_start_index:
                    archive_box = col2.box()
                    archive_row = archive_box.row()
                    archive_icon = "TRIA_DOWN" if panels_visibility.get("Archive", False) else "TRIA_RIGHT"
                    archive_prop = archive_row.operator(
                        "timeline.toggle_panels_visibility",
                        text="Archive",
                        icon=archive_icon,
                        emboss=False,
                    )
                    archive_prop.version = "Archive"
                    if panels_visibility.get("Archive", False):
                        # Draw archived versions inside the Archive section
                        for archived_index in range(archive_start_index, len(versions)):
                            archived_version = versions[archived_index]
                            archived_changes = changelog[archived_version]
                            self.draw_version_section(archive_box, archived_version, archived_changes)


def parse_and_format_changes(self, changes, wrap_length=70):
    formatted_changes = []
    lines = changes.strip().split("\n")
    icon_pattern_double = re.compile(r"\*\*(.*?)\*\*")  # Regex for **ICON_NAME**
    icon_pattern_triple = re.compile(r"\*\*\*(.*?)\*\*\*")  # Regex for ***IconName***

    for line in lines:
        # Determine the initial indentation (counting spaces at the start of the line)
        indent = len(line) - len(line.lstrip(" "))

        if line.strip() == "":  # Check if the line is empty and handle it separately
            formatted_changes.append(("NONE", " " * indent))
            continue

        # Search for triple asterisk icon markers first
        triple_match = icon_pattern_triple.search(line)
        if triple_match:
            icon_value = get_icon_id(triple_match.group(1))  # Get icon value from function
            clean_line = icon_pattern_triple.sub("", line)  # Remove the marker from the line
            icon_name = icon_value
            icon_offset = " " * (indent - len(triple_match.group(0)))  # Calculate the space before icon
        else:
            # Then check for double asterisk icon markers
            double_match = icon_pattern_double.search(line)
            if double_match:
                icon_name = double_match.group(1).upper()  # Convert icon name to upper case
                clean_line = icon_pattern_double.sub("", line)  # Remove the marker from the line
                icon_offset = " " * (indent - len(double_match.group(0)))  # Calculate the space before icon
            else:
                # Normal line without special icon
                icon_name = "NONE"
                clean_line = line
                icon_offset = " " * indent

        # Wrap the text maintaining the original indentation
        if clean_line.strip():  # Ensure there is text to wrap
            wrapped_lines = textwrap.wrap(
                clean_line.strip(), width=wrap_length, initial_indent=icon_offset, subsequent_indent=""
            )
            first = True
            for wrapped_line in wrapped_lines:
                # Only add the icon to the first line, subsequent lines should maintain indent
                if first:
                    formatted_changes.append((icon_name, wrapped_line))
                    first = False
                else:
                    formatted_changes.append(("NONE", " " * indent + wrapped_line))
        else:
            # Append the line as is if there's no text after stripping
            formatted_changes.append(("NONE", icon_offset))
            formatted_changes.append((icon_name, clean_line.strip()))

    return formatted_changes


# Operator to update all panels
class RIG_UI_OT_RedrawPanels(bpy.types.Operator):
    """Update all Rig UI panels to the current settings"""

    bl_idname = "rig_ui.redraw_panels"
    bl_label = "Update Panels"

    def execute(self, context):
        unregister_panels()
        register_panels()

        # Save the user preferences
        bpy.ops.wm.save_userpref()

        return {"FINISHED"}


class RIG_UI_OT_ToggleVisibility(bpy.types.Operator):

    bl_idname = "rig_ui.toggle_panels_visibility"
    bl_label = "Toggle Changelog Visibility"
    bl_description = "Toggle on/off"

    version: bpy.props.StringProperty()

    def execute(self, context):
        # Toggle the visibility state
        if self.version in panels_visibility:
            panels_visibility[self.version] = not panels_visibility[self.version]
        else:
            panels_visibility[self.version] = True
        return {"FINISHED"}


class RIG_UI_OT_HelpPopup(bpy.types.Operator):
    bl_idname = "rig_ui.help_popup"
    bl_label = ""
    bl_options = {"REGISTER", "UNDO"}
    bl_description = "Display help for this section"

    docs: bpy.props.StringProperty()

    def draw(self, context):
        layout = self.layout
        help_entry = docs.get(self.docs, None)

        if help_entry:
            header_container = layout.box()
            header_row = header_container.row()
            header_split = header_row.split(factor=0.9)
            title_row = header_split.row()
            title_row.label(text="", icon_value=get_icon_id("AniMateProContact"))
            title_row.label(text=help_entry["header"])
            if help_entry["link"] != "":
                header_split.operator("wm.url_open", text="", icon="LINKED", emboss=False).url = help_entry["link"]
            else:
                header_split.label(text="", icon="BLANK1")

            layout.separator()
            formatted_changes = parse_and_format_changes(self, help_entry["body"], 70)
            text_container = layout.column()
            for icon, text in formatted_changes:
                if icon != "NONE":
                    if isinstance(icon, int):
                        # If icon is an integer, use icon_value argument
                        text_container.label(text=text, icon_value=icon)
                    else:
                        # If icon is a string (icon name), use icon argument
                        text_container.label(text=text, icon=icon)
                else:
                    text_container.label(text=text)
        else:
            layout.label(text="Information not available for this topic.", icon="ERROR")

    def execute(self, context):
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=400)


classes = [
    RIG_UI_KeymapPreferences,
    RIG_UI_AddonPreferences,
    RIG_UI_OT_RedrawPanels,
    RIG_UI_OT_ToggleVisibility,
    RIG_UI_OT_HelpPopup,
]


def register_preferences_properties():
    bpy.types.WindowManager.rig_ui_keymap_prefs = bpy.props.PointerProperty(type=RIG_UI_KeymapPreferences)


def unregister_preferences_properties():
    del bpy.types.WindowManager.rig_ui_keymap_prefs


def register():
    # Register other classes
    for cls in classes:
        bpy.utils.register_class(cls)

    # Register the addon properties
    register_preferences_properties()


def unregister():
    # Unregister the addon properties
    unregister_preferences_properties()

    # Unregister other classes
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()


# ------------------------------------------------------------------------ #
