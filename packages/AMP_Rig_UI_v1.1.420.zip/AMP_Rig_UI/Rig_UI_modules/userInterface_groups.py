# ------------------------------------------------------------------------------------------------------------------------ #
# pro_grpupsuserInterface.py

import bpy
from .utils import refresh_ui, generate_unique_id
from .customIcons import get_icon


class RIG_UI_UL_groups_items(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)

        # Draw the group index
        column_index = row.column(align=True)
        column_index.alignment = "LEFT"
        column_index.label(text=f"#{index + 1}")

        column_groups = row.column(align=True)
        row_groups = column_groups.row(align=True)

        # Editable text field for the group name
        row_groups.prop(item, "name", text="", emboss=False)

        # Dropdown menu for the options
        row_groups.prop(item, "display_type", text="")


class RIG_UI_OT_groups_ListItem(bpy.types.PropertyGroup):
    unique_id: bpy.props.StringProperty(name="Unique ID", default="", override={"LIBRARY_OVERRIDABLE"})
    name: bpy.props.StringProperty(name="Name", default="Unnamed", override={"LIBRARY_OVERRIDABLE"})
    toggle: bpy.props.BoolProperty(name="Toggle", default=True, override={"LIBRARY_OVERRIDABLE"})
    display_type: bpy.props.EnumProperty(
        name="Display Type",
        items=[
            ("BOX", "Box", ""),
            ("LABEL", "Label", ""),
            ("LABEL_BOX", "Box with Label", ""),
            ("HEADER", "Toggleable header", ""),
            ("HEADER_BOX", "Toggleable header Box", ""),
            ("NONE", "No style", ""),
        ],
        default="BOX",
        override={"LIBRARY_OVERRIDABLE"},
    )


class RIG_UI_OT_groups_add_item(bpy.types.Operator):
    bl_idname = "general.add_item"
    bl_label = "Add List Item"
    list_id: bpy.props.StringProperty()
    index_id: bpy.props.StringProperty(default="")

    def execute(self, context):
        armature = context.active_object.data
        collection = getattr(armature, self.list_id)

        # Determine the next available group name
        group_names = [item.name for item in collection]
        new_group_name = "Group 1"
        index = 1

        while new_group_name in group_names:
            index += 1
            new_group_name = f"Group {index}"

        # Add the new group with the determined name
        item = collection.add()
        item.name = new_group_name

        # Assign a unique identifier to the new group
        item.unique_id = generate_unique_id()

        # Update the active index to the new item
        new_index = len(collection) - 1
        if self.index_id and hasattr(armature, self.index_id):
            setattr(armature, self.index_id, new_index)
        else:
            self.report({"WARNING"}, "Index ID not provided or incorrect.")

        refresh_ui(context)

        return {"FINISHED"}


class RIG_UI_OT_groups_remove_item(bpy.types.Operator):
    bl_idname = "general.remove_item"
    bl_label = "Remove List Item"
    list_id: bpy.props.StringProperty()
    index_id: bpy.props.StringProperty()

    def execute(self, context):
        armature = context.active_object.data
        collection = getattr(armature, self.list_id)
        index = getattr(armature, self.index_id)

        if len(collection) == 0:
            self.report({"WARNING"}, "No items to delete.")
            return {"FINISHED"}

        # Remove the group
        collection.remove(index)

        # Update the active index
        if index >= len(collection):
            index = len(collection) - 1

        setattr(armature, self.index_id, index)

        refresh_ui(context)

        return {"FINISHED"}


class RIG_UI_OT_groups_move_item_up(bpy.types.Operator):
    bl_idname = "general.move_item_up"
    bl_label = "Move Item Up"
    list_id: bpy.props.StringProperty()
    index_id: bpy.props.StringProperty()

    def execute(self, context):
        armature = context.active_object.data
        collection = getattr(armature, self.list_id)
        index = getattr(armature, self.index_id)

        if index > 0:
            collection.move(index, index - 1)
            setattr(armature, self.index_id, index - 1)  # Update index to keep selection
            refresh_ui(context)
        else:
            self.report({"WARNING"}, "Cannot move group further up.")
        return {"FINISHED"}


class RIG_UI_OT_groups_move_item_down(bpy.types.Operator):
    bl_idname = "general.move_item_down"
    bl_label = "Move Item Down"
    list_id: bpy.props.StringProperty()
    index_id: bpy.props.StringProperty()

    def execute(self, context):
        armature = context.active_object.data
        collection = getattr(armature, self.list_id)
        index = getattr(armature, self.index_id)

        if index < len(collection) - 1:
            collection.move(index, index + 1)
            setattr(armature, self.index_id, index + 1)  # Update index to keep selection
            refresh_ui(context)
        else:
            self.report({"WARNING"}, "Cannot move group further down.")
        return {"FINISHED"}


class RIG_UI_OT_groups_initialize_group_list(bpy.types.Operator):
    bl_idname = "general.initialize_group_list"
    bl_label = "Initialize List"
    list_name: bpy.props.StringProperty()

    def execute(self, context):
        armature = context.active_object.data

        # Check if the list already exists on the armature
        if not hasattr(armature, self.list_name):
            # Create a new CollectionProperty
            new_list = bpy.props.CollectionProperty(type=RIG_UI_OT_groups_ListItem)
            setattr(bpy.types.Armature, self.list_name, new_list)

            # Initialize the list on the specific armature
            setattr(armature, self.list_name, [])

            # Also initialize the active index property for this list
            active_index_name = f"active_{self.list_name}_index"
            setattr(bpy.types.Armature, active_index_name, bpy.props.IntProperty(default=0))
            setattr(armature, active_index_name, 0)
        else:
            pass

        # Trigger update of the UI
        context.area.tag_redraw()

        return {"FINISHED"}


def check_and_draw_init_button(context, layout, armature, list_name):
    # Try accessing the property directly
    try:
        list_exists = getattr(armature, list_name) is not None
    except AttributeError:
        list_exists = False

    if not list_exists:
        init_button = layout.operator("general.initialize_group_list", text="Create Groups")
        init_button.list_name = list_name
        return False
    return True


def draw_generic_list(context, layout, list_id, index_id, armature):
    # Ensure the armature's data is used for the list and index properties
    armature_data = armature.data

    list_row = layout.row(align=True)
    col_list = list_row.column(align=True)

    col_list.template_list("RIG_UI_UL_groups_items", "", armature_data, list_id, armature_data, index_id)

    col = list_row.column(align=True)
    add_op = col.operator("general.add_item", **get_icon("Add"), text="")
    add_op.list_id, add_op.index_id = list_id, index_id

    remove_op = col.operator("general.remove_item", **get_icon("Remove"), text="")
    remove_op.list_id, remove_op.index_id = list_id, index_id

    up_op = col.operator("general.move_item_up", **get_icon("Up"), text="")
    up_op.list_id, up_op.index_id = list_id, index_id

    down_op = col.operator("general.move_item_down", **get_icon("Down"), text="")
    down_op.list_id, down_op.index_id = list_id, index_id


def draw_bc_ui_groups_list(context, layout, armature):
    draw_generic_list(
        context,
        layout,
        "bone_collections_ui_groups",
        "active_bone_collection_ui_groups_index",
        armature,
    )


def draw_vb_ui_groups_list(context, layout, armature):
    draw_generic_list(
        context,
        layout,
        "visibility_bookmarks_ui_groups",
        "active_visibility_bookmark_ui_groups_index",
        armature,
    )


def draw_cp_ui_groups_list(context, layout, armature):
    draw_generic_list(
        context,
        layout,
        "custom_properties_ui_groups",
        "active_custom_property_ui_groups_index",
        armature,
    )


def close_popup(context):
    bpy.context.window.screen = bpy.context.window.screen


class RIG_UI_CustomProperties_OT_SelectGroup(bpy.types.Operator):
    """Select the Rig UI group where you want to assign this item
    - Ctrl + Click: Copy group ID to clipboard
    - Shift + Click: Paste group ID from clipboard
    - Alt + Click: Clear group ID
    - Click: Open the pop-up menu for group selection"""

    bl_idname = "rig_ui.select_group"
    bl_label = "Select Group"

    item_index: bpy.props.IntProperty()
    list_id: bpy.props.StringProperty()
    target: bpy.props.StringProperty()
    group_index: bpy.props.IntProperty()

    def execute(self, context):
        return {"FINISHED"}

    def invoke(self, context, event):
        armature = context.active_object.data
        target_list = getattr(armature, self.target, [])

        if self.item_index >= len(target_list):
            self.report({"ERROR"}, "Invalid item index")
            return {"CANCELLED"}

        item = target_list[self.item_index]

        if event.ctrl:
            bpy.context.window_manager.clipboard = item.group_id
            refresh_ui(context)

        elif event.shift:
            clipboard = bpy.context.window_manager.clipboard

            if any(group.unique_id == clipboard for group in armature.custom_properties_ui_groups):
                item.group_id = clipboard
                refresh_ui(context)
            else:
                self.report({"ERROR"}, "Clipboard does not contain a valid group ID")
        elif event.alt:
            item.group_id = ""
            refresh_ui(context)
        else:
            refresh_ui(context)
            return bpy.context.window_manager.invoke_props_dialog(self)

        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        armature = context.active_object.data

        # Use the list_id to get the correct group collection
        group_collection = getattr(armature, self.list_id, [])
        for group in group_collection:
            op = layout.operator("rig_ui.set_group_id", text=group.name)
            op.group_id = group.unique_id
            op.item_index = self.item_index
            op.list_id = self.list_id
            op.target = self.target


class RIG_UI_CustomProperties_OT_SetGroupID(bpy.types.Operator):
    """Set this group for the UI element"""

    bl_idname = "rig_ui.set_group_id"
    bl_label = "Set Group ID"

    group_id: bpy.props.StringProperty()
    item_index: bpy.props.IntProperty()
    list_id: bpy.props.StringProperty()
    target: bpy.props.StringProperty()

    def execute(self, context):
        armature = context.active_object.data
        target_list = getattr(armature, self.target, [])

        # Check for valid item index
        if self.item_index >= len(target_list):
            self.report({"ERROR"}, "Invalid item index")
            return {"CANCELLED"}

        item = target_list[self.item_index]
        item.group_id = self.group_id  # Set the group_id for the item

        # Copy the set group_id to the clipboard
        bpy.context.window_manager.clipboard = self.group_id

        # Refresh the UI to reflect changes
        refresh_ui(context)
        close_popup(context)
        return {"FINISHED"}


class RIG_UI_BoneCollection_OT_SelectGroup(bpy.types.Operator):
    """Select the Rig UI group where you want to assign this item
    - Ctrl + Click: Copy group ID to clipboard
    - Shift + Click: Paste group ID from clipboard
    - Alt + Click: Clear group ID
    - Click: Open the pop-up menu for group selection"""

    bl_idname = "bonecollection.select_group"
    bl_label = "Select Bone Collection Group"

    collection_name: bpy.props.StringProperty()

    # group_index: bpy.props.IntProperty(default=-1)

    def execute(self, context):
        # Execute can remain empty or include additional logic if needed
        return {"FINISHED"}

    def invoke(self, context, event):
        armature = context.active_object.data
        colls_all = getattr(armature, "collections_all", armature.collections)
        collection = colls_all.get(self.collection_name)

        if event.ctrl:
            bpy.context.window_manager.clipboard = collection.get("group_id", "")
            refresh_ui(context)
        elif event.shift:
            clipboard = bpy.context.window_manager.clipboard
            if any(group.unique_id == clipboard for group in armature.bone_collections_ui_groups):
                collection["group_id"] = clipboard
                refresh_ui(context)
            else:
                self.report({"ERROR"}, "Clipboard does not contain a valid group ID")
        elif event.alt:
            collection["group_id"] = ""
            refresh_ui(context)
        else:
            refresh_ui(context)
            return context.window_manager.invoke_props_dialog(self)

        refresh_ui(context)
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        armature = context.active_object.data
        for group in armature.bone_collections_ui_groups:
            op = layout.operator("bonecollection.set_group_id", text=group.name)
            op.collection_name = self.collection_name
            op.group_id = group.unique_id


class RIG_UI_BoneCollection_OT_SetGroupID(bpy.types.Operator):
    """Set the group ID for a bone collection"""

    bl_idname = "bonecollection.set_group_id"
    bl_label = "Set Bone Collection Group ID"

    collection_name: bpy.props.StringProperty()
    group_id: bpy.props.StringProperty()

    def execute(self, context):
        armature = context.active_object.data
        colls_all = getattr(armature, "collections_all", armature.collections)
        collection = colls_all.get(self.collection_name)
        if collection:
            collection["group_id"] = self.group_id

        # Copy the set group_id to the clipboard
        bpy.context.window_manager.clipboard = self.group_id

        close_popup(context)
        refresh_ui(context)
        return {"FINISHED"}


classes = [
    RIG_UI_UL_groups_items,
    RIG_UI_OT_groups_ListItem,
    RIG_UI_OT_groups_add_item,
    RIG_UI_OT_groups_remove_item,
    RIG_UI_OT_groups_move_item_up,
    RIG_UI_OT_groups_move_item_down,
    RIG_UI_OT_groups_initialize_group_list,
    RIG_UI_CustomProperties_OT_SelectGroup,
    RIG_UI_CustomProperties_OT_SetGroupID,
    RIG_UI_BoneCollection_OT_SelectGroup,
    RIG_UI_BoneCollection_OT_SetGroupID,
]


def register():
    # Register other classes
    for cls in classes:
        bpy.utils.register_class(cls)

    # Register properties
    bpy.types.Armature.bone_collections_ui_groups = bpy.props.CollectionProperty(type=RIG_UI_OT_groups_ListItem)
    bpy.types.Armature.visibility_bookmarks_ui_groups = bpy.props.CollectionProperty(type=RIG_UI_OT_groups_ListItem)
    bpy.types.Armature.custom_properties_ui_groups = bpy.props.CollectionProperty(type=RIG_UI_OT_groups_ListItem)
    bpy.types.Armature.active_bone_collection_ui_groups_index = bpy.props.IntProperty(default=0)
    bpy.types.Armature.active_visibility_bookmark_ui_groups_index = bpy.props.IntProperty(default=0)
    bpy.types.Armature.active_custom_property_ui_groups_index = bpy.props.IntProperty(default=0)


def unregister():
    # Unregister properties
    del bpy.types.Armature.bone_collections_ui_groups
    del bpy.types.Armature.visibility_bookmarks_ui_groups
    del bpy.types.Armature.custom_properties_ui_groups
    del bpy.types.Armature.active_bone_collection_ui_groups_index
    del bpy.types.Armature.active_visibility_bookmark_ui_groups_index
    del bpy.types.Armature.active_custom_property_ui_groups_index

    # Unregister other classes
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()

# end of file pro_grpupsuserInterface.py
# ------------------------------------------------------------------------------------------------------------------------ #
