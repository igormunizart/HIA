# ------------------------------------------------------------------------ #
# __init__.py
# Main script file
"""
                        #########################
                        ## AniMate Pro: RIG_UI ##
                        #########################

Copyright (C) 2024, Jose Ignacio de Andres, NotThatNDA, www.x.com/notthatnda

    GNU GENERAL PUBLIC LICENSE Version 3

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.
    If not, see <https://www.gnu.org/licenses/>.
    
"""

bl_info = {
    "name": "AniMatePro - Rig UI",
    "category": "Rigging",
    "description": "Supercharge your Character UIs",
    "author": "NotThatNDA",
    "blender": (4, 0, 0),
    "version": (1, 1, 420),
    "doc_url": "https://www.notion.so/notthatnda/Rig-UI-Documentation-ce181010f51e4d4c8ff1308ad884ed7e",
    "tracker_url": "https://www.notion.so/notthatnda/Features-Roadmap-and-Development-db480723be7a47da82d9f8371e2c5f92",
    "support": "COMMUNITY",
    "location": "View3D > Sidebar",
}


# from .Rig_UI_pro_modules import pro_transfer_setup
from .Rig_UI_modules.utils import check_pro_version

# ADDON_NAME = __package__.split(".")[0]

PRO_VERSION = check_pro_version()

IN_DEV = False

from .Rig_UI_modules import (
    boneCollections,
    customIcons,
    iconSelection,
    keymaps,
    popUpPanel,
    preferences,
    userInterface,
    userInterfaceHeader,
    userInterface_groups,
    userInterfaceMoveButtons,
    import_ui_from_bc,
    utils,
)


if PRO_VERSION:
    from .Rig_UI_pro_modules import (
        pro_utils,
        pro_move_bone_collections,
        pro_rig_custom_properties,
        pro_visibility_bookmarks,
        pro_exportToScript,
        pro_autorig_pro_panel,
        pro_custom_bone_properties_panel,
        pro_rigify_panel,
        pro_transfer_setup,
        pro_ik_fk_toggle,
    )


# Global properties
rig_ui_popup_instance = None
rig_ui_panel_toggle = False


def register_modules(is_pro=False):
    """Register modules, with an option to only register 'pro' modules if is_pro is True."""
    for name, module in globals().items():
        if hasattr(module, "register"):
            # Check if we're dealing with a pro module and the PRO_VERSION is enabled or if it's a standard module
            if (is_pro and name.startswith("pro_") and PRO_VERSION) or (not is_pro and not name.startswith("pro_")):
                if module == customIcons:
                    module.load_icons()
                else:
                    module.register()


def unregister_modules(is_pro=False):
    """Unregister modules, with an option to only unregister 'pro' modules if is_pro is True."""
    for name, module in reversed(list(globals().items())):
        if hasattr(module, "unregister"):
            # Check if we're dealing with a pro module and the PRO_VERSION is enabled or if it's a standard module
            if (is_pro and name.startswith("pro_") and PRO_VERSION) or (not is_pro and not name.startswith("pro_")):
                if module == customIcons:
                    module.unload_icons()
                else:
                    module.unregister()


def register():
    """Register the addon."""

    # First, register standard modules
    register_modules(is_pro=False)

    # Then, if PRO_VERSION is True, register pro modules
    register_modules(is_pro=True)


def unregister():
    """Unregister the addon."""

    # First, unregister pro modules if PRO_VERSION is True
    unregister_modules(is_pro=True)

    # Then, unregister standard modules
    unregister_modules(is_pro=False)


if __name__ == "__main__":
    register()

if __name__ == "__main__":
    register()
# ------------------------------------------------------------------------ #
