# documentation.py

docs = {
    # Preferences Keymaps, Keymap settings
    "bc_keymaps": {
        "header": "Keymap seetings for Rig UI",
        "link": "",
        "body": """
- Improved Move Bone Collection: Use the alternative built in hoekey to move bones between bone collections.

- Pop up panel: Hotkey to open the Rig UI pop up panel.

- Default Move Bone Collection: Use the Blender's default built in hotkey to move bones between bone collections.

""",
    },
    # Preferences, Bone Collection buttons
    "bc_modifier_keys": {
        "header": "Hotkeys for Bone Collections",
        "link": "",
        "body": """
Modifiers allow you to enhance the functionality of how you interact with bone collections.
You can use various modifier keys (Shift, Ctrl, Alt) in combination with mouse clicks to perform different actions on bone collections.

Here are the default actions:
- LMB: Select bones in the collection, unhide if hidden.
- Shift + LMB: Add the bones in the collection to the current selection.
- Ctrl + LMB: Toggle collection visibility.
- Ctrl + Shift + LMB: Isolate collection visibility / Restore previous collection state.

You can customize these modifiers in the preferences, go to Rig UI preferences > Keymaps.
""",
    },
    # Preferences, Bone Collection buttons
    "general_experimental": {
        "header": "Experimental feature",
        "link": "",
        "body": """
Experimental features are not fully tested and may not work as expected. Use them at your own risk.
They are generally not documented and may be implemented in future versions or scrapped if they don't work as intended.
To enable or disable experimental features, go to Rig UI preferences > General.
""",
    },
}
