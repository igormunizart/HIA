from . import Localizer, utils

experimental_panels = [utils.BRD_EXPERIMENTAL_PT_Panel, Localizer.localizer_panels]
