# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "HiA Previz",
    "author" : "Igor Munz", 
    "description" : "Addon para o pipeline de Previz do Histera Studios!",
    "blender" : (4, 3, 0),
    "version" : (0, 0, 4),
    "location" : "Sao Paulo",
    "warning" : "Existem alguns outros addons que precisam estar juntos para funcionar, consulte a documentacao",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews


addon_keymaps = {}
_icons = None
class SNA_PT_HIANIMATION_PREVIZ_V001_1CD2A(bpy.types.Panel):
    bl_label = 'HiAnimation Previz v0.0.1'
    bl_idname = 'SNA_PT_HIANIMATION_PREVIZ_V001_1CD2A'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'HiA Previz'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout


class SNA_PT_TEST_BEAA7(bpy.types.Panel):
    bl_label = 'test'
    bl_idname = 'SNA_PT_TEST_BEAA7'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        attr_3429E = '["' + str('maxFocalLength' + '"]') 
        layout.prop(bpy.context.scene.camera.data, attr_3429E, text='max Focal Length', icon_value=0, emboss=True)
        attr_0569F = '["' + str('minFocalLength' + '"]') 
        layout.prop(bpy.context.scene.camera.data, attr_0569F, text='min Focal Length', icon_value=0, emboss=True)
        layout.separator(factor=1.0)
        attr_1FFD2 = '["' + str('minLensDist' + '"]') 
        layout.prop(bpy.context.scene.camera.data, attr_1FFD2, text='min Distortion', icon_value=0, emboss=True)
        attr_702EC = '["' + str('maxLensDist' + '"]') 
        layout.prop(bpy.context.scene.camera.data, attr_702EC, text='max Distortion', icon_value=0, emboss=True)


class SNA_PT_TEST_8DC57(bpy.types.Panel):
    bl_label = 'test'
    bl_idname = 'SNA_PT_TEST_8DC57'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout


def sna_add_to_sequencer_ht_header_7BF5E(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('sequencer.refresh_all', text='', icon_value=647, emboss=True, depress=False)


def sna_add_to_dopesheet_ht_header_3FCD4(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('sna.op_tomaster_60d57', text='Switch to Edit', icon_value=688, emboss=True, depress=False)


class SNA_OT_Op_Tomaster_60D57(bpy.types.Operator):
    bl_idname = "sna.op_tomaster_60d57"
    bl_label = "OP_toMaster"
    bl_description = "Troque para a scene Master e para o Workspace Video Editing"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        # Switch to a different scene

        def switch_scene(scene_name):
            if scene_name in bpy.data.scenes:
                bpy.context.window.scene = bpy.data.scenes[scene_name]
                print(f"Switched to scene: {scene_name}")
            else:
                print(f"Scene '{scene_name}' not found")
        # Switch to a different workspace

        def switch_workspace(workspace_name):
            if workspace_name in bpy.data.workspaces:
                bpy.context.window.workspace = bpy.data.workspaces[workspace_name]
                print(f"Switched to workspace: {workspace_name}")
            else:
                print(f"Workspace '{workspace_name}' not found")
        # Example usage
        switch_scene("_Master_")  # Replace with your scene name
        switch_workspace("Video Editing")  # Replace with your workspace name (e.g., "Layout", "Modeling", "Sculpting", etc.)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_graph_ht_header_07D12(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('sna.op_tomaster_60d57', text='Switch to Edit', icon_value=688, emboss=True, depress=False)


class SNA_OT_Opmixamo_3Aeb4(bpy.types.Operator):
    bl_idname = "sna.opmixamo_3aeb4"
    bl_label = "opMixamo"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.mr.make_rig('INVOKE_DEFAULT', bake_anim=True, ik_arms=True, ik_legs=True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_CAMERA_C12BA(bpy.types.Panel):
    bl_label = 'Camera'
    bl_idname = 'SNA_PT_CAMERA_C12BA'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_HIANIMATION_PREVIZ_V001_1CD2A'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout


class SNA_PT_BASIC_E42E1(bpy.types.Panel):
    bl_label = 'Basic'
    bl_idname = 'SNA_PT_BASIC_E42E1'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'HIDE_HEADER'}
    bl_parent_id = 'SNA_PT_CAMERA_C12BA'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        if hasattr(bpy.types,"ADD_CAMERA_RIGS_PT_camera_rig_ui"):
            if not hasattr(bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui, "poll") or bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui.poll(context):
                bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui.draw(self, context)
            else:
                layout.label(text="Can't display this panel here!", icon="ERROR")
        else:
            layout.label(text="Can't display this panel!", icon="ERROR")


class SNA_PT_DOF_1575A(bpy.types.Panel):
    bl_label = 'DOF'
    bl_idname = 'SNA_PT_DOF_1575A'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_CAMERA_C12BA'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        if hasattr(bpy.types,"ADD_CAMERA_RIGS_PT_camera_rig_ui_dof"):
            if not hasattr(bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui_dof, "poll") or bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui_dof.poll(context):
                bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui_dof.draw(self, context)
            else:
                layout.label(text="Can't display this panel here!", icon="ERROR")
        else:
            layout.label(text="Can't display this panel!", icon="ERROR")


class SNA_PT_VIEWPORT_CONFIG_61DF9(bpy.types.Panel):
    bl_label = 'Viewport Config'
    bl_idname = 'SNA_PT_VIEWPORT_CONFIG_61DF9'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_CAMERA_C12BA'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        if hasattr(bpy.types,"ADD_CAMERA_RIGS_PT_camera_rig_ui_viewport"):
            if not hasattr(bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui_viewport, "poll") or bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui_viewport.poll(context):
                bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui_viewport.draw(self, context)
            else:
                layout.label(text="Can't display this panel here!", icon="ERROR")
        else:
            layout.label(text="Can't display this panel!", icon="ERROR")


class SNA_PT_PROPRIEDADES_790C8(bpy.types.Panel):
    bl_label = 'Propriedades'
    bl_idname = 'SNA_PT_PROPRIEDADES_790C8'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_CAMERA_C12BA'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        if hasattr(bpy.types,"ADD_CAMERA_RIGS_PT_camera_rig_ui_visibility"):
            if not hasattr(bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui_visibility, "poll") or bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui_visibility.poll(context):
                bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui_visibility.draw(self, context)
            else:
                layout.label(text="Can't display this panel here!", icon="ERROR")
        else:
            layout.label(text="Can't display this panel!", icon="ERROR")


class SNA_PT_LENS_DISTORTION_A9D57(bpy.types.Panel):
    bl_label = 'Lens Distortion'
    bl_idname = 'SNA_PT_LENS_DISTORTION_A9D57'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_CAMERA_C12BA'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_8E8FD = layout.box()
        box_8E8FD.alert = False
        box_8E8FD.enabled = True
        box_8E8FD.active = True
        box_8E8FD.use_property_split = False
        box_8E8FD.use_property_decorate = False
        box_8E8FD.alignment = 'Expand'.upper()
        box_8E8FD.scale_x = 1.0
        box_8E8FD.scale_y = 1.0
        if not True: box_8E8FD.operator_context = "EXEC_DEFAULT"
        row_FF37E = box_8E8FD.row(heading='', align=False)
        row_FF37E.alert = False
        row_FF37E.enabled = True
        row_FF37E.active = True
        row_FF37E.use_property_split = False
        row_FF37E.use_property_decorate = False
        row_FF37E.scale_x = 1.0
        row_FF37E.scale_y = 1.0
        row_FF37E.alignment = 'Center'.upper()
        row_FF37E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_FF37E.label(text='Eevee Lens Distortion', icon_value=0)
        split_855B5 = box_8E8FD.split(factor=1.0, align=True)
        split_855B5.alert = False
        split_855B5.enabled = True
        split_855B5.active = True
        split_855B5.use_property_split = False
        split_855B5.use_property_decorate = False
        split_855B5.scale_x = 1.0
        split_855B5.scale_y = 1.0
        split_855B5.alignment = 'Center'.upper()
        if not True: split_855B5.operator_context = "EXEC_DEFAULT"
        attr_97B41 = '["' + str('autoLensDist' + '"]') 
        split_855B5.prop(bpy.context.scene.camera.data, attr_97B41, text='Auto Lens Distortion', icon_value=0, emboss=True, toggle=True)
        if bpy.context.scene.camera.data['autoLensDist']:
            box_8E8FD.popover('SNA_PT_TEST_BEAA7', text='Min/Max Range', icon_value=0)
        else:
            attr_D3A64 = '["' + str('lensDist' + '"]') 
            box_8E8FD.prop(bpy.context.scene.camera.data, attr_D3A64, text='Lens Distortion', icon_value=0, emboss=True, slider=True)


class SNA_PT_SHAKIFY_EAC0D(bpy.types.Panel):
    bl_label = 'Shakify'
    bl_idname = 'SNA_PT_SHAKIFY_EAC0D'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_CAMERA_C12BA'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        if hasattr(bpy.types,"DATA_PT_camera_shakify"):
            if not hasattr(bpy.types.DATA_PT_camera_shakify, "poll") or bpy.types.DATA_PT_camera_shakify.poll(context):
                bpy.types.DATA_PT_camera_shakify.draw(self, context)
            else:
                layout.label(text="Can't display this panel here!", icon="ERROR")
        else:
            layout.label(text="Can't display this panel!", icon="ERROR")


class SNA_PT_MIXAMO_1FEC9(bpy.types.Panel):
    bl_label = 'Mixamo'
    bl_idname = 'SNA_PT_MIXAMO_1FEC9'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_CAMERA_C12BA'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        op = layout.operator('import_scene.fbx', text='Import AnimMixamo', icon_value=129, emboss=True, depress=False)
        op = layout.operator('sna.opmixamo_3aeb4', text='Convert AnimMixamo', icon_value=203, emboss=True, depress=False)
        col_3A7D7 = layout.column(heading='', align=False)
        col_3A7D7.alert = False
        col_3A7D7.enabled = True
        col_3A7D7.active = True
        col_3A7D7.use_property_split = False
        col_3A7D7.use_property_decorate = False
        col_3A7D7.scale_x = 1.0
        col_3A7D7.scale_y = 1.0
        col_3A7D7.alignment = 'Center'.upper()
        col_3A7D7.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_3A7D7.label(text='Name and Save your Action', icon_value=0)
        split_27C01 = col_3A7D7.split(factor=0.75, align=True)
        split_27C01.alert = False
        split_27C01.enabled = True
        split_27C01.active = True
        split_27C01.use_property_split = False
        split_27C01.use_property_decorate = False
        split_27C01.scale_x = 1.0
        split_27C01.scale_y = 1.0
        split_27C01.alignment = 'Expand'.upper()
        if not True: split_27C01.operator_context = "EXEC_DEFAULT"
        split_27C01.prop(bpy.context.active_object.animation_data.action, 'name', text='', icon_value=0, emboss=True)
        split_27C01.prop(bpy.data.actions[bpy.context.active_object.animation_data.action.name], 'use_fake_user', text='', icon_value=0, emboss=True)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_PT_HIANIMATION_PREVIZ_V001_1CD2A)
    bpy.utils.register_class(SNA_PT_TEST_BEAA7)
    bpy.utils.register_class(SNA_PT_TEST_8DC57)
    bpy.types.SEQUENCER_HT_header.append(sna_add_to_sequencer_ht_header_7BF5E)
    bpy.types.DOPESHEET_HT_header.append(sna_add_to_dopesheet_ht_header_3FCD4)
    bpy.utils.register_class(SNA_OT_Op_Tomaster_60D57)
    bpy.types.GRAPH_HT_header.append(sna_add_to_graph_ht_header_07D12)
    bpy.utils.register_class(SNA_OT_Opmixamo_3Aeb4)
    bpy.utils.register_class(SNA_PT_CAMERA_C12BA)
    bpy.utils.register_class(SNA_PT_BASIC_E42E1)
    bpy.utils.register_class(SNA_PT_DOF_1575A)
    bpy.utils.register_class(SNA_PT_VIEWPORT_CONFIG_61DF9)
    bpy.utils.register_class(SNA_PT_PROPRIEDADES_790C8)
    bpy.utils.register_class(SNA_PT_LENS_DISTORTION_A9D57)
    bpy.utils.register_class(SNA_PT_SHAKIFY_EAC0D)
    bpy.utils.register_class(SNA_PT_MIXAMO_1FEC9)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_PT_HIANIMATION_PREVIZ_V001_1CD2A)
    bpy.utils.unregister_class(SNA_PT_TEST_BEAA7)
    bpy.utils.unregister_class(SNA_PT_TEST_8DC57)
    bpy.types.SEQUENCER_HT_header.remove(sna_add_to_sequencer_ht_header_7BF5E)
    bpy.types.DOPESHEET_HT_header.remove(sna_add_to_dopesheet_ht_header_3FCD4)
    bpy.utils.unregister_class(SNA_OT_Op_Tomaster_60D57)
    bpy.types.GRAPH_HT_header.remove(sna_add_to_graph_ht_header_07D12)
    bpy.utils.unregister_class(SNA_OT_Opmixamo_3Aeb4)
    bpy.utils.unregister_class(SNA_PT_CAMERA_C12BA)
    bpy.utils.unregister_class(SNA_PT_BASIC_E42E1)
    bpy.utils.unregister_class(SNA_PT_DOF_1575A)
    bpy.utils.unregister_class(SNA_PT_VIEWPORT_CONFIG_61DF9)
    bpy.utils.unregister_class(SNA_PT_PROPRIEDADES_790C8)
    bpy.utils.unregister_class(SNA_PT_LENS_DISTORTION_A9D57)
    bpy.utils.unregister_class(SNA_PT_SHAKIFY_EAC0D)
    bpy.utils.unregister_class(SNA_PT_MIXAMO_1FEC9)
