# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "HA_animbot",
    "author" : "Igor Muniz", 
    "description" : "Animbot? for blender",
    "blender" : (4, 2, 0),
    "version" : (0, 0, 1),
    "location" : "São Paulo, Brazil",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "Animation" 
}


import bpy
import bpy.utils.previews
from bpy.props import (StringProperty, PointerProperty, FloatProperty, BoolProperty)


addon_keymaps = {}
_icons = None


def sna_add_to_view3d_pt_tools_active_23488(self, context):
    if not (False):
        layout = self.layout
        col_F01EC = layout.column(heading='', align=True)
        col_F01EC.alert = False
        col_F01EC.enabled = True
        col_F01EC.active = True
        col_F01EC.use_property_split = False
        col_F01EC.use_property_decorate = False
        col_F01EC.scale_x = 1.0
        col_F01EC.scale_y = 1.0
        col_F01EC.alignment = 'Left'.upper()
        col_F01EC.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        box_59BF1 = col_F01EC.box()
        box_59BF1.alert = False
        box_59BF1.enabled = True
        box_59BF1.active = True
        box_59BF1.use_property_split = False
        box_59BF1.use_property_decorate = False
        box_59BF1.alignment = 'Expand'.upper()
        box_59BF1.scale_x = 1.0
        box_59BF1.scale_y = 1.0
        if not True: box_59BF1.operator_context = "EXEC_DEFAULT"
        op = box_59BF1.operator('sna.store_relationship_43c17', text='', icon_value=75, emboss=True, depress=False)
        box_CA4D1 = col_F01EC.box()
        box_CA4D1.alert = False
        box_CA4D1.enabled = True
        box_CA4D1.active = True
        box_CA4D1.use_property_split = False
        box_CA4D1.use_property_decorate = False
        box_CA4D1.alignment = 'Expand'.upper()
        box_CA4D1.scale_x = 1.0
        box_CA4D1.scale_y = 1.0
        if not True: box_CA4D1.operator_context = "EXEC_DEFAULT"
        op = box_CA4D1.operator('sna.apply_transformations_22941', text='', icon_value=166, emboss=True, depress=False)


class SNA_OT_Apply_Transformations_22941(bpy.types.Operator):
    bl_idname = "sna.apply_transformations_22941"
    bl_label = "Apply transformations"
    bl_description = "Apply global transformation based on Source Object stored, and create a keyframe."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.bone.apply_transformation('INVOKE_DEFAULT', )
        bpy.ops.anim.keyframe_insert('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Store_Relationship_43C17(bpy.types.Operator):
    bl_idname = "sna.store_relationship_43c17"
    bl_label = "Store Relationship"
    bl_description = "Save global relationship beetween source and target, select the child object first."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.bone.save_relation('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


import mathutils
from bpy.types import (Panel, Operator, PropertyGroup)
# Structure to store bone relationships
class BoneRelationProperty(PropertyGroup):
    source_armature: StringProperty(
        name="Source Armature",
        description="Name of source armature",

        default=""
    )
    source_bone: StringProperty(
        name="Source Bone",
        description="Name of source bone",

        default=""
    )
    target_armature: StringProperty(
        name="Target Armature",
        description="Name of target armature",

        default=""
    )
    target_bone: StringProperty(
        name="Target Bone",
        description="Name of target bone",

        default=""
    )
    # Individual matrix elements
    m00: FloatProperty(default=1.0)
    m01: FloatProperty(default=0.0)
    m02: FloatProperty(default=0.0)
    m03: FloatProperty(default=0.0)
    m10: FloatProperty(default=0.0)
    m11: FloatProperty(default=1.0)
    m12: FloatProperty(default=0.0)
    m13: FloatProperty(default=0.0)
    m20: FloatProperty(default=0.0)
    m21: FloatProperty(default=0.0)
    m22: FloatProperty(default=1.0)
    m23: FloatProperty(default=0.0)
    m30: FloatProperty(default=0.0)
    m31: FloatProperty(default=0.0)
    m32: FloatProperty(default=0.0)
    m33: FloatProperty(default=1.0)
    # Enable/disable relationship
    enabled: BoolProperty(
        name="Enabled",
        description="Enable/disable this relationship",

        default=True
    )


# Operator to save bone relationship
class BONE_OT_SaveRelation(Operator):
    bl_idname = "bone.save_relation"
    bl_label = "Save Relationship"
    bl_description = "Saves the current relationship between selected bones"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        # Check if we're in pose mode and have at least two bones selected
        return (context.mode == 'POSE' and
                context.selected_pose_bones and
                len(context.selected_pose_bones) >= 2)

    def execute(self, context):
        # Get the two selected bones
        if len(context.selected_pose_bones) < 2:
            self.report({'ERROR'}, "Select at least two bones")
            return {'CANCELLED'}
        # Consider the active bone as the source and the other as the target
        source_bone = context.active_pose_bone
        target_bone = None
        for bone in context.selected_pose_bones:
            if bone != source_bone:
                target_bone = bone
                break
        if not source_bone:
            self.report({'ERROR'}, "Could not determine source and target")
            return {'CANCELLED'}
        # Get global transformations of bones
        source_matrix_world = source_bone.id_data.matrix_world @ source_bone.matrix
        target_matrix_world = target_bone.id_data.matrix_world @ target_bone.matrix
        # Calculate offset matrix (difference between transformations)
        # This matrix represents the transformation needed to go from source to target
        offset_matrix = target_matrix_world.inverted() @ source_matrix_world
        # Store the relationship
        bone_relation = context.scene.bone_relations
        bone_relation.source_armature = source_bone.id_data.name
        bone_relation.source_bone = source_bone.name
        bone_relation.target_armature = target_bone.id_data.name
        bone_relation.target_bone = target_bone.name
        # Store matrix elements individually
        bone_relation.m00 = offset_matrix[0][0]
        bone_relation.m01 = offset_matrix[0][1]
        bone_relation.m02 = offset_matrix[0][2]
        bone_relation.m03 = offset_matrix[0][3]
        bone_relation.m10 = offset_matrix[1][0]
        bone_relation.m11 = offset_matrix[1][1]
        bone_relation.m12 = offset_matrix[1][2]
        bone_relation.m13 = offset_matrix[1][3]
        bone_relation.m20 = offset_matrix[2][0]
        bone_relation.m21 = offset_matrix[2][1]
        bone_relation.m22 = offset_matrix[2][2]
        bone_relation.m23 = offset_matrix[2][3]
        bone_relation.m30 = offset_matrix[3][0]
        bone_relation.m31 = offset_matrix[3][1]
        bone_relation.m32 = offset_matrix[3][2]
        bone_relation.m33 = offset_matrix[3][3]
        self.report({'INFO'}, f"Relationship saved between {source_bone.name} and {target_bone.name}")
        return {'FINISHED'}


# Operator to apply transformation based on saved relationship
class BONE_OT_ApplyTransformation(Operator):
    bl_idname = "bone.apply_transformation"
    bl_label = "Apply Transformation"
    bl_description = "Applies transformation from source bone to target while maintaining relationship"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        # Check if we have a saved relationship and are in pose mode
        relations = context.scene.bone_relations
        return (context.mode == 'POSE' and
                relations.source_armature and
                relations.source_bone and
                relations.target_armature and
                relations.target_bone)

    def execute(self, context):
        relations = context.scene.bone_relations
        if not relations.enabled:
            self.report({'WARNING'}, "This relationship is disabled")
            return {'CANCELLED'}
        # Get armature objects
        if relations.source_armature not in bpy.data.objects or relations.target_armature not in bpy.data.objects:
            self.report({'ERROR'}, "Armatures not found")
            return {'CANCELLED'}
        source_arm = bpy.data.objects[relations.source_armature]
        target_arm = bpy.data.objects[relations.target_armature]
        # Check if bones exist
        if relations.source_bone not in source_arm.pose.bones or relations.target_bone not in target_arm.pose.bones:
            self.report({'ERROR'}, "Bones not found")
            return {'CANCELLED'}
        source_bone = source_arm.pose.bones[relations.source_bone]
        target_bone = target_arm.pose.bones[relations.target_bone]
        # Reconstruct offset matrix from individual elements
        offset_matrix = mathutils.Matrix((
            (relations.m00, relations.m01, relations.m02, relations.m03),
            (relations.m10, relations.m11, relations.m12, relations.m13),
            (relations.m20, relations.m21, relations.m22, relations.m23),
            (relations.m30, relations.m31, relations.m32, relations.m33)
        ))
        # Get global transformation of source bone
        source_matrix_world = source_arm.matrix_world @ source_bone.matrix
        # Calculate new transformation for target bone
        # using saved relationship (offset)
        target_matrix_world = source_matrix_world @ offset_matrix.inverted()
        # Convert back to target bone's local space
        target_matrix_local = target_arm.matrix_world.inverted() @ target_matrix_world
        # Set new matrix for target bone
        target_bone.matrix = target_matrix_local
        # Deselect source bone
        source_bone.bone.select = False
        # Select target bone
        target_bone.bone.select = True
        self.report({'INFO'}, f"Transformation applied from {source_bone.name} to {target_bone.name}")
        return {'FINISHED'}


# UI Panel
class BONE_PT_RelationPanel(Panel):
    bl_label = "Bone Relation Manager"
    bl_idname = "BONE_PT_relation_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Bone Relations'

    def draw(self, context):
        layout = self.layout
        relations = context.scene.bone_relations
        box = layout.box()
        box.label(text="Save Relationship:")
        box.operator("bone.save_relation")
        box = layout.box()
        box.label(text="Current Relationship:")
        row = box.row()
        row.prop(relations, "enabled", text="Enabled")
        if relations.source_bone and relations.target_bone:
            box.label(text=f"Source: {relations.source_armature} - {relations.source_bone}")
            box.label(text=f"Target: {relations.target_armature} - {relations.target_bone}")
            box.operator("bone.apply_transformation")
        else:
            box.label(text="No relationship saved")


# Class registration
classes = (
    BoneRelationProperty,
    BONE_OT_SaveRelation,
    BONE_OT_ApplyTransformation,
    BONE_PT_RelationPanel,


)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.VIEW3D_PT_tools_active.append(sna_add_to_view3d_pt_tools_active_23488)
    bpy.utils.register_class(SNA_OT_Apply_Transformations_22941)
    bpy.utils.register_class(SNA_OT_Store_Relationship_43C17)
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)
    # Register scene properties
    bpy.types.Scene.bone_relations = PointerProperty(type=BoneRelationProperty)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.types.VIEW3D_PT_tools_active.remove(sna_add_to_view3d_pt_tools_active_23488)
    bpy.utils.unregister_class(SNA_OT_Apply_Transformations_22941)
    bpy.utils.unregister_class(SNA_OT_Store_Relationship_43C17)
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
    # Remove scene properties
    del bpy.types.Scene.bone_relations
