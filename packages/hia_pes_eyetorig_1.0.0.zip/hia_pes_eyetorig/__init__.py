# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "HiA_PES_EyeToRig",
    "author" : "Igor Muniz", 
    "description" : "Transforme objetos selecionados para prp.Olhos-rig",
    "blender" : (4, 3, 2),
    "version" : (1, 0, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import os
from bpy.types import Panel, Operator, PropertyGroup


addon_keymaps = {}
_icons = None
class SNA_OT_Operator_89D37(bpy.types.Operator):
    bl_idname = "sna.operator_89d37"
    bl_label = "Operator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        before_data = list(bpy.data.collections)
        bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'prop_olho-RIG.blend') + r'\Collection', filename='prp.olho', link=False)
        new_data = list(filter(lambda d: not d in before_data, list(bpy.data.collections)))
        appended_CCCED = None if not new_data else new_data[0]
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


bl_info = {
    "name": "Collection Duplicator with Transform",
    "author": "Seu Nome",
    "version": (1, 0),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > Collection Duplicator",
    "description": "Duplica uma collection e aplica transformações dos objetos selecionados nas armatures",
    "warning": "",
    "doc_url": "",
    "category": "Object",


}


from bpy.props import StringProperty, PointerProperty, FloatProperty
import mathutils
class CollectionDuplicatorProperties(PropertyGroup):
    # Propriedade para armazenar o nome da collection
    collection_name: StringProperty(
        name="Nome da Collection",
        description="Nome da collection que será duplicada",

        default="",
    )
    # Fator multiplicador de escala
    scale_factor: FloatProperty(
        name="Fator de Escala",
        description="Fator multiplicador de escala a ser aplicado (1 = escala original)",

        default=1.0,
        min=0.01,
        soft_max=10.0,
        step=10,
        precision=2
    )


class OBJECT_OT_duplicate_collection(Operator):
    bl_idname = "object.duplicate_collection_apply_transform"
    bl_label = "Make"
    bl_description = "Duplica a collection e aplica a transformação do(s) objeto(s) selecionado(s) no(s) objeto(s) Armature"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        props = context.scene.collection_duplicator_props
        return (len(context.selected_objects) > 0 and 
                props.collection_name in bpy.data.collections)

    def execute(self, context):
        props = context.scene.collection_duplicator_props
        source_collection_name = props.collection_name
        selected_objects = context.selected_objects.copy()  # Copia a lista para não modificá-la durante o loop
        scale_factor = props.scale_factor  # Obtém o fator de escala
        # Verifica se a collection existe
        if source_collection_name not in bpy.data.collections:
            self.report({'ERROR'}, f"Collection '{source_collection_name}' não encontrada!")
            return {'CANCELLED'}
        # Verifica se há objeto(s) selecionado(s)
        if not selected_objects:
            self.report({'ERROR'}, "Nenhum objeto selecionado! Selecione pelo menos um objeto para usar sua transformação.")
            return {'CANCELLED'}
        # Contador para acompanhar o número de cópias criadas com sucesso
        successful_copies = 0
        last_armature = None
        # Para cada objeto selecionado, cria uma cópia da collection
        for target_obj in selected_objects:
            # Obtém a matriz global do objeto atual
            transform_matrix = target_obj.matrix_world.copy()
            # Aplica o fator de escala à matriz de transformação
            if scale_factor != 1.0:
                # Extrai os componentes de localização, rotação e escala da matriz
                loc, rot, scale = transform_matrix.decompose()
                # Aplica o fator multiplicador à escala
                scale = mathutils.Vector((
                    scale.x * scale_factor,
                    scale.y * scale_factor,
                    scale.z * scale_factor
                ))
                # Reconstrói a matriz com a escala modificada
                loc_mat = mathutils.Matrix.Translation(loc)
                rot_mat = rot.to_matrix().to_4x4()
                scale_mat = mathutils.Matrix()
                scale_mat[0][0] = scale.x
                scale_mat[1][1] = scale.y
                scale_mat[2][2] = scale.z
                # Combina os componentes para criar a nova matriz
                transform_matrix = loc_mat @ rot_mat @ scale_mat
            # Obtém a collection original
            source_collection = bpy.data.collections[source_collection_name]
            # Armazena a seleção e o objeto ativo originais
            original_selected_objects = context.selected_objects.copy()
            original_active_object = context.active_object
            # Deseleciona todos os objetos
            bpy.ops.object.select_all(action='DESELECT')
            # Função recursiva para selecionar todos os objetos em uma collection e suas subcollections

            def select_objects_in_collection(collection):
                # Seleciona objetos nesta collection
                for obj in collection.objects:
                    if obj.name in context.view_layer.objects:
                        obj.select_set(True)
                # Processa subcollections recursivamente
                for child_collection in collection.children:
                    select_objects_in_collection(child_collection)
            # Seleciona todos os objetos na collection de origem
            select_objects_in_collection(source_collection)
            # Verifica se algum objeto foi selecionado
            if not context.selected_objects:
                self.report({'WARNING'}, f"Nenhum objeto encontrado na collection '{source_collection_name}'!")
                continue
            # Define qualquer objeto selecionado como ativo (necessário para o operador duplicate_move_linked)
            context.view_layer.objects.active = context.selected_objects[0]
            # Usa o operador de duplicação do Blender para criar cópias linkadas
            bpy.ops.object.duplicate_move_linked()
            # Os objetos duplicados agora estão selecionados
            duplicated_objects = context.selected_objects
            # Cria um nome para a nova collection com um contador se necessário
            collection_name_base = f"{source_collection_name}_copy"
            collection_name = collection_name_base
            counter = 1
            # Garante um nome único para a collection
            while collection_name in bpy.data.collections:
                collection_name = f"{collection_name_base}_{counter}"
                counter += 1
            # Cria uma nova collection para os objetos duplicados
            new_collection = bpy.data.collections.new(collection_name)
            bpy.context.scene.collection.children.link(new_collection)
            # Move os objetos duplicados para a nova collection
            for obj in duplicated_objects:
                # Remove o objeto de suas collections atuais
                for coll in obj.users_collection:
                    coll.objects.unlink(obj)
                # Adiciona à nova collection
                new_collection.objects.link(obj)
            # Procura o objeto Armature entre os objetos duplicados
            armature_obj = None
            for obj in duplicated_objects:
                if obj.type == 'ARMATURE':
                    armature_obj = obj
                    last_armature = obj  # Guarda o último armature para selecioná-lo no final
                    break
            if not armature_obj:
                self.report({'WARNING'}, f"Nenhum objeto Armature encontrado na collection duplicada '{collection_name}'!")
                continue
            # Aplica a matriz global modificada ao objeto Armature
            armature_obj.matrix_world = transform_matrix
            successful_copies += 1
        # Após concluir todas as duplicações, seleciona o último armature processado
        if successful_copies > 0 and last_armature:
            # Deseleciona todos os objetos
            bpy.ops.object.select_all(action='DESELECT')
            # Seleciona e ativa o último objeto Armature
            last_armature.select_set(True)
            context.view_layer.objects.active = last_armature
        # Reporta o resultado baseado no número de cópias bem-sucedidas
        scale_info = f" (Escala: {scale_factor}x)" if scale_factor != 1.0 else ""
        if successful_copies == 0:
            self.report({'ERROR'}, "Nenhuma cópia foi criada com sucesso!")
            return {'CANCELLED'}
        elif successful_copies == 1:
            self.report({'INFO'}, f"1 collection duplicada com transformação aplicada ao Armature{scale_info}!")
        else:
            self.report({'INFO'}, f"{successful_copies} collections duplicadas com transformações individuais aplicadas aos Armatures{scale_info}!")
        return {'FINISHED'}


class VIEW3D_PT_collection_duplicator_panel(Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Collection Duplicator'
    bl_label = "Collection Duplicator"

    def draw(self, context):
        layout = self.layout
        props = context.scene.collection_duplicator_props
        # Seleção de collection pelo nome
        layout.label(text="1. Selecione a Collection:")
        layout.prop_search(props, "collection_name", bpy.data, "collections", text="")
        # Fator de escala
        layout.label(text="2. Defina o fator de escala (opcional):")
        layout.prop(props, "scale_factor", text="Escala")
        # Instruções
        layout.label(text="3. Selecione objeto(s) para usar a transformação")
        # Status do objeto selecionado
        if context.selected_objects:
            if len(context.selected_objects) == 1:
                layout.label(text=f"Objeto selecionado: {context.active_object.name}", icon='OBJECT_DATA')
            else:
                layout.label(text=f"{len(context.selected_objects)} objetos selecionados", icon='GROUP')
        else:
            layout.label(text="Nenhum objeto selecionado", icon='ERROR')
        # Botão Make
        layout.label(text="4. Crie a(s) collection(s) duplicada(s):")
        row = layout.row()
        row.scale_y = 1.5  # Torna o botão maior
        row.operator(OBJECT_OT_duplicate_collection.bl_idname)


classes = (
    CollectionDuplicatorProperties,
    OBJECT_OT_duplicate_collection,
    VIEW3D_PT_collection_duplicator_panel,


)


def sna_add_to_view3d_pt_collection_duplicator_panel_3AC89(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('sna.operator_89d37', text='Import Rig', icon_value=0, emboss=True, depress=False)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_OT_Operator_89D37)
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.collection_duplicator_props = PointerProperty(type=CollectionDuplicatorProperties)
    bpy.types.VIEW3D_PT_collection_duplicator_panel.prepend(sna_add_to_view3d_pt_collection_duplicator_panel_3AC89)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_OT_Operator_89D37)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.collection_duplicator_props
    bpy.types.VIEW3D_PT_collection_duplicator_panel.remove(sna_add_to_view3d_pt_collection_duplicator_panel_3AC89)
