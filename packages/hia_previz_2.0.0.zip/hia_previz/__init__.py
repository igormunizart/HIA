# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "HiA Previz",
    "author" : "Igor Muniz", 
    "description" : "Addon para o pipeline de Previz do Histeria Studios!.",
    "blender" : (4, 2, 0),
    "version" : (2, 0, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
from bpy.props import BoolProperty, IntProperty


addon_keymaps = {}
_icons = None
visual_scripting_editor = {'sna_customp': False, 'sna_sensorw': False, }
class SNA_PT_HIANIMATION_PREVIZ_V001_5CD6B(bpy.types.Panel):
    bl_label = 'HiAnimation Previz v0.0.1'
    bl_idname = 'SNA_PT_HIANIMATION_PREVIZ_V001_5CD6B'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'HiA Previz'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout


class SNA_PT_TEST_E3EE3(bpy.types.Panel):
    bl_label = 'test'
    bl_idname = 'SNA_PT_TEST_E3EE3'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        attr_3429E = '["' + str('maxFocalLength' + '"]') 
        layout.prop(bpy.context.scene.camera.data, attr_3429E, text='max Focal Length', icon_value=0, emboss=True)
        attr_0569F = '["' + str('minFocalLength' + '"]') 
        layout.prop(bpy.context.scene.camera.data, attr_0569F, text='min Focal Length', icon_value=0, emboss=True)
        layout.separator(factor=1.0)
        attr_1FFD2 = '["' + str('minLensDist' + '"]') 
        layout.prop(bpy.context.scene.camera.data, attr_1FFD2, text='min Distortion', icon_value=0, emboss=True)
        attr_702EC = '["' + str('maxLensDist' + '"]') 
        layout.prop(bpy.context.scene.camera.data, attr_702EC, text='max Distortion', icon_value=0, emboss=True)


class SNA_PT_TEST_8665F(bpy.types.Panel):
    bl_label = 'test'
    bl_idname = 'SNA_PT_TEST_8665F'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout


def sna_add_to_sequencer_ht_header_CADFA(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('sequencer.refresh_all', text='', icon_value=647, emboss=True, depress=False)


def sna_add_to_dopesheet_ht_header_73295(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('sna.op_tomaster_60d57', text='Switch to Edit', icon_value=688, emboss=True, depress=False)


class SNA_OT_Op_Tomaster_60D57(bpy.types.Operator):
    bl_idname = "sna.op_tomaster_60d57"
    bl_label = "OP_toMaster"
    bl_description = "Troque para a scene Master e para o Workspace Video Editing"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('switch_scene("_Master_")')
        exec('switch_workspace("Video Editing")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_graph_ht_header_5C12C(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('sna.op_tomaster_60d57', text='Switch to Edit', icon_value=688, emboss=True, depress=False)


class SNA_OT_Opmixamo_3Aeb4(bpy.types.Operator):
    bl_idname = "sna.opmixamo_3aeb4"
    bl_label = "opMixamo"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.mr.make_rig('INVOKE_DEFAULT', bake_anim=True, ik_arms=True, ik_legs=True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_view3d_ht_header_B0FBF(self, context):
    if not (False):
        layout = self.layout
        layout.popover('SNA_PT_hiacam_subpanel_2BB3E', text='', icon_value=608)


class SNA_PT_HIA_CAMERA_32888(bpy.types.Panel):
    bl_label = 'HiA Camera'
    bl_idname = 'SNA_PT_HIA_CAMERA_32888'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'HiA Camera'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout


class SNA_OT_Op_Setcrop_Dd674(bpy.types.Operator):
    bl_idname = "sna.op_setcrop_dd674"
    bl_label = "op_setCrop"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_crop: bpy.props.IntProperty(name='crop', description='', default=0, subtype='NONE')

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene['hiaOverlay_crop'] = self.sna_crop
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Createvar_37Dd1(bpy.types.Operator):
    bl_idname = "sna.createvar_37dd1"
    bl_label = "createVar"
    bl_description = "Create custom Property 'var'"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.camera.add_var_driver('INVOKE_DEFAULT', only_selected=bpy.context.scene.sna_onlyselected)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_LENS_DISTORTION_CAMERA_CB8F3(bpy.types.Panel):
    bl_label = 'Lens Distortion Camera'
    bl_idname = 'SNA_PT_LENS_DISTORTION_CAMERA_CB8F3'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'HIDE_HEADER'}
    bl_parent_id = 'SNA_PT_HIA_CAMERA_32888'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout


from bpy.types import Operator
class CAMERA_OT_add_var_driver(Operator):
    """Adiciona driver na propriedade 'var' das câmeras"""
    bl_idname = "camera.add_var_driver"
    bl_label = "Add Var Driver"
    bl_options = {'REGISTER', 'UNDO'}
    only_selected: BoolProperty(
        name="Only Selected",
        description="Apply only to selected camera",

        default=False
    )

    def execute(self, context):
        cameras_processed = 0
        if self.only_selected:
            # Aplica apenas na câmera selecionada
            obj = context.active_object
            if obj is None:
                self.report({'ERROR'}, "Nenhum objeto selecionado!")
                return {'CANCELLED'}
            elif obj.type != 'CAMERA':
                self.report({'ERROR'}, f"O objeto selecionado '{obj.name}' não é uma câmera!")
                return {'CANCELLED'}
            else:
                if self.process_camera_var(obj):
                    cameras_processed = 1
        else:
            # Aplica em todas as câmeras da cena
            for obj in context.scene.objects:
                if obj.type == 'CAMERA':
                    if self.process_camera_var(obj):
                        cameras_processed += 1
        self.report({'INFO'}, f"Driver 'var' adicionado em {cameras_processed} câmera(s)")
        return {'FINISHED'}

    def process_camera_var(self, obj):
        """Processa uma câmera individual"""
        try:
            # Remove driver existente se houver
            try:
                obj.data.driver_remove('["var"]')
            except:
                pass
            # Adiciona ou atualiza a propriedade "var"
            obj.data["var"] = 0.0
            # Configura os limites (clamp) para a propriedade "var"
            # Isso cria metadados para a propriedade com min/max
            obj.data.id_properties_ui("var").update(
                min=0.0,
                max=1.0,
                soft_min=0.0,
                soft_max=1.0,
                description="Variable for camera calculations",

                default=0.0
            )
            # Adiciona a propriedade "preview" como inteiro
            obj.data["preview"] = 0
            # Configura os metadados para a propriedade "preview"
            obj.data.id_properties_ui("preview").update(
                min=0,
                max=100,
                soft_min=0,
                soft_max=10,
                description="Preview quality setting",

                default=0
            )
            # Adiciona o driver na propriedade "var"
            driver = obj.data.driver_add('["var"]')
            driver.driver.type = 'SCRIPTED'
            driver.driver.use_self = True
            driver.driver.expression = '((self.lens - self["minFocalLength"]) * (self["maxLensDist"] - self["minLensDist"]) / (self["maxFocalLength"] - self["minFocalLength"]) + self["maxLensDist"]) * self["autoLensDist"] + self["lensDist"] * (1 - self["autoLensDist"])'
            return True
        except Exception as e:
            self.report({'ERROR'}, f"Erro ao processar {obj.name}: {str(e)}")
            return False


class CAMERA_OT_add_sensor_driver(Operator):
    """Adiciona driver no sensor_width das câmeras"""
    bl_idname = "camera.add_sensor_driver"
    bl_label = "Add Sensor Width Driver"
    bl_options = {'REGISTER', 'UNDO'}
    only_selected: BoolProperty(
        name="Only Selected",
        description="Apply only to selected camera",

        default=False
    )

    def execute(self, context):
        cameras_processed = 0
        if self.only_selected:
            # Aplica apenas na câmera selecionada
            obj = context.active_object
            if obj is None:
                self.report({'ERROR'}, "Nenhum objeto selecionado!")
                return {'CANCELLED'}
            elif obj.type != 'CAMERA':
                self.report({'ERROR'}, f"O objeto selecionado '{obj.name}' não é uma câmera!")
                return {'CANCELLED'}
            else:
                if self.process_camera_sensor(obj):
                    cameras_processed = 1
        else:
            # Aplica em todas as câmeras da cena
            for obj in context.scene.objects:
                if obj.type == 'CAMERA':
                    if self.process_camera_sensor(obj):
                        cameras_processed += 1
        self.report({'INFO'}, f"Driver sensor_width adicionado em {cameras_processed} câmera(s)")
        return {'FINISHED'}

    def process_camera_sensor(self, obj):
        """Processa uma câmera individual"""
        try:
            # Verifica se a propriedade "var" existe
            if "var" not in obj.data:
                obj.data["var"] = 0.0
                # Configura os limites (clamp) para a propriedade "var"
                obj.data.id_properties_ui("var").update(
                    min=0.0,
                    max=1.0,
                    soft_min=0.0,
                    soft_max=1.0,
                    description="Variable for camera calculations",

                    default=0.0
                )
            # Remove driver existente no sensor_width se houver
            try:
                obj.data.driver_remove("sensor_width")
            except:
                pass
            # Adiciona o driver no sensor_width
            driver = obj.data.driver_add("sensor_width")
            driver.driver.type = 'SCRIPTED'
            driver.driver.use_self = True
            driver.driver.expression = '54 - 42.75*pow(self["var"],0.74) + 24.75*pow(self["var"],0.94)'
            return True
        except Exception as e:
            self.report({'ERROR'}, f"Erro ao processar {obj.name}: {str(e)}")
            return False


class CAMERA_OT_add_sensor_driver_alt(Operator):
    """Adiciona driver alternativo no sensor_width das câmeras (36 - 24 * var + offset)"""
    bl_idname = "camera.add_sensor_driver_alt"
    bl_label = "Add Sensor Width Driver (Alternative)"
    bl_options = {'REGISTER', 'UNDO'}
    only_selected: BoolProperty(
        name="Only Selected",
        description="Apply only to selected camera",

        default=False
    )
    offset_value: IntProperty(
        name="Offset Value",
        description="Integer value to add to the expression",

        default=0,
        min=-100,
        max=100
    )

    def execute(self, context):
        cameras_processed = 0
        if self.only_selected:
            # Aplica apenas na câmera selecionada
            obj = context.active_object
            if obj is None:
                self.report({'ERROR'}, "Nenhum objeto selecionado!")
                return {'CANCELLED'}
            elif obj.type != 'CAMERA':
                self.report({'ERROR'}, f"O objeto selecionado '{obj.name}' não é uma câmera!")
                return {'CANCELLED'}
            else:
                if self.process_camera_sensor_alt(obj):
                    cameras_processed = 1
        else:
            # Aplica em todas as câmeras da cena
            for obj in context.scene.objects:
                if obj.type == 'CAMERA':
                    if self.process_camera_sensor_alt(obj):
                        cameras_processed += 1
        self.report({'INFO'}, f"Driver sensor_width alternativo adicionado em {cameras_processed} câmera(s)")
        return {'FINISHED'}

    def process_camera_sensor_alt(self, obj):
        """Processa uma câmera individual com driver alternativo"""
        try:
            # Verifica se a propriedade "var" existe
            if "var" not in obj.data:
                obj.data["var"] = 0.0
                # Configura os limites (clamp) para a propriedade "var"
                obj.data.id_properties_ui("var").update(
                    min=0.0,
                    max=1.0,
                    soft_min=0.0,
                    soft_max=1.0,
                    description="Variable for camera calculations",

                    default=0.0
                )
            # Remove driver existente no sensor_width se houver
            try:
                obj.data.driver_remove("sensor_width")
            except:
                pass
            # Adiciona o driver alternativo no sensor_width com o offset
            driver = obj.data.driver_add("sensor_width")
            driver.driver.type = 'SCRIPTED'
            driver.driver.use_self = True
            # Expressão modificada para incluir o offset_value
            if self.offset_value != 0:
                driver.driver.expression = f'36 - 24 * self["var"] + {self.offset_value}'
            else:
                driver.driver.expression = '36 - 24 * self["var"]'
            return True
        except Exception as e:
            self.report({'ERROR'}, f"Erro ao processar {obj.name}: {str(e)}")
            return False


class CAMERA_OT_add_both_drivers(Operator):
    """Adiciona ambos os drivers nas câmeras"""
    bl_idname = "camera.add_both_drivers"
    bl_label = "Add Both Drivers"
    bl_options = {'REGISTER', 'UNDO'}
    only_selected: BoolProperty(
        name="Only Selected",
        description="Apply only to selected camera",

        default=False
    )

    def execute(self, context):
        # Executa ambos os operadores em sequência
        bpy.ops.camera.add_var_driver(only_selected=self.only_selected)
        bpy.ops.camera.add_sensor_driver(only_selected=self.only_selected)
        return {'FINISHED'}


class CAMERA_OT_set_preview(Operator):
    """Define o valor da propriedade 'preview' nas câmeras"""
    bl_idname = "camera.set_preview"
    bl_label = "Set Camera Preview"
    bl_options = {'REGISTER', 'UNDO'}
    only_selected: BoolProperty(
        name="Only Selected",
        description="Apply only to selected camera",

        default=False
    )
    preview_value: IntProperty(
        name="Preview Value",
        description="Preview value (0=Off, 1=On)",

        default=0,
        min=0,
        max=2
    )

    def execute(self, context):
        cameras_processed = 0
        if self.only_selected:
            obj = context.active_object
            if obj is None:
                self.report({'ERROR'}, "Nenhum objeto selecionado!")
                return {'CANCELLED'}
            elif obj.type != 'CAMERA':
                self.report({'ERROR'}, f"O objeto selecionado '{obj.name}' não é uma câmera!")
                return {'CANCELLED'}
            else:
                if self.set_camera_preview(obj, self.preview_value):
                    cameras_processed = 1
        else:
            for obj in context.scene.objects:
                if obj.type == 'CAMERA':
                    if self.set_camera_preview(obj, self.preview_value):
                        cameras_processed += 1
        self.report({'INFO'}, f"Preview = {self.preview_value} em {cameras_processed} câmera(s)")
        return {'FINISHED'}

    def set_camera_preview(self, obj, value):
        """Define o valor de preview para a câmera"""
        try:
            # Define o valor da propriedade preview
            obj.data["preview"] = value
            return True
        except Exception as e:
            self.report({'ERROR'}, f"Erro ao processar {obj.name}: {str(e)}")
            return False


# Lista de classes para registro
classes = [
    CAMERA_OT_add_var_driver,
    CAMERA_OT_add_sensor_driver,
    CAMERA_OT_add_sensor_driver_alt,
    CAMERA_OT_add_both_drivers,
    CAMERA_OT_set_preview


]
# Registro automático quando o script é executado
class SNA_OT_Createdriver_50Cc6(bpy.types.Operator):
    bl_idname = "sna.createdriver_50cc6"
    bl_label = "createDriver"
    bl_description = "Add a complex Driver interpolation to Sensor Width"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.camera.add_sensor_driver('INVOKE_DEFAULT', only_selected=bpy.context.scene.sna_onlyselected)
        bpy.ops.camera.set_preview('INVOKE_DEFAULT', only_selected=bpy.context.scene.sna_onlyselected, preview_value=2)
        bpy.context.scene.render.resolution_percentage = 150
        bpy.ops.camera.toggle_shakify_constraints('INVOKE_DEFAULT', enable_constraints=bpy.context.scene.sna_workshakify)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Createdriveralt001_0C778(bpy.types.Operator):
    bl_idname = "sna.createdriveralt001_0c778"
    bl_label = "createDriverAlt.001"
    bl_description = "Add a simple driver to Sensor Width"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.camera.add_sensor_driver('INVOKE_DEFAULT', only_selected=bpy.context.scene.sna_onlyselected)
        bpy.ops.camera.set_preview('INVOKE_DEFAULT', only_selected=bpy.context.scene.sna_onlyselected, preview_value=1)
        bpy.context.scene.render.resolution_percentage = 100
        bpy.ops.camera.toggle_shakify_constraints('INVOKE_DEFAULT', enable_constraints=bpy.context.scene.sna_previewshakify)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Createdriveralt002_10F0E(bpy.types.Operator):
    bl_idname = "sna.createdriveralt002_10f0e"
    bl_label = "createDriverAlt.002"
    bl_description = "Add a simple driver to Sensor Width"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.camera.add_sensor_driver_alt('INVOKE_DEFAULT', only_selected=bpy.context.scene.sna_onlyselected, offset_value=bpy.context.scene.sna_margin)
        bpy.ops.camera.set_preview('INVOKE_DEFAULT', only_selected=bpy.context.scene.sna_onlyselected, preview_value=0)
        bpy.context.scene.render.resolution_percentage = 50
        bpy.ops.camera.toggle_shakify_constraints('INVOKE_DEFAULT', enable_constraints=bpy.context.scene.sna_rendershakify)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_CONFIG_0B796(bpy.types.Panel):
    bl_label = 'Config'
    bl_idname = 'SNA_PT_CONFIG_0B796'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_LENS_DISTORTION_CAMERA_CB8F3'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_9071D = layout.column(heading='', align=True)
        col_9071D.alert = False
        col_9071D.enabled = True
        col_9071D.active = True
        col_9071D.use_property_split = False
        col_9071D.use_property_decorate = False
        col_9071D.scale_x = 1.0
        col_9071D.scale_y = 1.0
        col_9071D.alignment = 'Expand'.upper()
        col_9071D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        box_6F374 = col_9071D.box()
        box_6F374.alert = False
        box_6F374.enabled = True
        box_6F374.active = True
        box_6F374.use_property_split = True
        box_6F374.use_property_decorate = False
        box_6F374.alignment = 'Center'.upper()
        box_6F374.scale_x = 1.0
        box_6F374.scale_y = 1.0
        if not True: box_6F374.operator_context = "EXEC_DEFAULT"
        box_6F374.prop(bpy.context.scene, 'sna_onlyselected', text='Only Selected', icon_value=27, emboss=True, toggle=True)
        op = box_6F374.operator('sna.createvar_37dd1', text='Property', icon_value=61, emboss=True, depress=False)


class SNA_PT_SETUP_475B9(bpy.types.Panel):
    bl_label = 'Setup'
    bl_idname = 'SNA_PT_SETUP_475B9'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'HIDE_HEADER'}
    bl_parent_id = 'SNA_PT_HIA_CAMERA_32888'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_31878 = layout.column(heading='', align=False)
        col_31878.alert = False
        col_31878.enabled = True
        col_31878.active = True
        col_31878.use_property_split = False
        col_31878.use_property_decorate = False
        col_31878.scale_x = 1.0
        col_31878.scale_y = 1.0
        col_31878.alignment = 'Expand'.upper()
        col_31878.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        split_26D42 = col_31878.split(factor=0.699999988079071, align=True)
        split_26D42.alert = False
        split_26D42.enabled = True
        split_26D42.active = True
        split_26D42.use_property_split = False
        split_26D42.use_property_decorate = False
        split_26D42.scale_x = 1.0
        split_26D42.scale_y = 1.0
        split_26D42.alignment = 'Left'.upper()
        if not True: split_26D42.operator_context = "EXEC_DEFAULT"
        split_E3653 = split_26D42.split(factor=0.800000011920929, align=True)
        split_E3653.alert = False
        split_E3653.enabled = True
        split_E3653.active = True
        split_E3653.use_property_split = False
        split_E3653.use_property_decorate = False
        split_E3653.scale_x = 1.0
        split_E3653.scale_y = 1.0
        split_E3653.alignment = 'Expand'.upper()
        if not True: split_E3653.operator_context = "EXEC_DEFAULT"
        op = split_E3653.operator('sna.createdriveralt002_10f0e', text='Work', icon_value=28, emboss=True, depress=False)
        split_E3653.prop(bpy.context.scene, 'sna_margin', text='', icon_value=377, emboss=True)
        row_D3432 = split_26D42.row(heading='', align=False)
        row_D3432.alert = False
        row_D3432.enabled = True
        row_D3432.active = False
        row_D3432.use_property_split = False
        row_D3432.use_property_decorate = False
        row_D3432.scale_x = 1.0
        row_D3432.scale_y = 1.0
        row_D3432.alignment = 'Expand'.upper()
        row_D3432.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_D3432.prop(bpy.context.scene, 'sna_workshakify', text='Shakify', icon_value=0, emboss=True, toggle=False)
        split_B773E = col_31878.split(factor=0.699999988079071, align=True)
        split_B773E.alert = False
        split_B773E.enabled = True
        split_B773E.active = True
        split_B773E.use_property_split = False
        split_B773E.use_property_decorate = False
        split_B773E.scale_x = 1.0
        split_B773E.scale_y = 1.0
        split_B773E.alignment = 'Expand'.upper()
        if not True: split_B773E.operator_context = "EXEC_DEFAULT"
        op = split_B773E.operator('sna.createdriveralt001_0c778', text='Preview', icon_value=24, emboss=True, depress=False)
        row_82D45 = split_B773E.row(heading='', align=False)
        row_82D45.alert = False
        row_82D45.enabled = True
        row_82D45.active = False
        row_82D45.use_property_split = False
        row_82D45.use_property_decorate = False
        row_82D45.scale_x = 1.0
        row_82D45.scale_y = 1.0
        row_82D45.alignment = 'Expand'.upper()
        row_82D45.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_82D45.prop(bpy.context.scene, 'sna_previewshakify', text='Shakify', icon_value=0, emboss=True)
        split_4232E = col_31878.split(factor=0.699999988079071, align=True)
        split_4232E.alert = False
        split_4232E.enabled = True
        split_4232E.active = True
        split_4232E.use_property_split = False
        split_4232E.use_property_decorate = False
        split_4232E.scale_x = 1.0
        split_4232E.scale_y = 1.0
        split_4232E.alignment = 'Expand'.upper()
        if not True: split_4232E.operator_context = "EXEC_DEFAULT"
        op = split_4232E.operator('sna.createdriver_50cc6', text='Render', icon_value=25, emboss=True, depress=False)
        row_650DB = split_4232E.row(heading='', align=False)
        row_650DB.alert = False
        row_650DB.enabled = True
        row_650DB.active = False
        row_650DB.use_property_split = False
        row_650DB.use_property_decorate = False
        row_650DB.scale_x = 1.0
        row_650DB.scale_y = 1.0
        row_650DB.alignment = 'Expand'.upper()
        row_650DB.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_650DB.prop(bpy.context.scene, 'sna_rendershakify', text='Shakify', icon_value=0, emboss=True, toggle=False)


class CAMERA_OT_toggle_shakify_constraints(Operator):
    """Toggle CameraShakify constraints on/off for all cameras"""
    bl_idname = "camera.toggle_shakify_constraints"
    bl_label = "Toggle CameraShakify Constraints"
    bl_description = "Enable or disable all CameraShakify constraints on cameras"
    bl_options = {'REGISTER', 'UNDO'}
    # Propriedade para controlar se deve ativar (True) ou desativar (False)
    enable_constraints: BoolProperty(
        name="Enable Constraints",
        description="Enable (True) or disable (False) CameraShakify constraints",

        default=False
    )

    def execute(self, context):
        """Executa a operação de ativar/desativar constraints"""
        modified_constraints = 0
        processed_cameras = 0
        action = "ativadas" if self.enable_constraints else "desativadas"
        # Percorre todas as cenas do projeto
        for scene in bpy.data.scenes:
            print(f"Verificando cena: {scene.name}")
            # Percorre todos os objetos da cena
            for obj in scene.objects:
                # Verifica se é uma câmera
                if obj.type == 'CAMERA':
                    camera_had_constraints = False
                    # Percorre todas as constraints do objeto câmera
                    for constraint in obj.constraints:
                        # Verifica se o nome da constraint começa com 'CameraShakify'
                        if constraint.name.lower().startswith('camerashakify'):
                            if not camera_had_constraints:
                                processed_cameras += 1
                                print(f"  Processando câmera: {obj.name}")
                                camera_had_constraints = True
                            # Verifica se precisa modificar o estado
                            if constraint.enabled != self.enable_constraints:
                                constraint.enabled = self.enable_constraints
                                modified_constraints += 1
                                print(f"    Constraint '{constraint.name}' ({constraint.type}) {action}")
                            else:
                                status = "ativada" if constraint.enabled else "desativada"
                                print(f"    Constraint '{constraint.name}' ({constraint.type}) já estava {status}")
        # Relatório final
        print(f"\nResumo:")
        print(f"Câmeras com constraints CameraShakify processadas: {processed_cameras}")
        print(f"Total de constraints CameraShakify {action}: {modified_constraints}")
        # Mensagem para o usuário
        if modified_constraints > 0:
            self.report({'INFO'}, f"{modified_constraints} constraints CameraShakify {action} em {processed_cameras} câmeras")
        else:
            self.report({'INFO'}, "Nenhuma constraint foi modificada")
        # Atualiza a interface
        if context.view_layer:
            context.view_layer.update()
        return {'FINISHED'}


# Função de conveniência para desativar (mantém compatibilidade com código original)
# Função de conveniência para ativar
# Registro das classes
# Execução direta (para testes)
class SNA_PT_hiacam_subpanel_2BB3E(bpy.types.Panel):
    bl_label = ''
    bl_idname = 'SNA_PT_hiacam_subpanel_2BB3E'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'HEADER_LAYOUT_EXPAND'}
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='View Mode', icon_value=0)
        if hasattr(bpy.types,"SNA_PT_SETUP_B89DA"):
            if not hasattr(bpy.types.SNA_PT_SETUP_B89DA, "poll") or bpy.types.SNA_PT_SETUP_B89DA.poll(context):
                bpy.types.SNA_PT_SETUP_B89DA.draw(self, context)
            else:
                layout.label(text="Can't display this panel here!", icon="ERROR")
        else:
            layout.label(text="Can't display this panel!", icon="ERROR")
        if hasattr(bpy.types,"SNA_PT_HIA_OVERLAYS_44209"):
            if not hasattr(bpy.types.SNA_PT_HIA_OVERLAYS_44209, "poll") or bpy.types.SNA_PT_HIA_OVERLAYS_44209.poll(context):
                bpy.types.SNA_PT_HIA_OVERLAYS_44209.draw(self, context)
            else:
                layout.label(text="Can't display this panel here!", icon="ERROR")
        else:
            layout.label(text="Can't display this panel!", icon="ERROR")


class SNA_PT_CAMERA_24CDC(bpy.types.Panel):
    bl_label = 'Camera'
    bl_idname = 'SNA_PT_CAMERA_24CDC'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_HIANIMATION_PREVIZ_V001_5CD6B'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout


class SNA_PT_BASIC_49DC4(bpy.types.Panel):
    bl_label = 'Basic'
    bl_idname = 'SNA_PT_BASIC_49DC4'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'HIDE_HEADER'}
    bl_parent_id = 'SNA_PT_CAMERA_24CDC'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        if hasattr(bpy.types,"ADD_CAMERA_RIGS_PT_camera_rig_ui"):
            if not hasattr(bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui, "poll") or bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui.poll(context):
                bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui.draw(self, context)
            else:
                layout.label(text="Can't display this panel here!", icon="ERROR")
        else:
            layout.label(text="Can't display this panel!", icon="ERROR")


class SNA_PT_DOF_120E3(bpy.types.Panel):
    bl_label = 'DOF'
    bl_idname = 'SNA_PT_DOF_120E3'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_CAMERA_24CDC'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        if hasattr(bpy.types,"ADD_CAMERA_RIGS_PT_camera_rig_ui_dof"):
            if not hasattr(bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui_dof, "poll") or bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui_dof.poll(context):
                bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui_dof.draw(self, context)
            else:
                layout.label(text="Can't display this panel here!", icon="ERROR")
        else:
            layout.label(text="Can't display this panel!", icon="ERROR")


class SNA_PT_VIEWPORT_CONFIG_33BE7(bpy.types.Panel):
    bl_label = 'Viewport Config'
    bl_idname = 'SNA_PT_VIEWPORT_CONFIG_33BE7'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_CAMERA_24CDC'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        if hasattr(bpy.types,"ADD_CAMERA_RIGS_PT_camera_rig_ui_viewport"):
            if not hasattr(bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui_viewport, "poll") or bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui_viewport.poll(context):
                bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui_viewport.draw(self, context)
            else:
                layout.label(text="Can't display this panel here!", icon="ERROR")
        else:
            layout.label(text="Can't display this panel!", icon="ERROR")


class SNA_PT_PROPRIEDADES_52D71(bpy.types.Panel):
    bl_label = 'Propriedades'
    bl_idname = 'SNA_PT_PROPRIEDADES_52D71'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_CAMERA_24CDC'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        if hasattr(bpy.types,"ADD_CAMERA_RIGS_PT_camera_rig_ui_visibility"):
            if not hasattr(bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui_visibility, "poll") or bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui_visibility.poll(context):
                bpy.types.ADD_CAMERA_RIGS_PT_camera_rig_ui_visibility.draw(self, context)
            else:
                layout.label(text="Can't display this panel here!", icon="ERROR")
        else:
            layout.label(text="Can't display this panel!", icon="ERROR")


class SNA_PT_LENS_DISTORTION_D3E32(bpy.types.Panel):
    bl_label = 'Lens Distortion'
    bl_idname = 'SNA_PT_LENS_DISTORTION_D3E32'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_CAMERA_24CDC'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_8E8FD = layout.box()
        box_8E8FD.alert = False
        box_8E8FD.enabled = True
        box_8E8FD.active = True
        box_8E8FD.use_property_split = False
        box_8E8FD.use_property_decorate = False
        box_8E8FD.alignment = 'Expand'.upper()
        box_8E8FD.scale_x = 1.0
        box_8E8FD.scale_y = 1.0
        if not True: box_8E8FD.operator_context = "EXEC_DEFAULT"
        row_FF37E = box_8E8FD.row(heading='', align=False)
        row_FF37E.alert = False
        row_FF37E.enabled = True
        row_FF37E.active = True
        row_FF37E.use_property_split = False
        row_FF37E.use_property_decorate = False
        row_FF37E.scale_x = 1.0
        row_FF37E.scale_y = 1.0
        row_FF37E.alignment = 'Center'.upper()
        row_FF37E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_FF37E.label(text='Eevee Lens Distortion', icon_value=0)
        split_855B5 = box_8E8FD.split(factor=1.0, align=True)
        split_855B5.alert = False
        split_855B5.enabled = True
        split_855B5.active = True
        split_855B5.use_property_split = False
        split_855B5.use_property_decorate = False
        split_855B5.scale_x = 1.0
        split_855B5.scale_y = 1.0
        split_855B5.alignment = 'Center'.upper()
        if not True: split_855B5.operator_context = "EXEC_DEFAULT"
        attr_97B41 = '["' + str('autoLensDist' + '"]') 
        split_855B5.prop(bpy.context.scene.camera.data, attr_97B41, text='Auto Lens Distortion', icon_value=0, emboss=True, toggle=True)
        if bpy.context.scene.camera.data['autoLensDist']:
            box_8E8FD.popover('SNA_PT_TEST_E3EE3', text='Min/Max Range', icon_value=0)
        else:
            attr_D3A64 = '["' + str('lensDist' + '"]') 
            box_8E8FD.prop(bpy.context.scene.camera.data, attr_D3A64, text='Lens Distortion', icon_value=0, emboss=True, slider=True)


class SNA_PT_SHAKIFY_2B158(bpy.types.Panel):
    bl_label = 'Shakify'
    bl_idname = 'SNA_PT_SHAKIFY_2B158'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_CAMERA_24CDC'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        if hasattr(bpy.types,"DATA_PT_camera_shakify"):
            if not hasattr(bpy.types.DATA_PT_camera_shakify, "poll") or bpy.types.DATA_PT_camera_shakify.poll(context):
                bpy.types.DATA_PT_camera_shakify.draw(self, context)
            else:
                layout.label(text="Can't display this panel here!", icon="ERROR")
        else:
            layout.label(text="Can't display this panel!", icon="ERROR")


class SNA_PT_MIXAMO_FEBCA(bpy.types.Panel):
    bl_label = 'Mixamo'
    bl_idname = 'SNA_PT_MIXAMO_FEBCA'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_CAMERA_24CDC'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        op = layout.operator('import_scene.fbx', text='Import AnimMixamo', icon_value=129, emboss=True, depress=False)
        op = layout.operator('sna.opmixamo_3aeb4', text='Convert AnimMixamo', icon_value=203, emboss=True, depress=False)
        col_3A7D7 = layout.column(heading='', align=False)
        col_3A7D7.alert = False
        col_3A7D7.enabled = True
        col_3A7D7.active = True
        col_3A7D7.use_property_split = False
        col_3A7D7.use_property_decorate = False
        col_3A7D7.scale_x = 1.0
        col_3A7D7.scale_y = 1.0
        col_3A7D7.alignment = 'Center'.upper()
        col_3A7D7.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_3A7D7.label(text='Name and Save your Action', icon_value=0)
        split_27C01 = col_3A7D7.split(factor=0.75, align=True)
        split_27C01.alert = False
        split_27C01.enabled = True
        split_27C01.active = True
        split_27C01.use_property_split = False
        split_27C01.use_property_decorate = False
        split_27C01.scale_x = 1.0
        split_27C01.scale_y = 1.0
        split_27C01.alignment = 'Expand'.upper()
        if not True: split_27C01.operator_context = "EXEC_DEFAULT"
        split_27C01.prop(bpy.context.active_object.animation_data.action, 'name', text='', icon_value=0, emboss=True)
        split_27C01.prop(bpy.data.actions['oi'], 'use_fake_user', text='', icon_value=0, emboss=True)


class SNA_PT_HIA_OVERLAYS_07B62(bpy.types.Panel):
    bl_label = 'HiA Overlays'
    bl_idname = 'SNA_PT_HIA_OVERLAYS_07B62'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_HIA_CAMERA_32888'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Aspect Ratio', icon_value=0)
        row_B04B6 = layout.row(heading='', align=True)
        row_B04B6.alert = False
        row_B04B6.enabled = True
        row_B04B6.active = True
        row_B04B6.use_property_split = False
        row_B04B6.use_property_decorate = False
        row_B04B6.scale_x = 1.0
        row_B04B6.scale_y = 1.0
        row_B04B6.alignment = 'Expand'.upper()
        row_B04B6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_B04B6.operator('sna.op_setcrop_dd674', text='1x1', icon_value=0, emboss=True, depress=(bpy.context.scene['hiaOverlay_crop'] == 0))
        op.sna_crop = 0
        op = row_B04B6.operator('sna.op_setcrop_dd674', text='16x9', icon_value=0, emboss=True, depress=(bpy.context.scene['hiaOverlay_crop'] == 1))
        op.sna_crop = 1
        op = row_B04B6.operator('sna.op_setcrop_dd674', text='9x16', icon_value=0, emboss=True, depress=(bpy.context.scene['hiaOverlay_crop'] == 2))
        op.sna_crop = 2
        layout.label(text='Overlay Guides', icon_value=0)
        row_E2301 = layout.row(heading='', align=True)
        row_E2301.alert = False
        row_E2301.enabled = True
        row_E2301.active = True
        row_E2301.use_property_split = False
        row_E2301.use_property_decorate = False
        row_E2301.scale_x = 1.0
        row_E2301.scale_y = 1.0
        row_E2301.alignment = 'Expand'.upper()
        row_E2301.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_25D07 = row_E2301.column(heading='', align=True)
        col_25D07.alert = False
        col_25D07.enabled = True
        col_25D07.active = bpy.context.scene['hiaOverlay_safeArea']
        col_25D07.use_property_split = False
        col_25D07.use_property_decorate = False
        col_25D07.scale_x = 1.0
        col_25D07.scale_y = 1.0
        col_25D07.alignment = 'Expand'.upper()
        col_25D07.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        attr_8BE61 = '["' + str('hiaOverlay_safeArea' + '"]') 
        col_25D07.prop(bpy.context.scene, attr_8BE61, text='Safe Area', icon_value=0, emboss=True, expand=True, toggle=True)
        attr_48E5D = '["' + str('hiaOverlay_safeAreaColor' + '"]') 
        col_25D07.prop(bpy.context.scene, attr_48E5D, text='', icon_value=0, emboss=True)
        col_F9588 = row_E2301.column(heading='', align=True)
        col_F9588.alert = False
        col_F9588.enabled = True
        col_F9588.active = bpy.context.scene['hiaOverlay_socialMediaSafe']
        col_F9588.use_property_split = False
        col_F9588.use_property_decorate = False
        col_F9588.scale_x = 1.0
        col_F9588.scale_y = 1.0
        col_F9588.alignment = 'Expand'.upper()
        col_F9588.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        attr_84F68 = '["' + str('hiaOverlay_socialMediaSafe' + '"]') 
        col_F9588.prop(bpy.context.scene, attr_84F68, text='Social Media', icon_value=0, emboss=True, expand=True, toggle=True)
        attr_263D3 = '["' + str('hiaOverlay_socialMediaSafeColor' + '"]') 
        col_F9588.prop(bpy.context.scene, attr_263D3, text='', icon_value=0, emboss=True)
        col_F0E4B = row_E2301.column(heading='', align=True)
        col_F0E4B.alert = False
        col_F0E4B.enabled = True
        col_F0E4B.active = bpy.context.scene['hiaOverlay_HUD']
        col_F0E4B.use_property_split = False
        col_F0E4B.use_property_decorate = False
        col_F0E4B.scale_x = 1.0
        col_F0E4B.scale_y = 1.0
        col_F0E4B.alignment = 'Expand'.upper()
        col_F0E4B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        attr_337A4 = '["' + str('hiaOverlay_HUD' + '"]') 
        col_F0E4B.prop(bpy.context.scene, attr_337A4, text='HUD', icon_value=0, emboss=True, expand=True, toggle=True)
        attr_D8848 = '["' + str('hiaOverlay_HUDcolor' + '"]') 
        col_F0E4B.prop(bpy.context.scene, attr_D8848, text='', icon_value=0, emboss=True)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_onlyselected = bpy.props.BoolProperty(name='onlySelected', description='', default=False)
    bpy.types.Scene.sna_margin = bpy.props.IntProperty(name='margin', description='', default=3, subtype='NONE')
    bpy.types.Scene.sna_workshakify = bpy.props.BoolProperty(name='workShakify', description='', default=False)
    bpy.types.Scene.sna_previewshakify = bpy.props.BoolProperty(name='previewShakify', description='', default=True)
    bpy.types.Scene.sna_rendershakify = bpy.props.BoolProperty(name='renderShakify', description='', default=True)
    bpy.types.Scene.sna_currentscene = bpy.props.PointerProperty(name='currentScene', description='', type=bpy.types.Scene)
    bpy.utils.register_class(SNA_PT_HIANIMATION_PREVIZ_V001_5CD6B)
    bpy.utils.register_class(SNA_PT_TEST_E3EE3)
    bpy.utils.register_class(SNA_PT_TEST_8665F)
    bpy.types.SEQUENCER_HT_header.append(sna_add_to_sequencer_ht_header_CADFA)
    bpy.types.DOPESHEET_HT_header.append(sna_add_to_dopesheet_ht_header_73295)
    bpy.utils.register_class(SNA_OT_Op_Tomaster_60D57)
    bpy.types.GRAPH_HT_header.append(sna_add_to_graph_ht_header_5C12C)
    bpy.utils.register_class(SNA_OT_Opmixamo_3Aeb4)
    bpy.types.VIEW3D_HT_header.append(sna_add_to_view3d_ht_header_B0FBF)
    bpy.utils.register_class(SNA_PT_HIA_CAMERA_32888)
    bpy.utils.register_class(SNA_OT_Op_Setcrop_Dd674)
    bpy.utils.register_class(SNA_OT_Createvar_37Dd1)
    bpy.utils.register_class(SNA_PT_LENS_DISTORTION_CAMERA_CB8F3)
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.utils.register_class(SNA_OT_Createdriver_50Cc6)
    bpy.utils.register_class(SNA_OT_Createdriveralt001_0C778)
    bpy.utils.register_class(SNA_OT_Createdriveralt002_10F0E)
    bpy.utils.register_class(SNA_PT_CONFIG_0B796)
    bpy.utils.register_class(SNA_PT_SETUP_475B9)
    bpy.utils.register_class(CAMERA_OT_toggle_shakify_constraints)
    bpy.utils.register_class(SNA_PT_hiacam_subpanel_2BB3E)
    bpy.utils.register_class(SNA_PT_CAMERA_24CDC)
    bpy.utils.register_class(SNA_PT_BASIC_49DC4)
    bpy.utils.register_class(SNA_PT_DOF_120E3)
    bpy.utils.register_class(SNA_PT_VIEWPORT_CONFIG_33BE7)
    bpy.utils.register_class(SNA_PT_PROPRIEDADES_52D71)
    bpy.utils.register_class(SNA_PT_LENS_DISTORTION_D3E32)
    bpy.utils.register_class(SNA_PT_SHAKIFY_2B158)
    bpy.utils.register_class(SNA_PT_MIXAMO_FEBCA)
    bpy.utils.register_class(SNA_PT_HIA_OVERLAYS_07B62)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_currentscene
    del bpy.types.Scene.sna_rendershakify
    del bpy.types.Scene.sna_previewshakify
    del bpy.types.Scene.sna_workshakify
    del bpy.types.Scene.sna_margin
    del bpy.types.Scene.sna_onlyselected
    bpy.utils.unregister_class(SNA_PT_HIANIMATION_PREVIZ_V001_5CD6B)
    bpy.utils.unregister_class(SNA_PT_TEST_E3EE3)
    bpy.utils.unregister_class(SNA_PT_TEST_8665F)
    bpy.types.SEQUENCER_HT_header.remove(sna_add_to_sequencer_ht_header_CADFA)
    bpy.types.DOPESHEET_HT_header.remove(sna_add_to_dopesheet_ht_header_73295)
    bpy.utils.unregister_class(SNA_OT_Op_Tomaster_60D57)
    bpy.types.GRAPH_HT_header.remove(sna_add_to_graph_ht_header_5C12C)
    bpy.utils.unregister_class(SNA_OT_Opmixamo_3Aeb4)
    bpy.types.VIEW3D_HT_header.remove(sna_add_to_view3d_ht_header_B0FBF)
    bpy.utils.unregister_class(SNA_PT_HIA_CAMERA_32888)
    bpy.utils.unregister_class(SNA_OT_Op_Setcrop_Dd674)
    bpy.utils.unregister_class(SNA_OT_Createvar_37Dd1)
    bpy.utils.unregister_class(SNA_PT_LENS_DISTORTION_CAMERA_CB8F3)
    for cls in classes:
        bpy.utils.unregister_class(cls)
    bpy.utils.unregister_class(SNA_OT_Createdriver_50Cc6)
    bpy.utils.unregister_class(SNA_OT_Createdriveralt001_0C778)
    bpy.utils.unregister_class(SNA_OT_Createdriveralt002_10F0E)
    bpy.utils.unregister_class(SNA_PT_CONFIG_0B796)
    bpy.utils.unregister_class(SNA_PT_SETUP_475B9)
    bpy.utils.unregister_class(CAMERA_OT_toggle_shakify_constraints)
    bpy.utils.unregister_class(SNA_PT_hiacam_subpanel_2BB3E)
    bpy.utils.unregister_class(SNA_PT_CAMERA_24CDC)
    bpy.utils.unregister_class(SNA_PT_BASIC_49DC4)
    bpy.utils.unregister_class(SNA_PT_DOF_120E3)
    bpy.utils.unregister_class(SNA_PT_VIEWPORT_CONFIG_33BE7)
    bpy.utils.unregister_class(SNA_PT_PROPRIEDADES_52D71)
    bpy.utils.unregister_class(SNA_PT_LENS_DISTORTION_D3E32)
    bpy.utils.unregister_class(SNA_PT_SHAKIFY_2B158)
    bpy.utils.unregister_class(SNA_PT_MIXAMO_FEBCA)
    bpy.utils.unregister_class(SNA_PT_HIA_OVERLAYS_07B62)
