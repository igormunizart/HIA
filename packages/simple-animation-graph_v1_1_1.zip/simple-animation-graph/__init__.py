bl_info = {
    "name": "Simple Animation Graph",
    "blender": (4, 2, 0),
    "category": "Animation",
    "author": "Dédouze",
    "version": (1, 1, 1),
    "description": "Animate by drawing trajectories on the screen!",
} 

import importlib

# Import the submodules
from . import properties
from . import panel
from . import operator

# Reload submodules in development (useful for testing)
importlib.reload(properties)
importlib.reload(panel)
importlib.reload(operator)

# Register/unregister functions
def register():
    properties.register()
    panel.register()
    operator.register()

def unregister():
    operator.unregister()
    panel.unregister()
    properties.unregister()

if __name__ == "__main__":
    register()
