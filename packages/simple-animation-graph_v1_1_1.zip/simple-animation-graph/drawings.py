import bpy
import mathutils
import sys  # Import sys to create super small number with machine epsilon

def calculate_intersection(p1, p2, p3, p4, epsilon=1e-9):
    """
    Calculate the intersection point or closest approach between two line segments in 3D.
    """
    # Direction vectors of the line segments
    d1 = p2 - p1
    d2 = p4 - p3
    r = p1 - p3

    # Dot products
    a = d1.dot(d1)
    e = d2.dot(d2)
    f = d2.dot(r)

    if a <= epsilon and e <= epsilon:
        # Both segments degenerate into points
        return p3#None

    if a <= epsilon:
        # First segment degenerates into a point
        t = f / e
        t = max(0, min(1, t))
        return p3 + d2 * t

    if e <= epsilon:
        # Second segment degenerates into a point
        s = -d1.dot(r) / a
        s = max(0, min(1, s))
        return p1 + d1 * s

    # General case
    b = d1.dot(d2)
    c = d1.dot(r)

    denom = a * e - b * b
    if abs(denom) <= epsilon:
        # Lines are parallel
        return p3#None

    # Solve for s and t
    s = (b * f - c * e) / denom
    t = (a * f - b * c) / denom

    # Clamp s and t to be within [0, 1] to stay within the segments
    s = max(0, min(1, s))
    t = max(0, min(1, t))

    # Calculate the closest points on each segment
    closest_point_1 = p1 + d1 * s
    closest_point_2 = p3 + d2 * t

    # Check if the closest points are close enough to consider as an intersection
    if (closest_point_1 - closest_point_2).length <= epsilon:
        return (closest_point_1 + closest_point_2) / 2

    return None

def add_epsilon_offset(point, view_orientation):
    """
    Hack for orthogonal view, Add a very small offset (epsilon) to the point to prevent precision issues in orthographic views.
    The offset is applied only to one axis for minimal visual change
    """
    
    epsilon = sys.float_info.epsilon
    if view_orientation == 'FRONT' or view_orientation == 'BACK':
        return point + mathutils.Vector((0, epsilon, 0))
    elif view_orientation == 'RIGHT' or view_orientation == 'LEFT':
        return point + mathutils.Vector((epsilon, 0 , 0))
    elif view_orientation == 'TOP' or view_orientation == 'BOTTOM':
        return point + mathutils.Vector((0, 0, epsilon))
    return point

def is_orthographic_view():
    """
    Check if the current 3D view is orthographic and return the view orientation.
    This method determines the orientation using the view matrix values.
    """
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    region_3d = space.region_3d
                    if region_3d.view_perspective == 'ORTHO':
                        view_matrix = region_3d.view_matrix
                        z_axis = view_matrix.col[2].xyz.normalized()

                        # Determine which axis is aligned by checking which has the maximum component
                        if abs(z_axis.z) > 0.99:
                            return 'TOP' if z_axis.z > 0 else 'BOTTOM'
                        elif abs(z_axis.y) > 0.99:
                            return 'FRONT' if z_axis.y < 0 else 'BACK'
                        elif abs(z_axis.x) > 0.99:
                            return 'RIGHT' if z_axis.x < 0 else 'LEFT'
    return None

# def is_orthographic_view():
#     """
#     Check if the current 3D view is orthographic.
#     """
#     for area in bpy.context.screen.areas:
#         if area.type == 'VIEW_3D':
#             for space in area.spaces:
#                 if space.type == 'VIEW_3D':
#                     return space.region_3d.view_perspective == 'ORTHO'
#     return False

def project_to_2d(point, plane='XY'):
    # Helper function to project a 3D point onto a 2D plane
    if plane == 'XY':
        return mathutils.Vector((point.x, point.y))
    elif plane == 'XZ':
        return mathutils.Vector((point.x, point.z))
    elif plane == 'YZ':
        return mathutils.Vector((point.y, point.z))

def get_trajectory_in_annotation(threshold_distance=0.5, simplify=1):
    
    annotations = bpy.data.grease_pencils
    if not annotations:
        raise RuntimeError("No drawn trajectory found.")

    gpencil = annotations[0]
    if bpy.app.version >= (4, 3, 0):
        if gpencil.layers.active_index < 0:
            raise RuntimeError("No drawn trajectory found.")
        layer = gpencil.layers[gpencil.layers.active_index]
    else:
        layer = gpencil.layers.active
    if not layer or not layer.active_frame:
        raise RuntimeError("No drawn trajectory on this frame.")

    frame = layer.active_frame
    longest_line = None
    max_length = 0

    # Find the longest line in the annotations to be considered as the main trajectory
    for stroke in frame.strokes:
        points = stroke.points
        length = sum((points[i].co - points[i - 1].co).length for i in range(1, len(points)))
        if length > max_length:
            longest_line = list(points)
            max_length = length

    if not longest_line:
        raise RuntimeError("Please draw a trajectory line.")
    
    # hack for trajectory not working in orthogonal mode : add very small random modification to the longest_line points to make the trajectory easier to intersect
    orthogonal_view = is_orthographic_view()
    if orthogonal_view:
        print(f"is orthogonal {orthogonal_view}")

    # if orthogonal_view:
    #     message = "Warning: Animating in orthographic view may not work correctly yet."
    #     print(message)  # Log to the system console
    #     # Add a report to the Info Editor
    #     bpy.app.handlers.depsgraph_update_pre.append(lambda _: print(message))

    # Ensure correct order of strokes along the trajectory
    intersection_points = []
    processed_strokes_indexes = set()

    #convert the points in the longest line from point.co to point 
    trajectory_points = list(map(lambda point: point.co, longest_line))
    trajectory_points = simplify_points(trajectory_points, simplify)
    # Iterate over trajectory segments in the correct order
    for i in range(1, len(trajectory_points)):
        if orthogonal_view:
            curr_segment_start = add_epsilon_offset(trajectory_points[i - 1], orthogonal_view)
            curr_segment_end = add_epsilon_offset(trajectory_points[i], orthogonal_view)
        else:
            curr_segment_start = trajectory_points[i - 1]
            curr_segment_end = trajectory_points[i]
        print(f"current segment : [{i - 1}-{i}]")
        range_has_intersection = False
        for j, stroke in enumerate(frame.strokes):
            if range_has_intersection:
                continue
            if j in processed_strokes_indexes or stroke.points == longest_line:
                continue  # Skip already processed strokes or the trajectory itself

            if len(stroke.points) >= 2:
                point_a = stroke.points[0].co
                point_b = stroke.points[-1].co
                # Calculate intersection ensuring the strokes are processed in the correct order
                intersection = calculate_intersection(point_a, point_b, curr_segment_start, curr_segment_end)

                # If the exact intersection is not found, use a threshold-based approximation
                if not intersection:
                    midpoint_trajectory = (curr_segment_start + curr_segment_end) / 2
                    midpoint_stroke = (point_a + point_b) / 2
                    if (midpoint_trajectory - midpoint_stroke).length <= threshold_distance:
                        print(f"stroke {j} added by proximity {(midpoint_trajectory - midpoint_stroke).length} <= {threshold_distance}")
                        intersection = midpoint_stroke
                    else:
                        print(f"stroke {j} not intersecting and not close enough")
                else:
                    print(f"stroke {j} intersecting !")
                    
                if intersection:
                    # convert to absolute world coord, because the GP object could be translated in space
                    # intersection = gpencil_object.matrix_world @ mathutils.Vector(intersection)
                    intersection_points.append(intersection)
                    processed_strokes_indexes.add(j)
                    range_has_intersection = True

    if not intersection_points:
        raise RuntimeError("No intersections found near the trajectory.")
    if len(intersection_points) < 2:
        raise RuntimeError("Please draw at least 2 intersections on the trajectory")

    return [mathutils.Vector(p) for p in intersection_points], trajectory_points

def subdivide_points(points, multiplier=1):
    """
    Subdivide a list of points by adding interpolated points between each pair.

    Parameters:
        points (list of mathutils.Vector): Points to subdivide.
        multiplier (int): Number of additional points to add between each pair (0 = no change).

    Returns:
        list of mathutils.Vector: Subdivided points.
    """
    if multiplier <= 0:
        return points[:]  # Return original points if multiplier is 0 or less

    subdivided_points = [points[0]]  # Always keep the first point
    for i in range(1, len(points)):
        start_point = points[i - 1]
        end_point = points[i]
        step_fraction = 1 / (multiplier + 1)

        # Add interpolated points
        for step in range(1, multiplier + 1):
            factor = step * step_fraction
            subdivided_points.append(start_point.lerp(end_point, factor))

        subdivided_points.append(end_point)

    return subdivided_points


def simplify_points(points, multiplier=1):
    """
    Simplify a list of points by skipping points based on the multiplier.

    Parameters:
        points (list of mathutils.Vector): Points to simplify.
        multiplier (int): Number of steps to skip (0 = no change).

    Returns:
        list of mathutils.Vector: Simplified points.
    """
    if multiplier <= 0:
        return points[:]  # Return original points if multiplier is 0 or less

    simplified_points = [points[0]]  # Always keep the first point
    for i in range(1, len(points) - 1):
        if i % (multiplier + 1) == 0:
            simplified_points.append(points[i])

    simplified_points.append(points[-1])  # Always keep the last point
    return simplified_points

def determine_axes_for_tracking(matrix_world, trajectory_vector):
    """
    Determine the track_axis and up_axis for tracking a trajectory.
    Returns:
        Tuple (track_axis, up_axis, track_axis_vector, up_axis_vector)
    """
    # Extract the object axes in world space
    x_axis = matrix_world.to_3x3() @ mathutils.Vector((1, 0, 0))
    y_axis = matrix_world.to_3x3() @ mathutils.Vector((0, 1, 0))
    z_axis = matrix_world.to_3x3() @ mathutils.Vector((0, 0, 1))
    
    # Calculate alignment (dot product) with trajectory vector
    dot_x = trajectory_vector.dot(x_axis)
    dot_y = trajectory_vector.dot(y_axis)
    dot_z = trajectory_vector.dot(z_axis)
    
    # Determine the track axis (most aligned with the trajectory vector)
    track_axis_vector, track_axis = max(
        [(x_axis, 'TRACK_X', dot_x), (y_axis, 'TRACK_Y', dot_y), (z_axis, 'TRACK_Z', dot_z)],
        key=lambda item: abs(item[2])
    )[:2]
    
    # Determine the up axis (the next closest axis to the trajectory, perpendicular to the track axis)
    potential_up_axes = [
        (axis, label, abs(trajectory_vector.dot(axis)))
        for axis, label in [(x_axis, 'UP_X'), (y_axis, 'UP_Y'), (z_axis, 'UP_Z')]
        if label != track_axis.replace('TRACK', 'UP')
    ]
    up_axis_vector, up_axis = max(potential_up_axes, key=lambda item: item[2])[:2]
    
    return track_axis, up_axis, track_axis_vector.normalized(), up_axis_vector.normalized()

def create_debug_visuals(intersection_points, collection_name="Animation_Debug_Local_Points"):
    # Create or get the collection for debug objects
    if collection_name in bpy.data.collections:
        debug_collection = bpy.data.collections[collection_name]
    else:
        debug_collection = bpy.data.collections.new(collection_name)
        bpy.context.scene.collection.children.link(debug_collection)

    # Create an empty for each intersection point
    # for idx, point in enumerate(intersection_points):
    #     empty = bpy.data.objects.new(f"Debug_Empty_{idx}", None)
    #     empty.location = point
    #     empty.scale = (0.05, 0.05, 0.05)
    #     debug_collection.objects.link(empty)

    # Create a NURBS curve through the intersection points
    curve_data = bpy.data.curves.new(name="Debug_Trajectory_Curve", type='CURVE')
    curve_data.dimensions = '3D'
    spline = curve_data.splines.new('NURBS')
    spline.points.add(len(intersection_points) - 1)
    spline.order_u = 2
    spline.use_endpoint_u = True

    for i, point in enumerate(intersection_points):
        spline.points[i].co = (point.x, point.y, point.z, 1.0)  # The fourth value is the weight for NURBS

    curve_object = bpy.data.objects.new("Debug_Trajectory_Curve_Object", curve_data)
    debug_collection.objects.link(curve_object)