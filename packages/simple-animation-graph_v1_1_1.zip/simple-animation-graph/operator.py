import bpy
from .drawings import *
from .utils import *

class SimpleAnimationOperator(bpy.types.Operator):
    bl_idname = "object.simple_animation_operator"
    bl_label = "Run Simple Animation"

    def execute(self, context):
        scene = context.scene
        obj = context.active_object
        props = scene.simple_animation_props

        if not obj:
            self.report({'ERROR'}, "No active object selected.")
            return {'CANCELLED'}

        is_bone_mode = obj.type == 'ARMATURE' and context.mode == 'POSE'
        bone = None
        
        if not (props.use_x or props.use_y or props.use_z):
            self.report({'ERROR'}, "Pick at least one of X Y or Z to save keyframes")
            return {'CANCELLED'}
        
        if is_bone_mode:
            selected_bones = bpy.context.selected_pose_bones
            if not selected_bones:
                self.report({'ERROR'}, "No bone selected in Pose Mode.")
                return {'CANCELLED'}
            bone = selected_bones[0]

        target = bone if is_bone_mode else obj
        data_path = "location" if props.animate_type == 'POSITION' else 'rotation_euler'

        try:
            sorted_intersection_points, longest_line = get_trajectory_in_annotation(props.graph_threshold_distance)
        except RuntimeError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
    
        sorted_local_intersection_points = list(map(lambda point: convert_to_local_point(target, point), sorted_intersection_points))
        if props.reverse_trajectory:
            sorted_local_intersection_points.reverse()

        keyframe_duration = props.keyframe_step if props.timing == 'by_step' else max(1, math.ceil(props.frames_duration / len(sorted_intersection_points)))
        current_frame = scene.frame_current
        frame_data = []

        # Retrieve initial state of the target
        initial_state = target.location.copy() if props.animate_type == 'POSITION' else target.rotation_euler.to_quaternion()

        if props.animate_type == 'POSITION':
            current_position = initial_state.copy()  # Set current position to initial
            last_point = sorted_local_intersection_points[0]

            for i, local_point in enumerate(sorted_local_intersection_points):
                if i == 0 and not props.jump_to_trajectory:
                    # Keep the initial position as the first keyframe
                    frame_data.append((current_frame, initial_state))
                else:
                    if props.jump_to_trajectory:
                        # Jump directly to the trajectory points
                        current_position = local_point.copy()
                    else:
                        # Calculate the position difference and update the current position
                        position_difference = local_point - last_point
                        current_position += position_difference
                    frame_data.append((current_frame + i * keyframe_duration, current_position.copy()))
                    last_point = local_point.copy()

        elif props.animate_type == 'ROTATION':
            current_rotation = initial_state  # Use the initial quaternion
            initial_vector = (sorted_local_intersection_points[0] - target.location).normalized()

            for i, local_point in enumerate(sorted_local_intersection_points):
                if i == 0 and not props.jump_to_trajectory:
                    # Keep the initial rotation as the first keyframe
                    frame_data.append((current_frame, current_rotation))
                else:
                    # Calculate the vector from the target's initial location to the current point
                    vector_to_current_point = (local_point - target.location).normalized()

                    # Calculate the rotation difference between the initial vector and the new direction
                    rotation_difference = initial_vector.rotation_difference(vector_to_current_point)

                    # Apply the rotation difference to the initial state, not the current state
                    applied_rotation = rotation_difference @ initial_state

                    frame_data.append((current_frame + i * keyframe_duration, applied_rotation))

            # Try smooth_rotation_euler to avoid weird ball rotation jump. NOT WORKING !!! keep it for later
            # frame_data = smooth_rotation_euler(target, frame_data)

        # Insert keyframes using a single batch keyframe function
        if props.animate_type == 'POSITION':
            batch_keyframe_operations(target, frame_data, "location", props.interpolation_mode, props.use_x, props.use_y, props.use_z)
        elif props.animate_type == 'ROTATION':
            frame_data = [(frame, rot.to_euler('XYZ')) for frame, rot in frame_data]
            batch_keyframe_operations(target, frame_data, "rotation_euler", props.interpolation_mode, props.use_x, props.use_y, props.use_z)
        
        # Update 3D cursor position if auto update cursor is enabled
        if props.auto_update_cursor and props.animate_type == 'POSITION':
            final_position = frame_data[-1][1]
            if is_bone_mode:
                # to do : fix the get absolute position for bone
                context.scene.cursor.location = sorted_intersection_points[-1]
            else:
                context.scene.cursor.location = get_absolute_position(target, final_position)

        # re select obj or bone
        if is_bone_mode:
            bpy.ops.object.mode_set(mode='POSE')
            bone.bone.select = True
            obj.data.bones.active = bone.bone
        else:
            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)
            context.view_layer.objects.active = obj

        # Create debug visuals if debug mode is enabled
        if props.debug_mode:
            create_debug_visuals(sorted_local_intersection_points, "Animation_Debug_Local_Points")
            create_debug_visuals(sorted_intersection_points, "Animation_Debug_Absolute_Points")

        report = "Animation done."
        # if is_orthographic_view():
        #     report = "Animation done. Warning: Animating in orthographic view not working correctly yet."
        self.report({'INFO'}, report)
        return {'FINISHED'}

addon_keymaps = []

def register():
    bpy.utils.register_class(SimpleAnimationOperator)

    # Register shortcuts
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon

    if kc:
        km = wm.keyconfigs.addon.keymaps.new(name='3D View', space_type='VIEW_3D')
        kmi = km.keymap_items.new(SimpleAnimationOperator.bl_idname, type='A', value='PRESS', shift=True, alt=True)
    
        # Store keymap for later unregister
        addon_keymaps.append((km, kmi))

def unregister():
    bpy.utils.unregister_class(SimpleAnimationOperator)

    # Unregister shortcuts
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()