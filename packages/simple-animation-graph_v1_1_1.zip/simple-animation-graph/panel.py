import bpy
# from pathlib import Path
import bpy

class SimpleAnimationPanel(bpy.types.Panel):
    bl_label = "Simple Animation Graph"
    bl_idname = "VIEW3D_PT_simple_animation"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Animation"

    @classmethod
    def poll(cls, context):
        return context.scene is not None

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        props = scene.simple_animation_props

        # Tabs at the top
        layout.prop(props, "active_tab", expand=True)

        if props.active_tab == "MAIN":
            self.draw_main_tab(layout, props)
        elif props.active_tab == "ABOUT":
            self.draw_about_tab(layout, props)

    def draw_main_tab(self, layout, props):
        layout.prop(props, "animate_type")
        layout.prop(props, "timing")
        if props.timing == 'by_step':
            layout.prop(props, "keyframe_step")
        elif props.timing == 'by_duration':
            layout.prop(props, "frames_duration")

        layout.prop(props, "interpolation_mode")

        if props.interpolation_mode == 'BEZIER':
            layout.label(text="In Bezier mode, try to separate keyframes by 3 or 4 frames at least to avoid jumps", icon='ERROR')
            
        # Advanced settings
        box = layout.box()
        row = box.row()
        row.prop(props, "show_advanced", text="Advanced Settings", icon="TRIA_DOWN" if props.show_advanced else "TRIA_RIGHT", emboss=False)

        if props.show_advanced:
            row = box.row()
            row.prop(props, "graph_threshold_distance")  # Add threshold distance for curve intersections
            
            row = box.row()
            row.prop(props, "auto_update_cursor")
            
            row = box.row()
            row.prop(props, "reverse_trajectory")

            if props.animate_type == 'POSITION':
                row = box.row()
                row.prop(props, "jump_to_trajectory")

            row = box.row()

            # axis_label = 'Rotate on axis:' if props.animate_type == 'ROTATION' else 'Save keyframe on:'
            row.label(text="Save keyframe on:")
            row = box.row(align=True)
            row.prop(props, "use_x", toggle=True, text="X")
            row.prop(props, "use_y", toggle=True, text="Y")
            row.prop(props, "use_z", toggle=True, text="Z")

        layout.operator("object.simple_animation_operator", icon='PLAY')

        # Show the shortcut dynamically
        keyconfig = bpy.context.window_manager.keyconfigs.addon
        if keyconfig:
            keymap = keyconfig.keymaps.get('3D View')
            if keymap:
                for kmi in keymap.keymap_items:
                    if kmi.idname == "object.simple_animation_operator":
                        shortcut = kmi.type
                        modifiers = []
                        if kmi.shift:
                            modifiers.append("Shift")
                        if kmi.ctrl:
                            modifiers.append("Ctrl")
                        if kmi.alt:
                            modifiers.append("Alt")
                        shortcut_str = " + ".join(modifiers + [shortcut])
                        layout.label(text=f"Shortcut: {shortcut_str}", icon='KEYTYPE_KEYFRAME_VEC')
                        break
                    

    def draw_about_tab(self, layout, props):
        # layout.prop(props, "debug_mode")
        # layout.separator()
        layout.label(text="Simple Animation Graph Addon", icon="INFO")
        layout.label(text="Addon in constant update XD")
        layout.label(text="Dedouze")
        layout.separator()

        op = layout.operator(
            'wm.url_open',
            text='Support with a tip',
            icon='URL'
        )
        op.url = 'https://tipeee.com/dedouze'

# Update the properties class to include the active tab
class SimpleAnimationProperties(bpy.types.PropertyGroup):
    active_tab: bpy.props.EnumProperty(
        name="Tabs",
        description="Choose the active tab",
        items=[
            ("MAIN", "Main", "Main animation settings"),
            ("ABOUT", "About", "About this addon"),
        ],
        default="MAIN",
    )

    animate_type: bpy.props.EnumProperty(
        name="Animation Type",
        description="Choose whether to animate position or rotation",
        items=[
            ('POSITION', "Position", "Animate object position"),
            ('ROTATION', "Rotation", "Animate object rotation"),
        ],
        default='POSITION',
    )
    
    timing: bpy.props.EnumProperty(
        name="Timing",
        description="Choose keyframe timing mode",
        items=[
            ('by_step', "By Step", "Set keyframes every X frames"),
            ('by_duration', "By Duration", "Set the total duration in frames"),
        ],
        default='by_step',
    )
    
    keyframe_step: bpy.props.IntProperty(
        name="Keyframe Step",
        description="Number of frames between keyframes",
        default=2,
        min=1,
    )

    frames_duration: bpy.props.IntProperty(
        name="Frames Duration",
        description="Total duration of the animation in frames",
        default=20,
        min=1,
    )

    interpolation_mode: bpy.props.EnumProperty(
        name="Interpolation Mode",
        description="Keyframe interpolation mode",
        items=[
            ('CONSTANT', "Constant", "No interpolation between keyframes"),
            ('LINEAR', "Linear", "Linear interpolation"),
            ('BEZIER', "Bezier", "Smooth interpolation (default)"),
        ],
        default='CONSTANT',
    )

    show_advanced: bpy.props.BoolProperty(
        name="Show Advanced",
        description="Show advanced settings",
        default=False,
    )

    auto_update_cursor: bpy.props.BoolProperty(
        name="Auto Update Cursor",
        description="Automatically move the cursor during animation",
        default=True,
    )

    reverse_trajectory: bpy.props.BoolProperty(
        name="Reverse Trajectory",
        description="Reverse the trajectory",
        default=False,
    )

    use_x: bpy.props.BoolProperty(
        name="Use X",
        description="Animate X axis",
        default=True,
    )
    
    use_y: bpy.props.BoolProperty(
        name="Use Y",
        description="Animate Y axis",
        default=True,
    )
    
    use_z: bpy.props.BoolProperty(
        name="Use Z",
        description="Animate Z axis",
        default=True,
    )

def register():
    bpy.utils.register_class(SimpleAnimationPanel)

def unregister():
    bpy.utils.unregister_class(SimpleAnimationPanel)
    