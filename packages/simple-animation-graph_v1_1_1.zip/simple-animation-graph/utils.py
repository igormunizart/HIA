import bpy
import mathutils

def calculate_intersection(p1_3d, p2_3d, p3_3d, p4_3d, epsilon=1e-6):
    """
    Calculate the intersection of two line segments in 3D space,
    but limit the calculation to the bounds of the segments.
    """
    p1 = p1_3d.xy
    p2 = p2_3d.xy
    p3 = p3_3d.xy
    p4 = p4_3d.xy

    def det(a, b):
        return a.x * b.y - a.y * b.x

    r = p2 - p1  # Direction vector of segment 1
    s = p4 - p3  # Direction vector of segment 2
    r_cross_s = det(r, s)

    # Check if the lines are parallel or coincident
    if abs(r_cross_s) < epsilon:
        return None

    p3_p1 = p3 - p1
    t = det(p3_p1, s) / r_cross_s
    u = det(p3_p1, r) / r_cross_s

    # Check if t and u are within the segment bounds [0, 1]
    if 0 <= t <= 1 and 0 <= u <= 1:
        intersection_point = tuple(p1 + t * r)
        return (intersection_point[0], intersection_point[1], p3_3d.z)

    return None  # No valid intersection

def batch_keyframe_operations(target, frame_data, data_path, interpolation_mode='LINEAR', use_x=True, use_y=True, use_z=True):
    """
    Insert multiple keyframes at once for efficiency.

    Parameters:
        target: The Blender object or PoseBone.
        frame_data: List of tuples [(frame_number, value_vector), ...].
        data_path: The Blender data path to insert keyframes (e.g., "location" or "rotation_euler").
        interpolation_mode: The interpolation mode for the keyframes (e.g., 'LINEAR', 'BEZIER', etc.).
    """
    action = None
    
    if isinstance(target, bpy.types.PoseBone):
        # Handle PoseBone animation
        armature = target.id_data  # Get the armature object
        action = armature.animation_data.action if armature.animation_data else None
        if not action:
            action = bpy.data.actions.new(name="BatchBoneAction")
            armature.animation_data_create().action = action
        data_path_prefix = f'pose.bones["{target.name}"].'
    else:
        # Handle Object animation
        action = target.animation_data.action if target.animation_data else None
        if not action:
            action = bpy.data.actions.new(name="BatchObjectAction")
            target.animation_data_create().action = action
        data_path_prefix = ""
    
    # Extract or create fcurves for each axis based on user selection
    fcurves = []
    use_axes = [use_x, use_y, use_z]
    axis_indices = [i for i, use_axis in enumerate(use_axes) if use_axis]  # Get the indices of enabled axes

    for i in axis_indices:
        fcurve = next((fc for fc in action.fcurves if fc.data_path == f'{data_path_prefix}{data_path}' and fc.array_index == i), None)
        if not fcurve:
            fcurve = action.fcurves.new(data_path=f'{data_path_prefix}{data_path}', index=i)
        fcurves.append((i, fcurve))

    # Insert keyframes into each fcurve
    for frame, value in frame_data:
        for index, fcurve in fcurves:
            keyframe = fcurve.keyframe_points.insert(frame, value[index])
            keyframe.interpolation = interpolation_mode


# Optimization for Gimbal Lock Prevention and Flipping
def smooth_rotation_euler(target, frame_data):
    """
    Process Euler rotations from quaternions while ensuring smooth transitions to avoid gimbal lock.

    Parameters:
        target: The Blender object or PoseBone whose animation should be modified.
        frame_data: List of tuples [(frame_number, rotation_quaternion), ...].

    Returns:
        List of tuples [(frame_number, rotation_euler), ...] where rotation_euler is a mathutils.Euler.
    """
    euler_data = []

    prev_euler = None
    for frame, quat in frame_data:
        # Convert quaternion to Euler angles
        euler_rot = quat.to_euler('XYZ')

        # Ensure compatibility with previous Euler to avoid gimbal lock
        if prev_euler:
            euler_rot.make_compatible(prev_euler)
        
        prev_euler = euler_rot.copy()

        # Append to new frame data list as Euler rotation
        euler_data.append((frame, euler_rot))

    return euler_data


# Updated utility functions to handle parent inverse and differentiate between objects and bones

def convert_to_local_rotation(target, world_quaternion):
    """
    Convert a world-space quaternion to the local space of an object or a bone.

    Parameters:
        target: The Blender object or PoseBone.
        world_quaternion: The rotation in world space to convert (Quaternion).

    Returns:
        mathutils.Quaternion: The local-space rotation relative to the target.
    """
    if isinstance(target, bpy.types.PoseBone):
        # Handle PoseBone
        armature = target.id_data  # Get the armature object
        bone_matrix = armature.matrix_world @ target.matrix
        bone_matrix_inv = bone_matrix.inverted()
        return (bone_matrix_inv.to_quaternion() @ world_quaternion).normalized()
    else:
        # Handle Object
        if not target.parent:
            return world_quaternion  # No transformation needed

        obj_matrix = target.matrix_world
        if target.parent:
            # Take into account the parent inverse matrix if it exists
            parent_matrix = target.parent.matrix_world
            parent_inv = target.matrix_parent_inverse
            obj_matrix = parent_matrix @ parent_inv @ target.matrix_basis

        obj_matrix_inv = obj_matrix.inverted()
        return (obj_matrix_inv.to_quaternion() @ world_quaternion).normalized()


def convert_to_local_point(target, world_position):
    """
    Convert a world-space position to the local space of an object or a bone,
    while taking scale into account.

    Parameters:
        target: The Blender object or PoseBone.
        world_position: The position in world space to convert (Vector).

    Returns:
        mathutils.Vector: The local-space position relative to the target.
    """
    if isinstance(target, bpy.types.PoseBone):
        # Handle PoseBone
        armature = target.id_data  # Get the armature object
        bone_matrix_world = armature.matrix_world @ target.bone.matrix_local
        bone_matrix_world_inv = bone_matrix_world.inverted()
        return bone_matrix_world_inv @ world_position
    else:
        # Handle Object
        if not target.parent:
            return world_position

        # If object has a parent, handle parent-relative transformation
        parent_matrix = target.parent.matrix_world
        parent_inverse = target.matrix_parent_inverse
        parent_combined = parent_matrix @ parent_inverse
        local_position = (parent_combined.inverted() @ world_position)
        # Correct for scaling (divide by the object's scale to handle non-uniform scaling)
        scale = target.scale
        if scale.x != 0 and scale.y != 0 and scale.z != 0:  # Avoid division by zero
            local_position.x /= scale.x
            local_position.y /= scale.y
            local_position.z /= scale.z
        
        return local_position


def get_absolute_position(target, local_position=None):
    """
    Get the absolute world position of an object or a bone in an armature.
    
    Parameters:
        target: The Blender object or PoseBone.

    Returns:
        mathutils.Vector: The absolute world position of the target.
    """
    if isinstance(target, bpy.types.PoseBone):
        parent_matrix = armature.matrix_world
        parent_inv = target.matrix
        if local_position is None:
            return bone.head#(parent_matrix @ parent_inv) @ target.location
        # Not working ! needs fix !
        return (parent_matrix @ parent_inv) @ local_position
    else:
        # Handle Object
        if target.parent:
            parent_matrix = target.parent.matrix_world
            parent_inv = target.matrix_parent_inverse
            if local_position is None:
                return (parent_matrix @ parent_inv) @ target.location
            return (parent_matrix @ parent_inv) @ local_position
        else:
            if local_position is None:
                return target.location
            return local_position
